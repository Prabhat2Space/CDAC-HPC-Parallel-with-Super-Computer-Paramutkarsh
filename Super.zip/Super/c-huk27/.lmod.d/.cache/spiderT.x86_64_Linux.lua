-- Date: Thu May  2 11:50:21 2024
ancient = 86400
mrcT = {
  alias2modT = {},
  hiddenT = {},
  version2modT = {},
}
spiderT = {
  ["/home/apps/modulefiles"]  = {
    ["Ansys-2023R1"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["Ansys-2023R1/Ansys"]  = {
          ["Version"] = "Ansys",
          ["canonical"] = "Ansys",
          ["fn"] = "/home/apps/modulefiles/Ansys-2023R1/Ansys",
          ["help"] = [[
Sets the environment for using Ansys 2023R1 
in the shared directory /home/raviks/ansys_inc/v232

]],
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*ansys.*zfinal",
          pathA = {
            ["/home/raviks/ansys_inc/shared_files/licensing/lic_admin"] = 1,
            ["/home/raviks/ansys_inc/shared_files/licensing/linx64"] = 1,
            ["/home/raviks/ansys_inc/v232/ACP"] = 1,
            ["/home/raviks/ansys_inc/v232/AFD/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/CEI/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/CFD-Post/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/CFX/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/Framework/bin/Linux64"] = 1,
            ["/home/raviks/ansys_inc/v232/Icepak/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/RSM/Config/tools/linux"] = 1,
            ["/home/raviks/ansys_inc/v232/TurboGrid/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/aisol/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/ansys/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/autodyn/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/fensapice/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/fluent/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/icemcfd/linux64_amd/bin"] = 1,
            ["/home/raviks/ansys_inc/v232/polyflow/bin"] = 1,
          },
          ["wV"] = "*ansys.*zfinal",
          whatis = {
            "(Name________) Ansys ", "(Version_____) 23 ", "(Compilers___)  "
            , "(System______) x86_64-redhat-linux ", "(Libraries___)  ",
          },
        },
      },
    },
    IntelPy = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["IntelPy/3.7"]  = {
          ["Version"] = "3.7",
          ["canonical"] = "3.7",
          ["fn"] = "/home/apps/modulefiles/IntelPy/3.7",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/home/apps/cdac/DL/py_intel/Intel_Python/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
        },
      },
    },
    Tmolex = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["Tmolex/Tmolex"]  = {
          ["Version"] = "Tmolex",
          ["canonical"] = "Tmolex",
          ["fn"] = "/home/apps/modulefiles/Tmolex/Tmolex",
          lpathA = {
            ["/home/ravikumar/COSMOlogic/TmoleX19/TURBOMOLE"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*tmolex.*zfinal",
          pathA = {
            ["/home/ravikumar/COSMOlogic/TmoleX19"] = 1,
          },
          ["wV"] = "*tmolex.*zfinal",
        },
      },
    },
    anaconda3 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["anaconda3/anaconda3"]  = {
          ["Version"] = "anaconda3",
          ["canonical"] = "anaconda3",
          ["fn"] = "/home/apps/modulefiles/anaconda3/anaconda3",
          lpathA = {
            ["/home/apps/anaconda3/lib"] = 1,
            ["/home/apps/firefox"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*anaconda.000000003.*zfinal",
          pathA = {
            ["/home/apps/anaconda3/bin"] = 1,
            ["/home/apps/firefox"] = 1,
            ["/home/apps/pycharm-community-2022.2.3/bin"] = 1,
          },
          ["wV"] = "*anaconda.000000003.*zfinal",
        },
        ["anaconda3/pytorch"]  = {
          ["Version"] = "pytorch",
          ["canonical"] = "pytorch",
          ["fn"] = "/home/apps/modulefiles/anaconda3/pytorch",
          lpathA = {
            ["/home/apps/anaconda3/lib"] = 1,
            ["/home/apps/firefox"] = 1,
            ["/opt/ohpc/pub/cuda/cuda-10.2/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*pytorch.*zfinal",
          pathA = {
            ["/home/apps/anaconda3/bin"] = 1,
            ["/home/apps/firefox"] = 1,
            ["/home/apps/pycharm-community-2022.2.3/bin"] = 1,
          },
          ["wV"] = "*pytorch.*zfinal",
        },
        ["anaconda3/tensorflow"]  = {
          ["Version"] = "tensorflow",
          ["canonical"] = "tensorflow",
          ["fn"] = "/home/apps/modulefiles/anaconda3/tensorflow",
          lpathA = {
            ["/home/apps/anaconda3/envs/tf/lib"] = 1,
            ["/home/apps/anaconda3/lib"] = 1,
            ["/home/apps/firefox"] = 1,
            ["/opt/ohpc/pub/cuda/cuda-11.2/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*tensorflow.*zfinal",
          pathA = {
            ["/home/apps/anaconda3/envs/tf/bin"] = 1,
            ["/home/apps/firefox"] = 1,
            ["/home/apps/pycharm-community-2022.2.3/bin"] = 1,
            ["/opt/ohpc/pub/cuda/cuda-11.2/bin"] = 1,
          },
          ["wV"] = "*tensorflow.*zfinal",
        },
      },
    },
    calibre = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["calibre/calibre"]  = {
          ["Version"] = "calibre",
          ["canonical"] = "calibre",
          ["fn"] = "/home/apps/modulefiles/calibre/calibre",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*calibre.*zfinal",
          pathA = {
            ["/home/apps/Calibre_2022.4_37/aoi_cal_2022.4_37.20/bin"] = 1,
          },
          ["wV"] = "*calibre.*zfinal",
        },
      },
    },
    cfour = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["cfour/cfour_24"]  = {
          ["Version"] = "cfour_24",
          ["canonical"] = "cfour_24",
          ["fn"] = "/home/apps/modulefiles/cfour/cfour_24",
          lpathA = {
            ["/home/apps/cfour/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*cfour.*_.000000024.*zfinal",
          pathA = {
            ["/home/apps/cfour/bin"] = 1,
          },
          ["wV"] = "*cfour.*_.000000024.*zfinal",
        },
      },
    },
    dtcraft = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["dtcraft/v0.1"]  = {
          ["Version"] = "v0.1",
          ["canonical"] = "v0.1",
          ["fn"] = "/home/apps/modulefiles/dtcraft/v0.1",
          ["help"] = [[
	Adds dtcraft to your environment

]],
          lpathA = {
            ["/home/apps/DtCraft/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*v.000000000.000000001.*zfinal",
          pathA = {
            ["/home/apps/DtCraft/bin"] = 1,
          },
          ["wV"] = "*v.000000000.000000001.*zfinal",
          whatis = {
            "Adds dtcraft to your environment ",
          },
        },
      },
    },
    firefox = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["firefox/101.0"]  = {
          ["Version"] = "101.0",
          ["canonical"] = "101.0",
          ["fn"] = "/home/apps/modulefiles/firefox/101.0",
          lpathA = {
            ["/home/apps/firefox"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000101.*zfinal",
          pathA = {
            ["/home/apps/firefox"] = 1,
          },
          ["wV"] = "000000101.*zfinal",
        },
      },
    },
    gcc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gcc/gcc-11.2.0"]  = {
          ["Name"] = "GNU Compiler Collection ",
          ["Version"] = "gcc-11.2.0",
          ["canonical"] = "gcc-11.2.0",
          ["fn"] = "/home/apps/modulefiles/gcc/gcc-11.2.0",
          lpathA = {
            ["/home/cdacapp/madhuri/GCC/gcc-11.2.0/mybin/lib"] = 1,
            ["/home/cdacapp/madhuri/GCC/gcc-11.2.0/mybin/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*gcc.*zfinal-.000000011.000000002.*zfinal",
          pathA = {
            ["/home/cdacapp/madhuri/GCC/gcc-11.2.0/mybin/bin"] = 1,
          },
          ["wV"] = "*gcc.*zfinal-.000000011.000000002.*zfinal",
          whatis = {
            "Name: GNU Compiler Collection ",
          },
        },
      },
    },
    genus = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["genus/genus"]  = {
          ["Version"] = "genus",
          ["canonical"] = "genus",
          ["fn"] = "/home/apps/modulefiles/genus/genus",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*genus.*zfinal",
          pathA = {
            ["/home/apps/GENUS201/bin"] = 1,
          },
          ["wV"] = "*genus.*zfinal",
        },
      },
    },
    gromacs = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gromacs/gromacs-2023.1"]  = {
          ["Version"] = "gromacs-2023.1",
          ["canonical"] = "gromacs-2023.1",
          ["fn"] = "/home/apps/modulefiles/gromacs/gromacs-2023.1",
          lpathA = {
            ["/home/cdacapp/madhuri/Gromacs/gromacs-2023.1/build_cpu_threaded/newbin/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*gromacs.*zfinal-.000002023.000000001.*zfinal",
          pathA = {
            ["/home/cdacapp/madhuri/Gromacs/gromacs-2023.1/build_cpu_threaded/newbin/bin"] = 1,
          },
          ["wV"] = "*gromacs.*zfinal-.000002023.000000001.*zfinal",
        },
      },
    },
    gromacs_plumed = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gromacs_plumed/gromacs_plumed_oneapi"]  = {
          ["Version"] = "gromacs_plumed_oneapi",
          ["canonical"] = "gromacs_plumed_oneapi",
          ["fn"] = "/home/apps/modulefiles/gromacs_plumed/gromacs_plumed_oneapi",
          ["help"] = [[
	Adds gromacs_plumed to your environment

]],
          lpathA = {
            ["/home/apps/gromacs_plumed/build/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*gromacs.*_.*plumed.*_.*oneapi.*zfinal",
          pathA = {
            ["/home/apps/gromacs_plumed/build/bin"] = 1,
          },
          ["wV"] = "*gromacs.*_.*plumed.*_.*oneapi.*zfinal",
          whatis = {
            "Adds gromacs_plumed to your environment ",
          },
        },
      },
    },
    horovod_python = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["horovod_python/3.9"]  = {
          ["Version"] = "3.9",
          ["canonical"] = "3.9",
          ["fn"] = "/home/apps/modulefiles/horovod_python/3.9",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000003.000000009.*zfinal",
          pathA = {
            ["/home/apps/cdac/DL/horovod_install/miniconda3/bin"] = 1,
          },
          ["wV"] = "000000003.000000009.*zfinal",
        },
      },
    },
    innovus = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["innovus/1"]  = {
          ["Version"] = "1",
          ["canonical"] = "1",
          ["fn"] = "/home/apps/modulefiles/innovus/1",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000001.*zfinal",
          pathA = {
            ["/home/apps/yosys_build/bin"] = 1,
          },
          ["wV"] = "000000001.*zfinal",
        },
        ["innovus/innovus"]  = {
          ["Version"] = "innovus",
          ["canonical"] = "innovus",
          ["fn"] = "/home/apps/modulefiles/innovus/innovus",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*innovus.*zfinal",
          pathA = {
            ["/home/apps/Innovus/INNOVUS201/bin"] = 1,
          },
          ["wV"] = "*innovus.*zfinal",
        },
      },
    },
    jdk11 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["jdk11/jdk-11.0.16"]  = {
          ["Version"] = "jdk-11.0.16",
          ["canonical"] = "jdk-11.0.16",
          ["fn"] = "/home/apps/modulefiles/jdk11/jdk-11.0.16",
          lpathA = {
            ["/home/apps/jdk/jdk-11.0.16.1/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*jdk.*zfinal-.000000011.000000000.000000016.*zfinal",
          pathA = {
            ["/home/apps/jdk/jdk-11.0.16.1/bin"] = 1,
          },
          ["wV"] = "*jdk.*zfinal-.000000011.000000000.000000016.*zfinal",
        },
        ["jdk11/jdk-11.0.16.bak"]  = {
          ["Version"] = "jdk-11.0.16.bak",
          ["canonical"] = "jdk-11.0.16.bak",
          ["fn"] = "/home/apps/modulefiles/jdk11/jdk-11.0.16.bak",
          lpathA = {
            ["/home/apps/jdk/jdk-11.0.16.1/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*jdk.*zfinal-.000000011.000000000.000000016.*bak.*zfinal",
          pathA = {
            ["/home/apps/jdk/jdk-11.0.16.1/bin"] = 1,
          },
          ["wV"] = "*jdk.*zfinal-.000000011.000000000.000000016.*bak.*zfinal",
        },
      },
    },
    julia = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["julia/gromacs-2023.1"]  = {
          ["Version"] = "gromacs-2023.1",
          ["canonical"] = "gromacs-2023.1",
          ["fn"] = "/home/apps/modulefiles/julia/gromacs-2023.1",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*gromacs.*zfinal-.000002023.000000001.*zfinal",
          ["wV"] = "*gromacs.*zfinal-.000002023.000000001.*zfinal",
        },
        ["julia/julia"]  = {
          ["Version"] = "julia",
          ["canonical"] = "julia",
          ["fn"] = "/home/apps/modulefiles/julia/julia",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*julia.*zfinal",
          pathA = {
            ["/home/apps/julia/julia-1.8.5/usr/bin"] = 1,
          },
          ["wV"] = "*julia.*zfinal",
          whatis = {
            "Adds Julia to your environment ",
          },
        },
      },
    },
    lamps2022 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["lamps2022/20220623"]  = {
          ["Version"] = "20220623",
          ["canonical"] = "20220623",
          ["fn"] = "/home/apps/modulefiles/lamps2022/20220623",
          lpathA = {
            ["/home/apps/lammps20220623/newbin/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "020220623.*zfinal",
          pathA = {
            ["/home/apps/lammps20220623/newbin/bin"] = 1,
          },
          ["wV"] = "020220623.*zfinal",
        },
      },
    },
    magic = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["magic/magic"]  = {
          ["Version"] = "magic",
          ["canonical"] = "magic",
          ["fn"] = "/home/apps/modulefiles/magic/magic",
          ["help"] = [[
	Adds magic to your environment

]],
          lpathA = {
            ["/home/apps/QFLOW/magic/build/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*magic.*zfinal",
          pathA = {
            ["/home/apps/QFLOW/magic/build/bin"] = 1,
          },
          ["wV"] = "*magic.*zfinal",
          whatis = {
            "Adds magic to your environment ",
          },
        },
      },
    },
    namd = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["namd/cpu"]  = {
          ["Version"] = "cpu",
          ["canonical"] = "cpu",
          ["fn"] = "/home/apps/modulefiles/namd/cpu",
          ["help"] = [[
	Adds NAMD (CPU based) to your environment

]],
          lpathA = {
            ["/home/apps/namd-test/namd-2.14/intel/fftw-3.3.10/lib"] = 1,
            ["/home/apps/namd-test/namd-2.14/intel/tcl8.6.10/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*cpu.*zfinal",
          pathA = {
            ["/home/apps/namd-test/namd-2.14/cpu/bin"] = 1,
            ["/home/apps/namd-test/namd-2.14/intel/fftw-3.3.10/bin"] = 1,
            ["/home/apps/namd-test/namd-2.14/intel/tcl8.6.10/bin"] = 1,
          },
          ["wV"] = "*cpu.*zfinal",
          whatis = {
            "Adds NAMD (CPU based) to your environment ",
          },
        },
        ["namd/gpu"]  = {
          ["Version"] = "gpu",
          ["canonical"] = "gpu",
          ["fn"] = "/home/apps/modulefiles/namd/gpu",
          ["help"] = [[
	Adds NAMD (CPU based) to your environment

]],
          lpathA = {
            ["/home/apps/NAMD/v2.14/intel/fftw-3.3.10/lib"] = 1,
            ["/home/apps/NAMD/v2.14/intel/tcl8.6.10/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*gpu.*zfinal",
          pathA = {
            ["/home/apps/NAMD/v2.14/gpu/bin"] = 1,
            ["/home/apps/NAMD/v2.14/intel/fftw-3.3.10/bin"] = 1,
            ["/home/apps/NAMD/v2.14/intel/tcl8.6.10/bin"] = 1,
          },
          ["wV"] = "*gpu.*zfinal",
          whatis = {
            "Adds NAMD (CPU based) to your environment ",
          },
        },
      },
    },
    netgen = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netgen/netgen"]  = {
          ["Version"] = "netgen",
          ["canonical"] = "netgen",
          ["fn"] = "/home/apps/modulefiles/netgen/netgen",
          lpathA = {
            ["/home/apps/gen/netgen/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*netgen.*zfinal",
          pathA = {
            ["/home/apps/gen/netgen/build/bin"] = 1,
          },
          ["wV"] = "*netgen.*zfinal",
          whatis = {
            "Adds gen to your environment ",
          },
        },
      },
    },
    ngspice = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ngspice/ngspice"]  = {
          ["Version"] = "ngspice",
          ["canonical"] = "ngspice",
          ["fn"] = "/home/apps/modulefiles/ngspice/ngspice",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*ngspice.*zfinal",
          pathA = {
            ["/home/apps/ngspice/bin"] = 1,
          },
          ["wV"] = "*ngspice.*zfinal",
        },
      },
    },
    nwchem = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["nwchem/gpu"]  = {
          ["Version"] = "gpu",
          ["canonical"] = "gpu",
          ["fn"] = "/home/apps/modulefiles/nwchem/gpu",
          ["help"] = [[
	Adds NWChem (GPU based) to your environment

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-10.3.0/cuda-11.5.0-rm2uenxwqwxjnmcvccrbuijs5jyhcsdc/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-10.3.0/cuda-11.5.0-rm2uenxwqwxjnmcvccrbuijs5jyhcsdc/lib64/stubs"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-10.3.0/openmpi-4.1.1-iyeajbrxaem6zf55nzsz6xv6sz6v7e6u/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/cuda-10.2.89-4wvupp7dcwmmu7pkzorsw6dpfyayr5lv/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/hwloc-2.6.0-iie5gvzfgfa43uj2flsr3vhnjy7iczml/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*gpu.*zfinal",
          pathA = {
            ["/home/apps/nwchem/nwchem2/nwchem-7.2.2/bin/LINUX64"] = 1,
          },
          ["wV"] = "*gpu.*zfinal",
          whatis = {
            "Adds NWChem (GPU based) to your environment ",
          },
        },
      },
    },
    openRoad = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openRoad/openRoad"]  = {
          ["Version"] = "openRoad",
          ["canonical"] = "openRoad",
          ["fn"] = "/home/apps/modulefiles/openRoad/openRoad",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*openroad.*zfinal",
          ["wV"] = "*openroad.*zfinal",
          whatis = {
            "openRoad to your environment ",
          },
        },
      },
    },
    openSTA = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openSTA/openSTA"]  = {
          ["Version"] = "openSTA",
          ["canonical"] = "openSTA",
          ["fn"] = "/home/apps/modulefiles/openSTA/openSTA",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*opensta.*zfinal",
          pathA = {
            ["/home/apps/openSTA/OpenSTA/app"] = 1,
          },
          ["wV"] = "*opensta.*zfinal",
          whatis = {
            "OpenSTA to your environment ",
          },
        },
      },
    },
    openTimer = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openTimer/openTimer"]  = {
          ["Version"] = "openTimer",
          ["canonical"] = "openTimer",
          ["fn"] = "/home/apps/modulefiles/openTimer/openTimer",
          lpathA = {
            ["/home/apps/opentimer/OpenTimer-master/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*opentimer.*zfinal",
          pathA = {
            ["/home/apps/opentimer/OpenTimer-master/bin"] = 1,
          },
          ["wV"] = "*opentimer.*zfinal",
          whatis = {
            "OpenTimer to your environment ",
          },
        },
      },
    },
    openmpi = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openmpi/4.1.4"]  = {
          ["Version"] = "4.1.4",
          ["canonical"] = "4.1.4",
          ["fn"] = "/home/apps/modulefiles/openmpi/4.1.4",
          lpathA = {
            ["/home/cdacapp/madhuri/MPI/openmpi-4.1.4/mybin/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000004.000000001.000000004.*zfinal",
          pathA = {
            ["/home/cdacapp/madhuri/MPI/openmpi-4.1.4/mybin/bin"] = 1,
          },
          ["wV"] = "000000004.000000001.000000004.*zfinal",
        },
      },
    },
    ["or-tools"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["or-tools/or-tools"]  = {
          ["Version"] = "or-tools",
          ["canonical"] = "or-tools",
          ["fn"] = "/home/apps/modulefiles/or-tools/or-tools",
          lpathA = {
            ["/home/cdacapp1/ordtools/merabin/lib"] = 1,
            ["/home/cdacapp1/ordtools/merabin/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*or.*tools.*zfinal",
          pathA = {
            ["/home/cdacapp1/ordtools/merabin/bin"] = 1,
          },
          ["wV"] = "*or.*tools.*zfinal",
          whatis = {
            "ord-tools to your environment ",
          },
        },
      },
    },
    paraview = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["paraview/5.10"]  = {
          ["Version"] = "5.10",
          ["canonical"] = "5.10",
          ["fn"] = "/home/apps/modulefiles/paraview/5.10",
          lpathA = {
            ["/home/apps/paraview/ParaView-5.10.1-MPI-Linux-Python3.9-x86_64/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000005.000000010.*zfinal",
          pathA = {
            ["/home/apps/paraview/ParaView-5.10.1-MPI-Linux-Python3.9-x86_64/bin"] = 1,
          },
          ["wV"] = "000000005.000000010.*zfinal",
        },
      },
    },
    primetime = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["primetime/primetime"]  = {
          ["Version"] = "primetime",
          ["canonical"] = "primetime",
          ["fn"] = "/home/apps/modulefiles/primetime/primetime",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*primetime.*zfinal",
          pathA = {
            ["/home/apps/Synopsys_EDA/synopsys/prime/T-2022.03-SP2/bin"] = 1,
          },
          ["wV"] = "*primetime.*zfinal",
        },
      },
    },
    ["python/conda-python"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["python/conda-python/3.7"]  = {
          ["Version"] = "3.7",
          ["canonical"] = "3.7",
          ["fn"] = "/home/apps/modulefiles/python/conda-python/3.7",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/home/apps/cdac/DL/DL-CondaPy3.7/bin"] = 1,
            ["/home/apps/cdac/DL/DL-CondaPy3.7/condabin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
        },
      },
    },
    qflow = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["qflow/qflow"]  = {
          ["Version"] = "qflow",
          ["canonical"] = "qflow",
          ["fn"] = "/home/apps/modulefiles/qflow/qflow",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*qflow.*zfinal",
          pathA = {
            ["/home/apps/QFLOW/qflow/build/bin"] = 1,
          },
          ["wV"] = "*qflow.*zfinal",
          whatis = {
            "Adds qflow to your environment ",
          },
        },
      },
    },
    qrouter = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["qrouter/qrouter"]  = {
          ["Version"] = "qrouter",
          ["canonical"] = "qrouter",
          ["fn"] = "/home/apps/modulefiles/qrouter/qrouter",
          lpathA = {
            ["/home/apps/QROUTER/qrouter/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*qrouter.*zfinal",
          pathA = {
            ["/home/apps/QROUTER/qrouter/build/bin"] = 1,
          },
          ["wV"] = "*qrouter.*zfinal",
          whatis = {
            "Adds qrouter to your environment ",
          },
        },
      },
    },
    ["rapid/conda-rapid"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["rapid/conda-rapid/21.08"]  = {
          ["Version"] = "21.08",
          ["canonical"] = "21.08",
          ["fn"] = "/home/apps/modulefiles/rapid/conda-rapid/21.08",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000021.000000008.*zfinal",
          pathA = {
            ["/home/apps/cdac/DL/RAPIDS_final/rapids/bin"] = 1,
            ["/home/apps/cdac/DL/RAPIDS_final/rapids/condabin"] = 1,
          },
          ["wV"] = "000000021.000000008.*zfinal",
        },
      },
    },
    spack = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["spack/0.16.3"]  = {
          ["Version"] = "0.16.3",
          ["canonical"] = "0.16.3",
          ["fn"] = "/home/apps/modulefiles/spack/0.16.3",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "000000000.000000016.000000003.*zfinal",
          pathA = {
            ["/home/apps/spack/bin"] = 1,
          },
          ["wV"] = "000000000.000000016.000000003.*zfinal",
        },
      },
    },
    spark = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["spark/spark-3.1.3"]  = {
          ["Version"] = "spark-3.1.3",
          ["canonical"] = "spark-3.1.3",
          ["fn"] = "/home/apps/modulefiles/spark/spark-3.1.3",
          lpathA = {
            ["/home/apps/anaconda3/lib"] = 1,
            ["/home/apps/firefox"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*spark.*zfinal-.000000003.000000001.000000003.*zfinal",
          pathA = {
            ["/home/apps/anaconda3/bin"] = 1,
            ["/home/apps/apache_spark/jdk1.8.0_131/bin"] = 1,
            ["/home/apps/apache_spark/spark-3.1.3-bin-hadoop3.2/bin"] = 1,
            ["/home/apps/apache_spark/spark-3.1.3-bin-hadoop3.2/sbin"] = 1,
            ["/home/apps/firefox"] = 1,
            ["/home/apps/pycharm-community-2022.2.3/bin"] = 1,
          },
          ["wV"] = "*spark.*zfinal-.000000003.000000001.000000003.*zfinal",
        },
      },
    },
    vcs = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["vcs/vcs"]  = {
          ["Version"] = "vcs",
          ["canonical"] = "vcs",
          ["fn"] = "/home/apps/modulefiles/vcs/vcs",
          lpathA = {
            ["/usr/lib"] = 1,
            ["/usr/lib64"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*vcs.*zfinal",
          pathA = {
            ["/home/apps/vcs/vcs/U-2023.03/bin"] = 1,
          },
          ["wV"] = "*vcs.*zfinal",
        },
      },
    },
    verdi = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["verdi/verdi"]  = {
          ["Version"] = "verdi",
          ["canonical"] = "verdi",
          ["fn"] = "/home/apps/modulefiles/verdi/verdi",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*verdi.*zfinal",
          pathA = {
            ["/home/apps/verdi/verdi/U-2023.03-SP1/bin"] = 1,
          },
          ["wV"] = "*verdi.*zfinal",
        },
      },
    },
    virtuoso = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["virtuoso/virtuoso"]  = {
          ["Version"] = "virtuoso",
          ["canonical"] = "virtuoso",
          ["fn"] = "/home/apps/modulefiles/virtuoso/virtuoso",
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*virtuoso.*zfinal",
          pathA = {
            ["/home/apps/IC618/bin"] = 1,
          },
          ["wV"] = "*virtuoso.*zfinal",
        },
      },
    },
    yosys = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["yosys/yosys"]  = {
          ["Version"] = "yosys",
          ["canonical"] = "yosys",
          ["fn"] = "/home/apps/modulefiles/yosys/yosys",
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/libffi-3.4.2-vqsv4fwfcm5k2hv5l5f7ahnonsqyi537/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-13.1.0/tcl-8.6.12-q2vb2oaf246jrj5ily4cmal67mjt4ber/lib"] = 1,
          },
          ["mpath"] = "/home/apps/modulefiles",
          ["pV"] = "*yosys.*zfinal",
          pathA = {
            ["/home/apps/yosys_build/bin"] = 1,
          },
          ["wV"] = "*yosys.*zfinal",
        },
      },
    },
  },
  ["/home/apps/spack/share/spack/modules/linux-centos7-cascadelake"]  = {
    abinit = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["abinit/9.4.2-intel-2021.3.0-oaj4"]  = {
          ["Version"] = "9.4.2-intel-2021.3.0-oaj4",
          ["canonical"] = "9.4.2-intel-2021.3.0-oaj4",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/abinit/9.4.2-intel-2021.3.0-oaj4",
          ["help"] = [[
ABINIT is a package whose main program allows one to find the total
energy, charge density and electronic structure of systems made of
electrons and nuclei (molecules and periodic solids) within Density
Functional Theory (DFT), using pseudopotentials and a planewave or
wavelet basis. ABINIT also includes options to optimize the geometry
according to the DFT forces and stresses, or to perform molecular
dynamics simulations using these forces, or to generate dynamical
matrices, Born effective charges, and dielectric tensors, based on
Density-Functional Perturbation Theory, and many more properties.
Excited states can be computed within the Many-Body Perturbation Theory
(the GW approximation and the Bethe-Salpeter equation), and Time-
Dependent Density Functional Theory (for molecules). In addition to the
main ABINIT code, different utility programs are provided.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/abinit-9.4.2-oaj44w2tznp3fx7jlulsgecxh4jkdkvw/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000009.000000004.000000002.*intel.*zfinal-.000002021.000000003.*oaj.000000004.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/abinit-9.4.2-oaj44w2tznp3fx7jlulsgecxh4jkdkvw/bin"] = 1,
          },
          ["wV"] = "000000009.000000004.000000002.*intel.*zfinal-.000002021.000000003.*oaj.000000004.*zfinal",
          whatis = {
            "ABINIT is a package whose main program allows one to find the total energy, charge density and electronic structure of systems made of electrons and nuclei (molecules and periodic solids) within Density Functional Theory (DFT), using pseudopotentials and a planewave or wavelet basis. ",
          },
        },
      },
    },
    anaconda3 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["anaconda3/2021.05-gcc-11.2.0-zhjd"]  = {
          ["Version"] = "2021.05-gcc-11.2.0-zhjd",
          ["canonical"] = "2021.05-gcc-11.2.0-zhjd",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/anaconda3/2021.05-gcc-11.2.0-zhjd",
          ["help"] = [[
 Anaconda is a free and open-source distribution of the Python and R
programming languages for scientific computing, that aims to simplify
package management and deployment. Package versions are managed by the
package management system conda.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/anaconda3-2021.05-zhjddue37p3aqz45djbpjlcc7qk4j3kh/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000005.*gcc.*zfinal-.000000011.000000002.*zhjd.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/anaconda3-2021.05-zhjddue37p3aqz45djbpjlcc7qk4j3kh/bin"] = 1,
          },
          ["wV"] = "000002021.000000005.*gcc.*zfinal-.000000011.000000002.*zhjd.*zfinal",
          whatis = {
            " Anaconda is a free and open-source distribution of the Python and R programming languages for scientific computing, that aims to simplify package management and deployment. Package versions are managed by the package management system conda.  ",
          },
        },
      },
    },
    ["arm-forge"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["arm-forge/22.0.1-gcc-12.1.0-pelf"]  = {
          ["Version"] = "22.0.1-gcc-12.1.0-pelf",
          ["canonical"] = "22.0.1-gcc-12.1.0-pelf",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/arm-forge/22.0.1-gcc-12.1.0-pelf",
          ["help"] = [[
Arm Forge is the complete toolsuite for software development - with
everything needed to debug, profile, optimize, edit and build C, C++ and
Fortran applications on Linux for high performance - from single threads
through to complex parallel HPC codes with MPI, OpenMP, threads or CUDA.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000022.000000000.000000001.*gcc.*zfinal-.000000012.000000001.*elf.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/arm-forge-22.0.1-pelfrbv6a6r6hunus4ns7hnrdbquwjd6/bin"] = 1,
          },
          ["wV"] = "000000022.000000000.000000001.*gcc.*zfinal-.000000012.000000001.*elf.*zfinal",
          whatis = {
            "Arm Forge is the complete toolsuite for software development - with everything needed to debug, profile, optimize, edit and build C, C++ and Fortran applications on Linux for high performance - from single threads through to complex parallel HPC codes with MPI, OpenMP, threads or CUDA. ",
          },
        },
      },
    },
    charliecloud = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["charliecloud/0.25-intel-2021.3.0-7qi7"]  = {
          ["Version"] = "0.25-intel-2021.3.0-7qi7",
          ["canonical"] = "0.25-intel-2021.3.0-7qi7",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/charliecloud/0.25-intel-2021.3.0-7qi7",
          ["help"] = [[
Lightweight user-defined software stacks for HPC.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000000.000000025.*intel.*zfinal-.000002021.000000003.*zfinal-.000000007.*qi.000000007.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/charliecloud-0.25-7qi7kjghdru44zlg5a2afd3pb737waoo/bin"] = 1,
          },
          ["wV"] = "000000000.000000025.*intel.*zfinal-.000002021.000000003.*zfinal-.000000007.*qi.000000007.*zfinal",
          whatis = {
            "Lightweight user-defined software stacks for HPC. ",
          },
        },
      },
    },
    cuda = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["cuda/11.4.0-gcc-11.2.0-gfra"]  = {
          ["Version"] = "11.4.0-gcc-11.2.0-gfra",
          ["canonical"] = "11.4.0-gcc-11.2.0-gfra",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/cuda/11.4.0-gcc-11.2.0-gfra",
          ["help"] = [[
CUDA is a parallel computing platform and programming model invented by
NVIDIA. It enables dramatic increases in computing performance by
harnessing the power of the graphics processing unit (GPU). Note: This
package does not currently install the drivers necessary to run CUDA.
These will need to be installed manually. See:
https://docs.nvidia.com/cuda/ for details.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000011.000000004.*gcc.*zfinal-.000000011.000000002.*gfra.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/cuda-11.4.0-gfra4raumcdwsj32tnxsa6c65ro3cx4n/bin"] = 1,
          },
          ["wV"] = "000000011.000000004.*gcc.*zfinal-.000000011.000000002.*gfra.*zfinal",
          whatis = {
            "CUDA is a parallel computing platform and programming model invented by NVIDIA. It enables dramatic increases in computing performance by harnessing the power of the graphics processing unit (GPU). ",
          },
        },
      },
    },
    ["darshan-util"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["darshan-util/3.3.1-gcc-11.2.0-vpf6"]  = {
          ["Version"] = "3.3.1-gcc-11.2.0-vpf6",
          ["canonical"] = "3.3.1-gcc-11.2.0-vpf6",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/darshan-util/3.3.1-gcc-11.2.0-vpf6",
          ["help"] = [[
Darshan (util) is collection of tools for parsing and summarizing log
files produced by Darshan (runtime) instrumentation. This package is
typically installed on systems (front-end) where you intend to analyze
log files produced by Darshan (runtime).

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/darshan-util-3.3.1-vpf6tvf2olsp3qpytack2igetmk5yrdl/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000003.000000001.*gcc.*zfinal-.000000011.000000002.*vpf.000000006.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/darshan-util-3.3.1-vpf6tvf2olsp3qpytack2igetmk5yrdl/bin"] = 1,
          },
          ["wV"] = "000000003.000000003.000000001.*gcc.*zfinal-.000000011.000000002.*vpf.000000006.*zfinal",
          whatis = {
            "Darshan (util) is collection of tools for parsing and summarizing log files produced by Darshan (runtime) instrumentation. This package is typically installed on systems (front-end) where you intend to analyze log files produced by Darshan (runtime). ",
          },
        },
      },
    },
    exabayes = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["exabayes/1.5.1-intel-2021.3.0-nfxg"]  = {
          ["Version"] = "1.5.1-intel-2021.3.0-nfxg",
          ["canonical"] = "1.5.1-intel-2021.3.0-nfxg",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/exabayes/1.5.1-intel-2021.3.0-nfxg",
          ["help"] = [[
ExaBayes is a software package for Bayesian tree inference. It is
particularly suitable for large-scale analyses on computer clusters.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000001.000000005.000000001.*intel.*zfinal-.000002021.000000003.*nfxg.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/exabayes-1.5.1-nfxgg4iw3l4ybehtzefxjrnzrch2srdu/bin"] = 1,
          },
          ["wV"] = "000000001.000000005.000000001.*intel.*zfinal-.000002021.000000003.*nfxg.*zfinal",
          whatis = {
            "ExaBayes is a software package for Bayesian tree inference. It is particularly suitable for large-scale analyses on computer clusters. ",
          },
        },
      },
    },
    extrae = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["extrae/3.8.3-gcc-11.2.0-a7pd"]  = {
          ["Version"] = "3.8.3-gcc-11.2.0-a7pd",
          ["canonical"] = "3.8.3-gcc-11.2.0-a7pd",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/extrae/3.8.3-gcc-11.2.0-a7pd",
          ["help"] = [[
Extrae is the package devoted to generate tracefiles which can be
analyzed later by Paraver. Extrae is a tool that uses different
interposition mechanisms to inject probes into the target application so
as to gather information regarding the application performance. The
Extrae instrumentation package can instrument the MPI programin model,
and the following parallel programming models either alone or in
conjunction with MPI : OpenMP, CUDA, OpenCL, pthread, OmpSs

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000008.000000003.*gcc.*zfinal-.000000011.000000002.*a.000000007.*pd.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/extrae-3.8.3-a7pdz4qvcm6yfrutyzimf3nzxn7shhax/bin"] = 1,
          },
          ["wV"] = "000000003.000000008.000000003.*gcc.*zfinal-.000000011.000000002.*a.000000007.*pd.*zfinal",
          whatis = {
            "Extrae is the package devoted to generate tracefiles which can be analyzed later by Paraver. Extrae is a tool that uses different interposition mechanisms to inject probes into the target application so as to gather information regarding the application performance. The Extrae instrumentation package can instrument the MPI programin model, and the following parallel programming models either alone or in conjunction with MPI : OpenMP, CUDA, OpenCL, pthread, OmpSs ",
          },
        },
        ["extrae/3.8.3-gcc-11.2.0-tilj"]  = {
          ["Version"] = "3.8.3-gcc-11.2.0-tilj",
          ["canonical"] = "3.8.3-gcc-11.2.0-tilj",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/extrae/3.8.3-gcc-11.2.0-tilj",
          ["help"] = [[
Extrae is the package devoted to generate tracefiles which can be
analyzed later by Paraver. Extrae is a tool that uses different
interposition mechanisms to inject probes into the target application so
as to gather information regarding the application performance. The
Extrae instrumentation package can instrument the MPI programin model,
and the following parallel programming models either alone or in
conjunction with MPI : OpenMP, CUDA, OpenCL, pthread, OmpSs

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000008.000000003.*gcc.*zfinal-.000000011.000000002.*tilj.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/extrae-3.8.3-tiljvampy753rtrgy5kccimpudq2bn5y/bin"] = 1,
          },
          ["wV"] = "000000003.000000008.000000003.*gcc.*zfinal-.000000011.000000002.*tilj.*zfinal",
          whatis = {
            "Extrae is the package devoted to generate tracefiles which can be analyzed later by Paraver. Extrae is a tool that uses different interposition mechanisms to inject probes into the target application so as to gather information regarding the application performance. The Extrae instrumentation package can instrument the MPI programin model, and the following parallel programming models either alone or in conjunction with MPI : OpenMP, CUDA, OpenCL, pthread, OmpSs ",
          },
        },
        ["extrae/3.8.3-gcc-11.2.0-to6l"]  = {
          ["Version"] = "3.8.3-gcc-11.2.0-to6l",
          ["canonical"] = "3.8.3-gcc-11.2.0-to6l",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/extrae/3.8.3-gcc-11.2.0-to6l",
          ["help"] = [[
Extrae is the package devoted to generate tracefiles which can be
analyzed later by Paraver. Extrae is a tool that uses different
interposition mechanisms to inject probes into the target application so
as to gather information regarding the application performance. The
Extrae instrumentation package can instrument the MPI programin model,
and the following parallel programming models either alone or in
conjunction with MPI : OpenMP, CUDA, OpenCL, pthread, OmpSs

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000008.000000003.*gcc.*zfinal-.000000011.000000002.*to.000000006.*l.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/extrae-3.8.3-to6le5jbmngwjiqhgugvyuq3dhaerwqu/bin"] = 1,
          },
          ["wV"] = "000000003.000000008.000000003.*gcc.*zfinal-.000000011.000000002.*to.000000006.*l.*zfinal",
          whatis = {
            "Extrae is the package devoted to generate tracefiles which can be analyzed later by Paraver. Extrae is a tool that uses different interposition mechanisms to inject probes into the target application so as to gather information regarding the application performance. The Extrae instrumentation package can instrument the MPI programin model, and the following parallel programming models either alone or in conjunction with MPI : OpenMP, CUDA, OpenCL, pthread, OmpSs ",
          },
        },
      },
    },
    fasta = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["fasta/36.3.8g-intel-2021.3.0-uhhs"]  = {
          ["Version"] = "36.3.8g-intel-2021.3.0-uhhs",
          ["canonical"] = "36.3.8g-intel-2021.3.0-uhhs",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/fasta/36.3.8g-intel-2021.3.0-uhhs",
          ["help"] = [[
The FASTA programs find regions of local or global similarity between
Protein or DNA sequences, either by searching Protein or DNA databases,
or by identifying local duplications within a sequence. Other programs
provide information on the statistical significance of an alignment.
Like BLAST, FASTA can be used to infer functional and evolutionary
relationships between sequences as well as help identify members of gene
families.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000036.000000003.000000008.*g.*intel.*zfinal-.000002021.000000003.*uhhs.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/fasta-36.3.8g-uhhsqtl7cl4p53nqecmg53u3z3djeyfy/bin"] = 1,
          },
          ["wV"] = "000000036.000000003.000000008.*g.*intel.*zfinal-.000002021.000000003.*uhhs.*zfinal",
          whatis = {
            "The FASTA programs find regions of local or global similarity between Protein or DNA sequences, either by searching Protein or DNA databases, or by identifying local duplications within a sequence. Other programs provide information on the statistical significance of an alignment. Like BLAST, FASTA can be used to infer functional and evolutionary relationships between sequences as well as help identify members of gene families.  ",
          },
        },
      },
    },
    gawk = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gawk/4.0.2-gcc-12.2.0-p2iw"]  = {
          ["Version"] = "4.0.2-gcc-12.2.0-p2iw",
          ["canonical"] = "4.0.2-gcc-12.2.0-p2iw",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gawk/4.0.2-gcc-12.2.0-p2iw",
          ["help"] = [[
Name   : gawk
Version: 4.0.2
Target : cascadelake

If you are like many computer users, you would frequently like to make
changes in various text files wherever certain patterns appear, or
extract data from parts of certain lines while discarding the rest. To
write a program to do this in a language such as C or Pascal is a time-
consuming inconvenience that may take many lines of code. The job is
easy with awk, especially the GNU implementation: gawk. The awk utility
interprets a special-purpose programming language that makes it possible
to handle simple data-reformatting jobs with just a few lines of code.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000004.000000000.000000002.*gcc.*zfinal-.000000012.000000002.*zfinal-.000000002.*iw.*zfinal",
          ["wV"] = "000000004.000000000.000000002.*gcc.*zfinal-.000000012.000000002.*zfinal-.000000002.*iw.*zfinal",
          whatis = {
            "If you are like many computer users, you would frequently like to make changes in various text files wherever certain patterns appear, or extract data from parts of certain lines while discarding the rest. To write a program to do this in a language such as C or Pascal is a time-consuming inconvenience that may take many lines of code. The job is easy with awk, especially the GNU implementation: gawk. ",
          },
        },
      },
    },
    gcc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gcc/12.1.0-gcc-11.2.0-5nqp"]  = {
          ["Version"] = "12.1.0-gcc-11.2.0-5nqp",
          ["canonical"] = "12.1.0-gcc-11.2.0-5nqp",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gcc/12.1.0-gcc-11.2.0-5nqp",
          ["help"] = [[
The GNU Compiler Collection includes front ends for C, C++, Objective-C,
Fortran, Ada, and Go, as well as libraries for these languages.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000012.000000001.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000005.*nqp.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/gcc-12.1.0-5nqpjhwocse6bfoww25kpgfzteohpnv5/bin"] = 1,
          },
          ["wV"] = "000000012.000000001.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000005.*nqp.*zfinal",
          whatis = {
            "The GNU Compiler Collection includes front ends for C, C++, Objective-C, Fortran, Ada, and Go, as well as libraries for these languages. ",
          },
        },
        ["gcc/4.8.5-gcc-12.2.0-zzyg"]  = {
          ["Version"] = "4.8.5-gcc-12.2.0-zzyg",
          ["canonical"] = "4.8.5-gcc-12.2.0-zzyg",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gcc/4.8.5-gcc-12.2.0-zzyg",
          ["help"] = [[
Name   : gcc
Version: 4.8.5
Target : cascadelake

The GNU Compiler Collection includes front ends for C, C++, Objective-C,
Fortran, Ada, and Go, as well as libraries for these languages.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000004.000000008.000000005.*gcc.*zfinal-.000000012.000000002.*zzyg.*zfinal",
          ["wV"] = "000000004.000000008.000000005.*gcc.*zfinal-.000000012.000000002.*zzyg.*zfinal",
          whatis = {
            "The GNU Compiler Collection includes front ends for C, C++, Objective-C, Fortran, Ada, and Go, as well as libraries for these languages. ",
          },
        },
      },
    },
    glimmer = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["glimmer/3.02b-intel-2021.3.0-uy5k"]  = {
          ["Version"] = "3.02b-intel-2021.3.0-uy5k",
          ["canonical"] = "3.02b-intel-2021.3.0-uy5k",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/glimmer/3.02b-intel-2021.3.0-uy5k",
          ["help"] = [[
Glimmer is a system for finding genes in microbial DNA, especially the
genomes of bacteria, archaea, and viruses.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000002.*b.*intel.*zfinal-.000002021.000000003.*uy.000000005.*k.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/glimmer-3.02b-uy5kamgldhnsfpvf5vnqmsuoqvrshhwx/bin"] = 1,
          },
          ["wV"] = "000000003.000000002.*b.*intel.*zfinal-.000002021.000000003.*uy.000000005.*k.*zfinal",
          whatis = {
            "Glimmer is a system for finding genes in microbial DNA, especially the genomes of bacteria, archaea, and viruses. ",
          },
        },
      },
    },
    gmake = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gmake/3.82-gcc-12.2.0-wwbf"]  = {
          ["Version"] = "3.82-gcc-12.2.0-wwbf",
          ["canonical"] = "3.82-gcc-12.2.0-wwbf",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gmake/3.82-gcc-12.2.0-wwbf",
          ["help"] = [[
Name   : gmake
Version: 3.82
Target : cascadelake

GNU Make is a tool which controls the generation of executables and
other non-source files of a program from the program's source files.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000082.*gcc.*zfinal-.000000012.000000002.*wwbf.*zfinal",
          ["wV"] = "000000003.000000082.*gcc.*zfinal-.000000012.000000002.*wwbf.*zfinal",
          whatis = {
            "GNU Make is a tool which controls the generation of executables and other non-source files of a program from the program's source files. ",
          },
        },
      },
    },
    gromacs = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gromacs/2018.4-intel-2021.4.0-qo33"]  = {
          ["Version"] = "2018.4-intel-2021.4.0-qo33",
          ["canonical"] = "2018.4-intel-2021.4.0-qo33",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gromacs/2018.4-intel-2021.4.0-qo33",
          ["help"] = [[
GROMACS (GROningen MAchine for Chemical Simulations) is a molecular
dynamics package primarily designed for simulations of proteins, lipids
and nucleic acids. It was originally developed in the Biophysical
Chemistry department of University of Groningen, and is now maintained
by contributors in universities and research centers across the world.
GROMACS is one of the fastest and most popular software packages
available and can run on CPUs as well as GPUs. It is free, open source
released under the GNU General Public License. Starting from version
4.6, GROMACS is released under the GNU Lesser General Public License.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002018.000000004.*intel.*zfinal-.000002021.000000004.*qo.000000033.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/gromacs-2018.4-qo33w7655freo5xrwklkayhv2nx3u2sc/bin"] = 1,
          },
          ["wV"] = "000002018.000000004.*intel.*zfinal-.000002021.000000004.*qo.000000033.*zfinal",
          whatis = {
            "GROMACS (GROningen MAchine for Chemical Simulations) is a molecular dynamics package primarily designed for simulations of proteins, lipids and nucleic acids. It was originally developed in the Biophysical Chemistry department of University of Groningen, and is now maintained by contributors in universities and research centers across the world. ",
          },
        },
        ["gromacs/2021.2-intel-2021.3.0-ajkj"]  = {
          ["Version"] = "2021.2-intel-2021.3.0-ajkj",
          ["canonical"] = "2021.2-intel-2021.3.0-ajkj",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gromacs/2021.2-intel-2021.3.0-ajkj",
          ["help"] = [[
GROMACS (GROningen MAchine for Chemical Simulations) is a molecular
dynamics package primarily designed for simulations of proteins, lipids
and nucleic acids. It was originally developed in the Biophysical
Chemistry department of University of Groningen, and is now maintained
by contributors in universities and research centers across the world.
GROMACS is one of the fastest and most popular software packages
available and can run on CPUs as well as GPUs. It is free, open source
released under the GNU General Public License. Starting from version
4.6, GROMACS is released under the GNU Lesser General Public License.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000002.*intel.*zfinal-.000002021.000000003.*ajkj.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/gromacs-2021.2-ajkj3jepsrr27oikewcklyz7v2wbxb5t/bin"] = 1,
          },
          ["wV"] = "000002021.000000002.*intel.*zfinal-.000002021.000000003.*ajkj.*zfinal",
          whatis = {
            "GROMACS (GROningen MAchine for Chemical Simulations) is a molecular dynamics package primarily designed for simulations of proteins, lipids and nucleic acids. It was originally developed in the Biophysical Chemistry department of University of Groningen, and is now maintained by contributors in universities and research centers across the world. ",
          },
        },
        ["gromacs/2021.3-gcc-10.3.0-4e3a"]  = {
          ["Version"] = "2021.3-gcc-10.3.0-4e3a",
          ["canonical"] = "2021.3-gcc-10.3.0-4e3a",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gromacs/2021.3-gcc-10.3.0-4e3a",
          ["help"] = [[
GROMACS (GROningen MAchine for Chemical Simulations) is a molecular
dynamics package primarily designed for simulations of proteins, lipids
and nucleic acids. It was originally developed in the Biophysical
Chemistry department of University of Groningen, and is now maintained
by contributors in universities and research centers across the world.
GROMACS is one of the fastest and most popular software packages
available and can run on CPUs as well as GPUs. It is free, open source
released under the GNU General Public License. Starting from version
4.6, GROMACS is released under the GNU Lesser General Public License.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000003.*gcc.*zfinal-.000000010.000000003.*zfinal-.000000004.*e.000000003.*a.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-10.3.0/gromacs-2021.3-4e3ajc53ntuu5n5zqs43rscpvwkij2j7/bin"] = 1,
          },
          ["wV"] = "000002021.000000003.*gcc.*zfinal-.000000010.000000003.*zfinal-.000000004.*e.000000003.*a.*zfinal",
          whatis = {
            "GROMACS (GROningen MAchine for Chemical Simulations) is a molecular dynamics package primarily designed for simulations of proteins, lipids and nucleic acids. It was originally developed in the Biophysical Chemistry department of University of Groningen, and is now maintained by contributors in universities and research centers across the world. ",
          },
        },
        ["gromacs/2021.3-intel-2021.5.0-nzlo"]  = {
          ["Version"] = "2021.3-intel-2021.5.0-nzlo",
          ["canonical"] = "2021.3-intel-2021.5.0-nzlo",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gromacs/2021.3-intel-2021.5.0-nzlo",
          ["help"] = [[
GROMACS (GROningen MAchine for Chemical Simulations) is a molecular
dynamics package primarily designed for simulations of proteins, lipids
and nucleic acids. It was originally developed in the Biophysical
Chemistry department of University of Groningen, and is now maintained
by contributors in universities and research centers across the world.
GROMACS is one of the fastest and most popular software packages
available and can run on CPUs as well as GPUs. It is free, open source
released under the GNU General Public License. Starting from version
4.6, GROMACS is released under the GNU Lesser General Public License.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000003.*intel.*zfinal-.000002021.000000005.*nzlo.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gromacs-2021.3-nzlo6u3fc6thzdpinlqzh2n242iyhcyz/bin"] = 1,
          },
          ["wV"] = "000002021.000000003.*intel.*zfinal-.000002021.000000005.*nzlo.*zfinal",
          whatis = {
            "GROMACS (GROningen MAchine for Chemical Simulations) is a molecular dynamics package primarily designed for simulations of proteins, lipids and nucleic acids. It was originally developed in the Biophysical Chemistry department of University of Groningen, and is now maintained by contributors in universities and research centers across the world. ",
          },
        },
        ["gromacs/2021.3-intel-2021.5.0-q6l3"]  = {
          ["Version"] = "2021.3-intel-2021.5.0-q6l3",
          ["canonical"] = "2021.3-intel-2021.5.0-q6l3",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gromacs/2021.3-intel-2021.5.0-q6l3",
          ["help"] = [[
GROMACS (GROningen MAchine for Chemical Simulations) is a molecular
dynamics package primarily designed for simulations of proteins, lipids
and nucleic acids. It was originally developed in the Biophysical
Chemistry department of University of Groningen, and is now maintained
by contributors in universities and research centers across the world.
GROMACS is one of the fastest and most popular software packages
available and can run on CPUs as well as GPUs. It is free, open source
released under the GNU General Public License. Starting from version
4.6, GROMACS is released under the GNU Lesser General Public License.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000003.*intel.*zfinal-.000002021.000000005.*q.000000006.*l.000000003.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gromacs-2021.3-q6l3wy2ynlnd7xhw3tr3tzscnmx6czb2/bin"] = 1,
          },
          ["wV"] = "000002021.000000003.*intel.*zfinal-.000002021.000000005.*q.000000006.*l.000000003.*zfinal",
          whatis = {
            "GROMACS (GROningen MAchine for Chemical Simulations) is a molecular dynamics package primarily designed for simulations of proteins, lipids and nucleic acids. It was originally developed in the Biophysical Chemistry department of University of Groningen, and is now maintained by contributors in universities and research centers across the world. ",
          },
        },
        ["gromacs/2022.2-gcc-11.2.0-kf72"]  = {
          ["Version"] = "2022.2-gcc-11.2.0-kf72",
          ["canonical"] = "2022.2-gcc-11.2.0-kf72",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/gromacs/2022.2-gcc-11.2.0-kf72",
          ["help"] = [[
GROMACS (GROningen MAchine for Chemical Simulations) is a molecular
dynamics package primarily designed for simulations of proteins, lipids
and nucleic acids. It was originally developed in the Biophysical
Chemistry department of University of Groningen, and is now maintained
by contributors in universities and research centers across the world.
GROMACS is one of the fastest and most popular software packages
available and can run on CPUs as well as GPUs. It is free, open source
released under the GNU General Public License. Starting from version
4.6, GROMACS is released under the GNU Lesser General Public License.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002022.000000002.*gcc.*zfinal-.000000011.000000002.*kf.000000072.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/gromacs-2022.2-kf72qx3xic2dsiocplixtv57wnbgwilb/bin"] = 1,
          },
          ["wV"] = "000002022.000000002.*gcc.*zfinal-.000000011.000000002.*kf.000000072.*zfinal",
          whatis = {
            "GROMACS (GROningen MAchine for Chemical Simulations) is a molecular dynamics package primarily designed for simulations of proteins, lipids and nucleic acids. It was originally developed in the Biophysical Chemistry department of University of Groningen, and is now maintained by contributors in universities and research centers across the world. ",
          },
        },
      },
    },
    hmmer = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hmmer/3.3.2-intel-2021.3.0-roye"]  = {
          ["Version"] = "3.3.2-intel-2021.3.0-roye",
          ["canonical"] = "3.3.2-intel-2021.3.0-roye",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/hmmer/3.3.2-intel-2021.3.0-roye",
          ["help"] = [[
HMMER is used for searching sequence databases for sequence homologs,
and for making sequence alignments. It implements methods using
probabilistic models called profile hidden Markov models (profile HMMs).

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000003.000000002.*intel.*zfinal-.000002021.000000003.*roye.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/hmmer-3.3.2-royejw4eemdogfsebdefwuobj5voww6w/bin"] = 1,
          },
          ["wV"] = "000000003.000000003.000000002.*intel.*zfinal-.000002021.000000003.*roye.*zfinal",
          whatis = {
            "HMMER is used for searching sequence databases for sequence homologs, and for making sequence alignments. It implements methods using probabilistic models called profile hidden Markov models (profile HMMs).  ",
          },
        },
      },
    },
    hpctoolkit = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hpctoolkit/2021.10.15-gcc-11.2.0-bc7h"]  = {
          ["Version"] = "2021.10.15-gcc-11.2.0-bc7h",
          ["canonical"] = "2021.10.15-gcc-11.2.0-bc7h",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/hpctoolkit/2021.10.15-gcc-11.2.0-bc7h",
          ["help"] = [[
HPCToolkit is an integrated suite of tools for measurement and analysis
of program performance on computers ranging from multicore desktop
systems to the nation's largest supercomputers. By using statistical
sampling of timers and hardware performance counters, HPCToolkit
collects accurate measurements of a program's work, resource
consumption, and inefficiency and attributes them to the full calling
context in which they occur.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000010.000000015.*gcc.*zfinal-.000000011.000000002.*bc.000000007.*h.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/hpctoolkit-2021.10.15-bc7hcoxveojuflk2qrymfzeglpk7wwus/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/hpcviewer-2021.10-ayxvrngmsvijpus54kuv3gsuab7crd6y/bin"] = 1,
          },
          ["wV"] = "000002021.000000010.000000015.*gcc.*zfinal-.000000011.000000002.*bc.000000007.*h.*zfinal",
          whatis = {
            "HPCToolkit is an integrated suite of tools for measurement and analysis of program performance on computers ranging from multicore desktop systems to the nation's largest supercomputers. By using statistical sampling of timers and hardware performance counters, HPCToolkit collects accurate measurements of a program's work, resource consumption, and inefficiency and attributes them to the full calling context in which they occur. ",
          },
        },
      },
    },
    ["intel-mpi-benchmarks"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["intel-mpi-benchmarks/2019.6-intel-2021.4.0-7k5r"]  = {
          ["Version"] = "2019.6-intel-2021.4.0-7k5r",
          ["canonical"] = "2019.6-intel-2021.4.0-7k5r",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-mpi-benchmarks/2019.6-intel-2021.4.0-7k5r",
          ["help"] = [[
Intel MPI Benchmarks provides a set of elementary benchmarks that
conform to MPI-1, MPI-2, and MPI-3 standard. You can run all of the
supported benchmarks, or a subset specified in the command line using
one executable file. Use command-line parameters to specify various
settings, such as time measurement, message lengths, and selection of
communicators. LICENSE INFORMATION: By downloading and using this
software, you agree to the terms and conditions of the software license
agreements at https://intel.ly/393CijO.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002019.000000006.*intel.*zfinal-.000002021.000000004.*zfinal-.000000007.*k.000000005.*r.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/intel-mpi-benchmarks-2019.6-7k5r3mdvmb7ywnbd4zi6c3e36wrbot6a/bin"] = 1,
          },
          ["wV"] = "000002019.000000006.*intel.*zfinal-.000002021.000000004.*zfinal-.000000007.*k.000000005.*r.*zfinal",
          whatis = {
            "Intel MPI Benchmarks provides a set of elementary benchmarks that conform to MPI-1, MPI-2, and MPI-3 standard. You can run all of the supported benchmarks, or a subset specified in the command line using one executable file. Use command-line parameters to specify various settings, such as time measurement, message lengths, and selection of communicators. ",
          },
        },
      },
    },
    ["intel-oneapi-advisor"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["intel-oneapi-advisor/2022.1.0-gcc-12.1.0-hgz6"]  = {
          ["Version"] = "2022.1.0-gcc-12.1.0-hgz6",
          ["canonical"] = "2022.1.0-gcc-12.1.0-hgz6",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-advisor/2022.1.0-gcc-12.1.0-hgz6",
          ["help"] = [[
Intel Advisor is a design and analysis tool for developing performant
code. The tool supports C, C++, Fortran, SYCL, OpenMP, OpenCL code, and
Python. It helps with the following: Performant CPU Code: Design your
application for efficient threading, vectorization, and memory use.
Efficient GPU Offload: Identify parts of the code that can be profitably
offloaded. Optimize the code for compute and memory. LICENSE
INFORMATION: By downloading and using this software, you agree to the
terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gmp-6.2.1-eihf6ztg3gg3f7l6affxhm2ng66eihpc/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/mpfr-4.1.0-vuqckfxnngbe3drkn5jtuxixvinltikp/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/zlib-1.2.11-bgxxyd6g6x3rcxm5r5es7ni6ijv62dnk/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002022.000000001.*gcc.*zfinal-.000000012.000000001.*hgz.000000006.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-advisor-2022.1.0-hgz6ktlbzdmlgj4vr6gmaiyht22hww5j/advisor/2022.1.0/bin64"] = 1,
          },
          ["wV"] = "000002022.000000001.*gcc.*zfinal-.000000012.000000001.*hgz.000000006.*zfinal",
          whatis = {
            "Intel Advisor is a design and analysis tool for developing performant code. The tool supports C, C++, Fortran, SYCL, OpenMP, OpenCL code, and Python. It helps with the following: Performant CPU Code: Design your application for efficient threading, vectorization, and memory use. Efficient GPU Offload: Identify parts of the code that can be profitably offloaded. Optimize the code for compute and memory. ",
          },
        },
      },
    },
    ["intel-oneapi-compilers"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["intel-oneapi-compilers/2021.2.0-gcc-11.2.0-dc7u"]  = {
          ["Version"] = "2021.2.0-gcc-11.2.0-dc7u",
          ["canonical"] = "2021.2.0-gcc-11.2.0-dc7u",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-compilers/2021.2.0-gcc-11.2.0-dc7u",
          ["help"] = [[
Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and
dpcpp. LICENSE INFORMATION: By downloading and using this software, you
agree to the terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/compiler/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/lib/emu"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/lib/oclfpga/host/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/lib/oclfpga/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/lib/x64"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000002.*gcc.*zfinal-.000000011.000000002.*dc.000000007.*u.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/bin/intel64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/ioc/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/lib/oclfpga/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.2.0-dc7udtmucyksbo6ylmde52qsejymlcfd/compiler/2021.2.0/linux/lib/oclfpga/llvm/aocl-bin"] = 1,
          },
          ["wV"] = "000002021.000000002.*gcc.*zfinal-.000000011.000000002.*dc.000000007.*u.*zfinal",
          whatis = {
            "Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and dpcpp. ",
          },
        },
        ["intel-oneapi-compilers/2021.3.0-gcc-11.2.0-zgrp"]  = {
          ["Version"] = "2021.3.0-gcc-11.2.0-zgrp",
          ["canonical"] = "2021.3.0-gcc-11.2.0-zgrp",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-compilers/2021.3.0-gcc-11.2.0-zgrp",
          ["help"] = [[
Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and
dpcpp. LICENSE INFORMATION: By downloading and using this software, you
agree to the terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/lib/emu"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/lib/oclfpga/host/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/lib/oclfpga/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/lib/x64"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000003.*gcc.*zfinal-.000000011.000000002.*zgrp.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/bin/intel64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/lib/oclfpga/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.3.0-zgrpvbjtxpaxbwzeaug2p62in422exav/compiler/2021.3.0/linux/lib/oclfpga/llvm/aocl-bin"] = 1,
          },
          ["wV"] = "000002021.000000003.*gcc.*zfinal-.000000011.000000002.*zgrp.*zfinal",
          whatis = {
            "Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and dpcpp. ",
          },
        },
        ["intel-oneapi-compilers/2021.4.0-gcc-11.2.0-forr"]  = {
          ["Version"] = "2021.4.0-gcc-11.2.0-forr",
          ["canonical"] = "2021.4.0-gcc-11.2.0-forr",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-compilers/2021.4.0-gcc-11.2.0-forr",
          ["help"] = [[
Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and
dpcpp. LICENSE INFORMATION: By downloading and using this software, you
agree to the terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/lib/emu"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/lib/oclfpga/host/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/lib/oclfpga/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/lib/x64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gmp-6.2.1-eihf6ztg3gg3f7l6affxhm2ng66eihpc/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/mpfr-4.1.0-vuqckfxnngbe3drkn5jtuxixvinltikp/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/zlib-1.2.11-bgxxyd6g6x3rcxm5r5es7ni6ijv62dnk/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000004.*gcc.*zfinal-.000000011.000000002.*forr.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/bin/intel64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/lib/oclfpga/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2021.4.0-forrfki5kx4443icsimv6iyig7h3o3tu/compiler/2021.4.0/linux/lib/oclfpga/llvm/aocl-bin"] = 1,
          },
          ["wV"] = "000002021.000000004.*gcc.*zfinal-.000000011.000000002.*forr.*zfinal",
          whatis = {
            "Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and dpcpp. ",
          },
        },
        ["intel-oneapi-compilers/2022.0.1-gcc-11.2.0-ksra"]  = {
          ["Version"] = "2022.0.1-gcc-11.2.0-ksra",
          ["canonical"] = "2022.0.1-gcc-11.2.0-ksra",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-compilers/2022.0.1-gcc-11.2.0-ksra",
          ["help"] = [[
Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and
dpcpp. LICENSE INFORMATION: By downloading and using this software, you
agree to the terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2022.0.1-ksraq7ruceaa3h4wpxe5q34s6o25kl6m/compiler/2022.0.1/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2022.0.1-ksraq7ruceaa3h4wpxe5q34s6o25kl6m/compiler/2022.0.1/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2022.0.1-ksraq7ruceaa3h4wpxe5q34s6o25kl6m/compiler/2022.0.1/linux/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2022.0.1-ksraq7ruceaa3h4wpxe5q34s6o25kl6m/compiler/2022.0.1/linux/lib/oclfpga/host/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2022.0.1-ksraq7ruceaa3h4wpxe5q34s6o25kl6m/compiler/2022.0.1/linux/lib/x64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gmp-6.2.1-eihf6ztg3gg3f7l6affxhm2ng66eihpc/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/mpfr-4.1.0-vuqckfxnngbe3drkn5jtuxixvinltikp/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/zlib-1.2.11-bgxxyd6g6x3rcxm5r5es7ni6ijv62dnk/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002022.000000000.000000001.*gcc.*zfinal-.000000011.000000002.*ksra.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2022.0.1-ksraq7ruceaa3h4wpxe5q34s6o25kl6m/compiler/2022.0.1/linux/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2022.0.1-ksraq7ruceaa3h4wpxe5q34s6o25kl6m/compiler/2022.0.1/linux/bin/intel64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-oneapi-compilers-2022.0.1-ksraq7ruceaa3h4wpxe5q34s6o25kl6m/compiler/2022.0.1/linux/lib/oclfpga/bin"] = 1,
          },
          ["wV"] = "000002022.000000000.000000001.*gcc.*zfinal-.000000011.000000002.*ksra.*zfinal",
          whatis = {
            "Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and dpcpp. ",
          },
        },
        ["intel-oneapi-compilers/2022.1.0-gcc-12.1.0-sooe"]  = {
          ["Version"] = "2022.1.0-gcc-12.1.0-sooe",
          ["canonical"] = "2022.1.0-gcc-12.1.0-sooe",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-compilers/2022.1.0-gcc-12.1.0-sooe",
          ["help"] = [[
Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and
dpcpp. LICENSE INFORMATION: By downloading and using this software, you
agree to the terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-compilers-2022.1.0-sooevvg73mbweikfayat5zcoojpghp3r/compiler/2022.1.0/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-compilers-2022.1.0-sooevvg73mbweikfayat5zcoojpghp3r/compiler/2022.1.0/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-compilers-2022.1.0-sooevvg73mbweikfayat5zcoojpghp3r/compiler/2022.1.0/linux/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-compilers-2022.1.0-sooevvg73mbweikfayat5zcoojpghp3r/compiler/2022.1.0/linux/lib/oclfpga/host/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-compilers-2022.1.0-sooevvg73mbweikfayat5zcoojpghp3r/compiler/2022.1.0/linux/lib/x64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gmp-6.2.1-eihf6ztg3gg3f7l6affxhm2ng66eihpc/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/mpfr-4.1.0-vuqckfxnngbe3drkn5jtuxixvinltikp/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/zlib-1.2.11-bgxxyd6g6x3rcxm5r5es7ni6ijv62dnk/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002022.000000001.*gcc.*zfinal-.000000012.000000001.*sooe.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-compilers-2022.1.0-sooevvg73mbweikfayat5zcoojpghp3r/compiler/2022.1.0/linux/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-compilers-2022.1.0-sooevvg73mbweikfayat5zcoojpghp3r/compiler/2022.1.0/linux/bin/intel64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-compilers-2022.1.0-sooevvg73mbweikfayat5zcoojpghp3r/compiler/2022.1.0/linux/lib/oclfpga/bin"] = 1,
          },
          ["wV"] = "000002022.000000001.*gcc.*zfinal-.000000012.000000001.*sooe.*zfinal",
          whatis = {
            "Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and dpcpp. ",
          },
        },
        ["intel-oneapi-compilers/2023.1.0-gcc-12.2.0-rno6"]  = {
          ["Version"] = "2023.1.0-gcc-12.2.0-rno6",
          ["canonical"] = "2023.1.0-gcc-12.2.0-rno6",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-compilers/2023.1.0-gcc-12.2.0-rno6",
          ["help"] = [[
Name   : intel-oneapi-compilers
Version: 2023.1.0
Target : cascadelake

Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and
dpcpp. LICENSE INFORMATION: By downloading and using this software, you
agree to the terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/hwloc-2.8.0-yz4yv3ud7ick5sakpqrqoxa755wuu5vh/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/intel-oneapi-compilers-2023.1.0-rno6xxjxsveerzexprsdicfmt3gy3sgu/compiler/2023.1.0/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/intel-oneapi-compilers-2023.1.0-rno6xxjxsveerzexprsdicfmt3gy3sgu/compiler/2023.1.0/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/intel-oneapi-compilers-2023.1.0-rno6xxjxsveerzexprsdicfmt3gy3sgu/compiler/2023.1.0/linux/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/intel-oneapi-compilers-2023.1.0-rno6xxjxsveerzexprsdicfmt3gy3sgu/compiler/2023.1.0/linux/lib/oclfpga/host/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/intel-oneapi-compilers-2023.1.0-rno6xxjxsveerzexprsdicfmt3gy3sgu/compiler/2023.1.0/linux/lib/x64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/krb5-1.19.3-mzie5i5glxdsq6k26cbkesa7r6jlb77y/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/libedit-3.1-20210216-r743mlz6sclwxildanxv5dnystavb2og/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/libevent-2.1.12-7uh2gvxp56ycilfxzyujmvnejrwrogsl/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/libpciaccess-0.16-vh3kq6xvgmctaessoil2qvzwr6czxrea/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/libxml2-2.10.1-pnzuzyutntkqb6cgg6ppzrkxg5gcjxok/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/ncurses-6.3-se4lskjg4fn6k7y4qjgt225mld7mhmrp/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/numactl-2.0.14-4tsisqha5dwa4p3xm6oif2qjsoomgpif/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/pmix-4.1.2-l4sbutpdabghisehy56jiavo6kxyb2mg/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/readline-8.1.2-5hrwkuebdlfy4j5bbjqz6pszwb4oa6og/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/xz-5.2.5-4fogg22ofsoxn2fbw2mlvsi35svir75f/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/zlib-1.2.12-xbkxnrrvvva6oz7x6r7aqe7kyo4neamc/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/gmp-6.2.1-bob4mtlt3qfr3op3bbcci5ilx5hwqgie/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/isl-0.24-vf6c3wye2uqglreqof26se2rxfrsoplu/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/mpfr-4.1.0-wuegb5xgxri4fl6x54qe3crvtjgsepth/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/ncurses-6.2-vrqk3yes72bluktyrlhwywkurdqxw4oo/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/pkgconf-1.8.0-jfxue7nuw7t7kzqvkc7tykaqh37nckti/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/readline-8.1-vgl5aoksjq5zgnrhalj3xczfcfd5ytpy/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/zlib-1.2.11-kpcoxtpwrosnfihvjpijrbdzj4wkthv6/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/zstd-1.5.0-kqt7lf7twmboa6obvwwz7fxvuirdgp4t/lib"] = 1,
            ["/home/samir/miniconda3/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002023.000000001.*gcc.*zfinal-.000000012.000000002.*rno.000000006.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/intel-oneapi-compilers-2023.1.0-rno6xxjxsveerzexprsdicfmt3gy3sgu/compiler/2023.1.0/linux/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/intel-oneapi-compilers-2023.1.0-rno6xxjxsveerzexprsdicfmt3gy3sgu/compiler/2023.1.0/linux/bin/intel64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.2.0/intel-oneapi-compilers-2023.1.0-rno6xxjxsveerzexprsdicfmt3gy3sgu/compiler/2023.1.0/linux/lib/oclfpga/bin"] = 1,
          },
          ["wV"] = "000002023.000000001.*gcc.*zfinal-.000000012.000000002.*rno.000000006.*zfinal",
          whatis = {
            "Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and dpcpp. ",
          },
        },
      },
    },
    ["intel-oneapi-mkl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["intel-oneapi-mkl/2022.1.0-intel-2021.4.0-lyyx"]  = {
          ["Version"] = "2022.1.0-intel-2021.4.0-lyyx",
          ["canonical"] = "2022.1.0-intel-2021.4.0-lyyx",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-mkl/2022.1.0-intel-2021.4.0-lyyx",
          ["help"] = [[
Intel oneAPI Math Kernel Library (Intel oneMKL; formerly Intel Math
Kernel Library or Intel MKL), is a library of optimized math routines
for science, engineering, and financial applications. Core math
functions include BLAS, LAPACK, ScaLAPACK, sparse solvers, fast Fourier
transforms, and vector math. LICENSE INFORMATION: By downloading and
using this software, you agree to the terms and conditions of the
software license agreements at https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/intel-oneapi-mkl-2022.1.0-lyyxttlru55aw5cr6pav7xj7bnscyzmo/mkl/2022.1.0/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/intel-oneapi-mkl-2022.1.0-lyyxttlru55aw5cr6pav7xj7bnscyzmo/mkl/2022.1.0/lib/intel64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gmp-6.2.1-eihf6ztg3gg3f7l6affxhm2ng66eihpc/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/mpfr-4.1.0-vuqckfxnngbe3drkn5jtuxixvinltikp/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/zlib-1.2.11-bgxxyd6g6x3rcxm5r5es7ni6ijv62dnk/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002022.000000001.*intel.*zfinal-.000002021.000000004.*lyyx.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/intel-oneapi-mkl-2022.1.0-lyyxttlru55aw5cr6pav7xj7bnscyzmo/mkl/2022.1.0/bin/intel64"] = 1,
          },
          ["wV"] = "000002022.000000001.*intel.*zfinal-.000002021.000000004.*lyyx.*zfinal",
          whatis = {
            "Intel oneAPI Math Kernel Library (Intel oneMKL; formerly Intel Math Kernel Library or Intel MKL), is a library of optimized math routines for science, engineering, and financial applications. Core math functions include BLAS, LAPACK, ScaLAPACK, sparse solvers, fast Fourier transforms, and vector math. ",
          },
        },
      },
    },
    ["intel-oneapi-vtune"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["intel-oneapi-vtune/2021.7.1-intel-2021.4.0-kxbz"]  = {
          ["Version"] = "2021.7.1-intel-2021.4.0-kxbz",
          ["canonical"] = "2021.7.1-intel-2021.4.0-kxbz",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-vtune/2021.7.1-intel-2021.4.0-kxbz",
          ["help"] = [[
Intel VTune Profiler is a profiler to optimize application performance,
system performance, and system configuration for HPC, cloud, IoT, media,
storage, and more. CPU, GPU, and FPGA: Tune the entire application's
performance--not just the accelerated portion. Multilingual: Profile
SYCL, C, C++, C#, Fortran, OpenCL code, Python, Google Go programming
language, Java, .NET, Assembly, or any combination of languages. System
or Application: Get coarse-grained system data for an extended period or
detailed results mapped to source code. Power: Optimize performance
while avoiding power and thermal-related throttling. LICENSE
INFORMATION: By downloading and using this software, you agree to the
terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gmp-6.2.1-eihf6ztg3gg3f7l6affxhm2ng66eihpc/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/mpfr-4.1.0-vuqckfxnngbe3drkn5jtuxixvinltikp/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/zlib-1.2.11-bgxxyd6g6x3rcxm5r5es7ni6ijv62dnk/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002021.000000007.000000001.*intel.*zfinal-.000002021.000000004.*kxbz.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/intel-oneapi-vtune-2021.7.1-kxbzfdnurm4vxuoanyystyczpzxp4hsl/vtune/2021.7.1/bin64"] = 1,
          },
          ["wV"] = "000002021.000000007.000000001.*intel.*zfinal-.000002021.000000004.*kxbz.*zfinal",
          whatis = {
            "Intel VTune Profiler is a profiler to optimize application performance, system performance, and system configuration for HPC, cloud, IoT, media, storage, and more. CPU, GPU, and FPGA: Tune the entire application's performance--not just the accelerated portion. Multilingual: Profile SYCL, C, C++, C#, Fortran, OpenCL code, Python, Google Go programming language, Java, .NET, Assembly, or any combination of languages. System or Application: Get coarse-grained system data for an extended period or detailed results mapped to source code. Power: Optimize performance while avoiding power and thermal-related throttling. ",
          },
        },
        ["intel-oneapi-vtune/2022.3.0-gcc-12.1.0-pdgi"]  = {
          ["Version"] = "2022.3.0-gcc-12.1.0-pdgi",
          ["canonical"] = "2022.3.0-gcc-12.1.0-pdgi",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/intel-oneapi-vtune/2022.3.0-gcc-12.1.0-pdgi",
          ["help"] = [[
Intel VTune Profiler is a profiler to optimize application performance,
system performance, and system configuration for HPC, cloud, IoT, media,
storage, and more. CPU, GPU, and FPGA: Tune the entire application's
performance--not just the accelerated portion. Multilingual: Profile
SYCL, C, C++, C#, Fortran, OpenCL code, Python, Google Go programming
language, Java, .NET, Assembly, or any combination of languages. System
or Application: Get coarse-grained system data for an extended period or
detailed results mapped to source code. Power: Optimize performance
while avoiding power and thermal-related throttling. LICENSE
INFORMATION: By downloading and using this software, you agree to the
terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gmp-6.2.1-eihf6ztg3gg3f7l6affxhm2ng66eihpc/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/mpfr-4.1.0-vuqckfxnngbe3drkn5jtuxixvinltikp/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/zlib-1.2.11-bgxxyd6g6x3rcxm5r5es7ni6ijv62dnk/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002022.000000003.*gcc.*zfinal-.000000012.000000001.*dgi.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-12.1.0/intel-oneapi-vtune-2022.3.0-pdgi7t6kriexgzc4qnyq5ljmxoz5vbut/vtune/2022.3.0/bin64"] = 1,
          },
          ["wV"] = "000002022.000000003.*gcc.*zfinal-.000000012.000000001.*dgi.*zfinal",
          whatis = {
            "Intel VTune Profiler is a profiler to optimize application performance, system performance, and system configuration for HPC, cloud, IoT, media, storage, and more. CPU, GPU, and FPGA: Tune the entire application's performance--not just the accelerated portion. Multilingual: Profile SYCL, C, C++, C#, Fortran, OpenCL code, Python, Google Go programming language, Java, .NET, Assembly, or any combination of languages. System or Application: Get coarse-grained system data for an extended period or detailed results mapped to source code. Power: Optimize performance while avoiding power and thermal-related throttling. ",
          },
        },
      },
    },
    lammps = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["lammps/20210310-intel-2021.3.0-vp4d"]  = {
          ["Version"] = "20210310-intel-2021.3.0-vp4d",
          ["canonical"] = "20210310-intel-2021.3.0-vp4d",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/lammps/20210310-intel-2021.3.0-vp4d",
          ["help"] = [[
LAMMPS stands for Large-scale Atomic/Molecular Massively Parallel
Simulator. This package uses patch releases, not stable release. See
https://github.com/spack/spack/pull/5342 for a detailed discussion.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "020210310.*intel.*zfinal-.000002021.000000003.*vp.000000004.*d.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/lammps-20210310-vp4dy2kqcu7dwxfyrrizctqhxa35z64u/bin"] = 1,
          },
          ["wV"] = "020210310.*intel.*zfinal-.000002021.000000003.*vp.000000004.*d.*zfinal",
          whatis = {
            "LAMMPS stands for Large-scale Atomic/Molecular Massively Parallel Simulator. This package uses patch releases, not stable release. See https://github.com/spack/spack/pull/5342 for a detailed discussion.  ",
          },
        },
      },
    },
    libiberty = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["libiberty/2.33.1-gcc-10.3.0-awju"]  = {
          ["Version"] = "2.33.1-gcc-10.3.0-awju",
          ["canonical"] = "2.33.1-gcc-10.3.0-awju",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/libiberty/2.33.1-gcc-10.3.0-awju",
          ["help"] = [[
The libiberty.a library from GNU binutils. Libiberty provides demangling
and support functions for the GNU toolchain.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000033.000000001.*gcc.*zfinal-.000000010.000000003.*awju.*zfinal",
          ["wV"] = "000000002.000000033.000000001.*gcc.*zfinal-.000000010.000000003.*awju.*zfinal",
          whatis = {
            "The libiberty.a library from GNU binutils. Libiberty provides demangling and support functions for the GNU toolchain. ",
          },
        },
      },
    },
    likwid = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["likwid/5.2.0-gcc-11.2.0-3oz6"]  = {
          ["Version"] = "5.2.0-gcc-11.2.0-3oz6",
          ["canonical"] = "5.2.0-gcc-11.2.0-3oz6",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/likwid/5.2.0-gcc-11.2.0-3oz6",
          ["help"] = [[
Likwid is a simple to install and use toolsuite of command line
applications for performance oriented programmers. It works for Intel
and AMD processors on the Linux operating system. This version uses the
perf_event backend which reduces the feature set but allows user
installs. See https://github.com/RRZE-
HPC/likwid/wiki/TutorialLikwidPerf#feature-limitations for information.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000005.000000002.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000003.*oz.000000006.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/likwid-5.2.0-3oz6bub6fblcpuqrlu3ml56llhy3h34q/bin"] = 1,
          },
          ["wV"] = "000000005.000000002.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000003.*oz.000000006.*zfinal",
          whatis = {
            "Likwid is a simple to install and use toolsuite of command line applications for performance oriented programmers. It works for Intel and AMD processors on the Linux operating system. This version uses the perf_event backend which reduces the feature set but allows user installs. See https://github.com/RRZE-HPC/likwid/wiki/TutorialLikwidPerf#feature-limitations for information. ",
          },
        },
      },
    },
    llvm = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["llvm/13.0.0-gcc-11.2.0-66oj"]  = {
          ["Version"] = "13.0.0-gcc-11.2.0-66oj",
          ["canonical"] = "13.0.0-gcc-11.2.0-66oj",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/llvm/13.0.0-gcc-11.2.0-66oj",
          ["help"] = [[
The LLVM Project is a collection of modular and reusable compiler and
toolchain technologies. Despite its name, LLVM has little to do with
traditional virtual machines, though it does provide helpful libraries

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000013.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000066.*oj.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/llvm-13.0.0-66ojqcqbosl54el7cfn7bnuyyvys5wxy/bin"] = 1,
          },
          ["wV"] = "000000013.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000066.*oj.*zfinal",
          whatis = {
            "The LLVM Project is a collection of modular and reusable compiler and toolchain technologies. Despite its name, LLVM has little to do with traditional virtual machines, though it does provide helpful libraries that can be used to build them. The name 'LLVM' itself is not an acronym; it is the full name of the project.  ",
          },
        },
        ["llvm/13.0.0-gcc-11.2.0-wvk6"]  = {
          ["Version"] = "13.0.0-gcc-11.2.0-wvk6",
          ["canonical"] = "13.0.0-gcc-11.2.0-wvk6",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/llvm/13.0.0-gcc-11.2.0-wvk6",
          ["help"] = [[
The LLVM Project is a collection of modular and reusable compiler and
toolchain technologies. Despite its name, LLVM has little to do with
traditional virtual machines, though it does provide helpful libraries

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000013.*gcc.*zfinal-.000000011.000000002.*wvk.000000006.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/llvm-13.0.0-wvk6u5fvhgjsh4q7ngl5hr2e3c4satp2/bin"] = 1,
          },
          ["wV"] = "000000013.*gcc.*zfinal-.000000011.000000002.*wvk.000000006.*zfinal",
          whatis = {
            "The LLVM Project is a collection of modular and reusable compiler and toolchain technologies. Despite its name, LLVM has little to do with traditional virtual machines, though it does provide helpful libraries that can be used to build them. The name 'LLVM' itself is not an acronym; it is the full name of the project.  ",
          },
        },
      },
    },
    lustre = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["lustre/2.12-gcc-12.2.0-t2bm"]  = {
          ["Version"] = "2.12-gcc-12.2.0-t2bm",
          ["canonical"] = "2.12-gcc-12.2.0-t2bm",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/lustre/2.12-gcc-12.2.0-t2bm",
          ["help"] = [[
Name   : lustre
Version: 2.12
Target : cascadelake

Lustre is a type of parallel distributed file system, generally used for
large-scale cluster computing.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000012.*gcc.*zfinal-.000000012.000000002.*t.000000002.*bm.*zfinal",
          ["wV"] = "000000002.000000012.*gcc.*zfinal-.000000012.000000002.*t.000000002.*bm.*zfinal",
          whatis = {
            "Lustre is a type of parallel distributed file system, generally used for large-scale cluster computing. ",
          },
        },
      },
    },
    meme = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["meme/5.3.0-gcc-11.2.0-fqph"]  = {
          ["Version"] = "5.3.0-gcc-11.2.0-fqph",
          ["canonical"] = "5.3.0-gcc-11.2.0-fqph",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/meme/5.3.0-gcc-11.2.0-fqph",
          ["help"] = [[
The MEME Suite allows the biologist to discover novel motifs in
collections of unaligned nucleotide or protein sequences, and to perform
a wide variety of other motif-based analyses.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000005.000000003.*gcc.*zfinal-.000000011.000000002.*fqph.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/meme-5.3.0-fqphh2pu73alyjqqbc4b5crqosru22pl/bin"] = 1,
          },
          ["wV"] = "000000005.000000003.*gcc.*zfinal-.000000011.000000002.*fqph.*zfinal",
          whatis = {
            "The MEME Suite allows the biologist to discover novel motifs in collections of unaligned nucleotide or protein sequences, and to perform a wide variety of other motif-based analyses. ",
          },
        },
      },
    },
    mpich = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mpich/3.4.2-intel-2021.3.0-coye"]  = {
          ["Version"] = "3.4.2-intel-2021.3.0-coye",
          ["canonical"] = "3.4.2-intel-2021.3.0-coye",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/mpich/3.4.2-intel-2021.3.0-coye",
          ["help"] = [[
MPICH is a high performance and widely portable implementation of the
Message Passing Interface (MPI) standard.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/mpich-3.4.2-coyeghirzar2zfkhlpcchqfoz45amwgf/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000004.000000002.*intel.*zfinal-.000002021.000000003.*coye.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/mpich-3.4.2-coyeghirzar2zfkhlpcchqfoz45amwgf/bin"] = 1,
          },
          ["wV"] = "000000003.000000004.000000002.*intel.*zfinal-.000002021.000000003.*coye.*zfinal",
          whatis = {
            "MPICH is a high performance and widely portable implementation of the Message Passing Interface (MPI) standard. ",
          },
        },
        ["mpich/4.0.2-gcc-11.2.0-qvpy"]  = {
          ["Version"] = "4.0.2-gcc-11.2.0-qvpy",
          ["canonical"] = "4.0.2-gcc-11.2.0-qvpy",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/mpich/4.0.2-gcc-11.2.0-qvpy",
          ["help"] = [[
MPICH is a high performance and widely portable implementation of the
Message Passing Interface (MPI) standard.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/mpich-4.0.2-qvpyrwd6h6atzikwrlchu6ael3vpst6g/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000004.000000000.000000002.*gcc.*zfinal-.000000011.000000002.*qvpy.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/mpich-4.0.2-qvpyrwd6h6atzikwrlchu6ael3vpst6g/bin"] = 1,
          },
          ["wV"] = "000000004.000000000.000000002.*gcc.*zfinal-.000000011.000000002.*qvpy.*zfinal",
          whatis = {
            "MPICH is a high performance and widely portable implementation of the Message Passing Interface (MPI) standard. ",
          },
        },
      },
    },
    namd = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["namd/2.14-gcc-11.2.0-rzlo"]  = {
          ["Version"] = "2.14-gcc-11.2.0-rzlo",
          ["canonical"] = "2.14-gcc-11.2.0-rzlo",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/namd/2.14-gcc-11.2.0-rzlo",
          ["help"] = [[
NAMD is a parallel molecular dynamics code designed for high-performance
simulation of large biomolecular systems.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000014.*gcc.*zfinal-.000000011.000000002.*rzlo.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/namd-2.14-rzlo2u7ydmrjfdjth5au2ladr4s7oyxa/bin"] = 1,
          },
          ["wV"] = "000000002.000000014.*gcc.*zfinal-.000000011.000000002.*rzlo.*zfinal",
          whatis = {
            "NAMD is a parallel molecular dynamics code designed for high-performance simulation of large biomolecular systems. ",
          },
        },
      },
    },
    ncview = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ncview/2.1.8-gcc-11.2.0-yr5r"]  = {
          ["Version"] = "2.1.8-gcc-11.2.0-yr5r",
          ["canonical"] = "2.1.8-gcc-11.2.0-yr5r",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/ncview/2.1.8-gcc-11.2.0-yr5r",
          ["help"] = [[
Simple viewer for NetCDF files.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000001.000000008.*gcc.*zfinal-.000000011.000000002.*yr.000000005.*r.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/ncview-2.1.8-yr5rpqgzmam225gvnv3gwfcuhezdo6rd/bin"] = 1,
          },
          ["wV"] = "000000002.000000001.000000008.*gcc.*zfinal-.000000011.000000002.*yr.000000005.*r.*zfinal",
          whatis = {
            "Simple viewer for NetCDF files. ",
          },
        },
      },
    },
    nemsio = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["nemsio/2.5.2-intel-2021.3.0-tplw"]  = {
          ["Version"] = "2.5.2-intel-2021.3.0-tplw",
          ["canonical"] = "2.5.2-intel-2021.3.0-tplw",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/nemsio/2.5.2-intel-2021.3.0-tplw",
          ["help"] = [[
The NOAA Environmental Modeling System I/O (NEMSIO) library. The basic
functions it provides are to read and write data sets for all the NEMS
applications. This is part of NOAA's NCEPLIBS project.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000005.000000002.*intel.*zfinal-.000002021.000000003.*tplw.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/nemsio-2.5.2-tplwn7f7thb76fzectg73kbl7x5iuczz/bin"] = 1,
          },
          ["wV"] = "000000002.000000005.000000002.*intel.*zfinal-.000002021.000000003.*tplw.*zfinal",
          whatis = {
            "The NOAA Environmental Modeling System I/O (NEMSIO) library. The basic functions it provides are to read and write data sets for all the NEMS applications. ",
          },
        },
      },
    },
    nest = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["nest/3.0-gcc-11.2.0-ljmm"]  = {
          ["Version"] = "3.0-gcc-11.2.0-ljmm",
          ["canonical"] = "3.0-gcc-11.2.0-ljmm",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/nest/3.0-gcc-11.2.0-ljmm",
          ["help"] = [[
NEST is a simulator for spiking neural network models It focuses on the
dynamics, size and structure of neural systems rather than on the exact
morphology of individual neurons.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.*gcc.*zfinal-.000000011.000000002.*ljmm.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/nest-3.0-ljmmbpcwc67p4afxrg6x3na42hwkvf24/bin"] = 1,
          },
          ["wV"] = "000000003.*gcc.*zfinal-.000000011.000000002.*ljmm.*zfinal",
          whatis = {
            "NEST is a simulator for spiking neural network models ",
          },
        },
      },
    },
    nwchem = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["nwchem/7.0.2-intel-2021.3.0-deq5"]  = {
          ["Version"] = "7.0.2-intel-2021.3.0-deq5",
          ["canonical"] = "7.0.2-intel-2021.3.0-deq5",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/nwchem/7.0.2-intel-2021.3.0-deq5",
          ["help"] = [[
High-performance computational chemistry software

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000007.000000000.000000002.*intel.*zfinal-.000002021.000000003.*deq.000000005.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/nwchem-7.0.2-deq5wvlvropbxxgxbrnvhoktalam4wcu/bin"] = 1,
          },
          ["wV"] = "000000007.000000000.000000002.*intel.*zfinal-.000002021.000000003.*deq.000000005.*zfinal",
          whatis = {
            "High-performance computational chemistry software ",
          },
        },
      },
    },
    openfdtd = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openfdtd/2.6.0-intel-2021.3.0-hprc"]  = {
          ["Version"] = "2.6.0-intel-2021.3.0-hprc",
          ["canonical"] = "2.6.0-intel-2021.3.0-hprc",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/openfdtd/2.6.0-intel-2021.3.0-hprc",
          ["help"] = [[
OpenFDTD is general purpose FDTD simulator applicable to a wide range of
applications. The FDTD method (Finite Difference Time Domain method) is
a method for numerically calculating the Maxwell equation, which is the
basic equation of the electromagnetic field, by the difference method.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000006.*intel.*zfinal-.000002021.000000003.*hprc.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfdtd-2.6.0-hprcw2tk3rsx5yvca3b552kh4uf2h6az/bin"] = 1,
          },
          ["wV"] = "000000002.000000006.*intel.*zfinal-.000002021.000000003.*hprc.*zfinal",
          whatis = {
            "OpenFDTD is general purpose FDTD simulator applicable to a wide range of applications. The FDTD method (Finite Difference Time Domain method) is a method for numerically calculating the Maxwell equation, which is the basic equation of the electromagnetic field, by the difference method. ",
          },
        },
      },
    },
    openfoam = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openfoam/1912-gcc-11.2.0-3jrr"]  = {
          ["Version"] = "1912-gcc-11.2.0-3jrr",
          ["canonical"] = "1912-gcc-11.2.0-3jrr",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/openfoam/1912-gcc-11.2.0-3jrr",
          ["help"] = [[
OpenFOAM is a GPL-opensource C++ CFD-toolbox. This offering is supported
by OpenCFD Ltd, producer and distributor of the OpenFOAM software via
www.openfoam.com, and owner of the OPENFOAM trademark. OpenCFD Ltd has
been developing and releasing OpenFOAM since its debut in 2004.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/adios2-2.7.1-jdffgceskegfyppgd7sz5wscrlzejk4m/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/boost-1.77.0-vihsnory3sz5pmifxoed5vwhdnnnl7mz/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/cgal-4.13-aqfyq4sshlc757uqehybyf4yiwcm67sl/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-mpi-2019.10.317-r5sbvpwalgjzykz3erbhc7zem2izbbk6/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/openfoam-1912-3jrr44nshlwj2cwrlz4rnhqztf2diu7i/platforms/linux64GccDPInt32-spack/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/openfoam-1912-3jrr44nshlwj2cwrlz4rnhqztf2diu7i/platforms/linux64GccDPInt32-spack/lib/dummy"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/openfoam-1912-3jrr44nshlwj2cwrlz4rnhqztf2diu7i/platforms/linux64GccDPInt32-spack/lib/mpi-user"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/openfoam-1912-3jrr44nshlwj2cwrlz4rnhqztf2diu7i/site/1912/platforms/linux64GccDPInt32-spack/lib"] = 1,
            ["/home/samir/OpenFOAM/samir-v1912/platforms/linux64GccDPInt32-spack/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000001912.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000003.*jrr.*zfinal",
          pathA = {
            ["/home/apps/spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/adios2-2.7.1-jdffgceskegfyppgd7sz5wscrlzejk4m/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-mpi-2019.10.317-r5sbvpwalgjzykz3erbhc7zem2izbbk6/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-mpi-2019.10.317-r5sbvpwalgjzykz3erbhc7zem2izbbk6/compilers_and_libraries_2020.4.317/linux/mpi/intel64/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-mpi-2019.10.317-r5sbvpwalgjzykz3erbhc7zem2izbbk6/compilers_and_libraries_2020.4.317/linux/mpi/intel64/libfabric/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/libfabric-1.13.2-dkuomw2tr4cg7gou7ditesm2s5urn7wt/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/libpng-1.6.37-ocjolukaviqz7eu6qxd6g6vswwurh3yq/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/lz4-1.9.3-2bfqfviat27t25cy3h72voaxswkmrprc/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/openfoam-1912-3jrr44nshlwj2cwrlz4rnhqztf2diu7i/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/openfoam-1912-3jrr44nshlwj2cwrlz4rnhqztf2diu7i/platforms/linux64GccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/openfoam-1912-3jrr44nshlwj2cwrlz4rnhqztf2diu7i/site/1912/platforms/linux64GccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/openfoam-1912-3jrr44nshlwj2cwrlz4rnhqztf2diu7i/wmake"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/sz-2.1.12-ka5cfwgxp7pp3n6gl7qpxicegavwctzv/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/autoconf-2.69-ceb7nlwfazf2nkv35fl2mpzdopfxef7t/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/automake-1.16.3-yr3cnmznvpsb2gkbud2etgs2ticprnfs/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/berkeley-db-18.1.40-esdh5smf3v2opaptasw3rw4yi4gjuv33/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/bzip2-1.0.8-7y3kw3kjepchrc47pugpsl5hngesuruw/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/cmake-3.21.3-cuo4onwmtocy6ak6b4t5qel5ci3qsuw4/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/diffutils-3.7-jf4k5sfjkgj5zmydrvpgzfvctljq5gea/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/gdbm-1.19-73vofzong2dedmqcj3ghmr2i5j5peyc5/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/libiconv-1.16-zibyn6qblgbpyowppojogw33zwcy3iep/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/libtool-2.4.6-ycssfzg3eirn6usvs6uziyvc3r3vchgu/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/m4-1.4.19-b74iwrelpjlodqw5syc6sx7yzfgt6dy3/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/ncurses-6.2-gwavpmelqt5lmdvhe634owennh637sgz/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/perl-5.34.0-dchhct5agfdgiedeeq6muwr2tizwupvj/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/pkgconf-1.8.0-5j7y6ulbecusvchbvjocqx2vdk6wvzdm/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/readline-8.1-fm7n7kcprggo7k5rl4xsvfetu3lfdecz/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/berkeley-db-18.1.40-k4v5w5e55oyalvig4qsiosz55hx6p6ul/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/bzip2-1.0.8-zww6j2hnd5fonaa47qvoboe37pfa3vgf/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/cgal-4.13-t5xzgmqfvf4fz7j52jfyggmkb2hxmnyn/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/cmake-3.22.1-ypqd26gzddhjdzvthnn2ldwxwd4q6k44/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gdbm-1.19-zljjyx2d5sahvarttqlxkobm4dnk6eo3/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/libiconv-1.16-7cfllhbcqulmjmm4rjo4h7sdw7mjmgr2/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/m4-1.4.19-porwyt5c4olanixr6qkq2mflqkmcuzub/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openssl-1.1.1l-pcrnjr7ipflb74ljes2nbdhbie5eal5r/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/perl-5.34.0-idlgrwnc3onn5goemgujkvmfzuspcwxx/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/adios2-2.7.1-pj4hsavzughv3l2smee4zdjq3xiy7ibu/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/hwloc-2.6.0-iie5gvzfgfa43uj2flsr3vhnjy7iczml/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libevent-2.1.12-bybtf5avje56fcsbukakjid3zhfumuo4/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libfabric-1.13.2-fj4vq7yhdtm37ryfpxtcw2ovlupxelx4/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libiconv-1.16-yo7stnv474bl6banyp47e55sm7diwzvd/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libpng-1.6.37-ldyzdsgzd54qq7etthys455tyzoubepf/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libtool-2.4.6-di7o36krqjxpix6hp2miinyytm57l6cy/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libxml2-2.9.12-6ozi2nvu6z5e56jfkjpybg7fgcdjgios/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/lz4-1.9.3-by5dktbxs7zkdheqacyoofkkpklmzqyq/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/numactl-2.0.14-432cuzkvcbfaf4gpfs47zhvpmh4sa24m/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openblas-0.3.18-t435bnt4h2vkl5xabvymxtmouspvo76l/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openmpi-4.1.1-lw4ni75fo755xtyjkechnw7kojg6wjzq/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/pcre-8.44-u24tbrkc4f5ubotlmkndzufutondh45n/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/pkgconf-1.8.0-jfxue7nuw7t7kzqvkc7tykaqh37nckti/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/py-cython-0.29.24-2nvyw4c7cz7ybvx6yuifj4ueroic2e2d/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/py-numpy-1.21.4-4pat3afj3ejevpq7vvrli3xfhm3s534f/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/python-3.9.0-onzi5bwdqu5ti6v4o3bhzqqzsqmfauqn/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/swig-4.0.2-gxvjybkwpf4npfzpr2d2el4pghnazcbj/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/sz-2.1.12-jvcy5vqgf6ysgfm77agoayecctbtv2hb/bin"] = 1,
            ["/home/samir/.local/bin"] = 1,
            ["/home/samir/OpenFOAM/samir-v1912/platforms/linux64GccDPInt32-spack/bin"] = 1,
            ["/home/samir/bin"] = 1,
            ["/home/samir/miniconda3/bin"] = 1,
            ["/home/samir/miniconda3/condabin"] = 1,
            ["/opt/ohpc/pub/bin"] = 1,
            ["/opt/ohpc/pub/compiler/gcc/8.3.0/bin"] = 1,
            ["/opt/ohpc/pub/utils/autotools/bin"] = 1,
            ["/opt/ohpc/pub/utils/prun/1.3"] = 1,
            ["/usr/bin"] = 1,
            ["/usr/lib64/qt-3.3/bin"] = 1,
            ["/usr/local/bin"] = 1,
            ["/usr/local/sbin"] = 1,
            ["/usr/sbin"] = 1,
          },
          ["wV"] = "000001912.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000003.*jrr.*zfinal",
          whatis = {
            "OpenFOAM is a GPL-opensource C++ CFD-toolbox. This offering is supported by OpenCFD Ltd, producer and distributor of the OpenFOAM software via www.openfoam.com, and owner of the OPENFOAM trademark. OpenCFD Ltd has been developing and releasing OpenFOAM since its debut in 2004.  ",
          },
        },
        ["openfoam/2106-intel-2021.5.0-kcou"]  = {
          ["Version"] = "2106-intel-2021.5.0-kcou",
          ["canonical"] = "2106-intel-2021.5.0-kcou",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/openfoam/2106-intel-2021.5.0-kcou",
          ["help"] = [[
OpenFOAM is a GPL-opensource C++ CFD-toolbox. This offering is supported
by OpenCFD Ltd, producer and distributor of the OpenFOAM software via
www.openfoam.com, and owner of the OPENFOAM trademark. OpenCFD Ltd has
been developing and releasing OpenFOAM since its debut in 2004.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/adios2-2.7.1-nvlzqirfzwpv3eo4cvhbfddgiddddfph/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/boost-1.68.0-y3zk5jdzp2wn4qybib3zbu5iw3ovbgua/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/cgal-4.13-t5xzgmqfvf4fz7j52jfyggmkb2hxmnyn/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openfoam-2106-kcou6mlif27fskk4nlnxssciosqj2xvr/platforms/linux64IccDPInt32-spack/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openfoam-2106-kcou6mlif27fskk4nlnxssciosqj2xvr/platforms/linux64IccDPInt32-spack/lib/dummy"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openfoam-2106-kcou6mlif27fskk4nlnxssciosqj2xvr/platforms/linux64IccDPInt32-spack/lib/user-mpi"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openfoam-2106-kcou6mlif27fskk4nlnxssciosqj2xvr/site/2106/platforms/linux64IccDPInt32-spack/lib"] = 1,
            ["/home/samir/OpenFOAM/samir-v2106/platforms/linux64IccDPInt32-spack/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002106.*intel.*zfinal-.000002021.000000005.*kcou.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/adios2-2.7.1-nvlzqirfzwpv3eo4cvhbfddgiddddfph/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openfoam-2106-kcou6mlif27fskk4nlnxssciosqj2xvr/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openfoam-2106-kcou6mlif27fskk4nlnxssciosqj2xvr/platforms/linux64IccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openfoam-2106-kcou6mlif27fskk4nlnxssciosqj2xvr/site/2106/platforms/linux64IccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openfoam-2106-kcou6mlif27fskk4nlnxssciosqj2xvr/wmake"] = 1,
            ["/home/samir/OpenFOAM/samir-v2106/platforms/linux64IccDPInt32-spack/bin"] = 1,
          },
          ["wV"] = "000002106.*intel.*zfinal-.000002021.000000005.*kcou.*zfinal",
          whatis = {
            "OpenFOAM is a GPL-opensource C++ CFD-toolbox. This offering is supported by OpenCFD Ltd, producer and distributor of the OpenFOAM software via www.openfoam.com, and owner of the OPENFOAM trademark. OpenCFD Ltd has been developing and releasing OpenFOAM since its debut in 2004.  ",
          },
        },
        ["openfoam/2112-intel-2021.3.0-v7tn"]  = {
          ["Version"] = "2112-intel-2021.3.0-v7tn",
          ["canonical"] = "2112-intel-2021.3.0-v7tn",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/openfoam/2112-intel-2021.3.0-v7tn",
          ["help"] = [[
OpenFOAM is a GPL-opensource C++ CFD-toolbox. This offering is supported
by OpenCFD Ltd, producer and distributor of the OpenFOAM software via
www.openfoam.com, and owner of the OPENFOAM trademark. OpenCFD Ltd has
been developing and releasing OpenFOAM since its debut in 2004.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/adios2-2.7.1-waacpjlaefoonn7hf27lb5ez7zjwbl4d/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/boost-1.68.0-paepigb4ledtz742thequ3mwz4kefa3o/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/cgal-4.13-g5bxv2qni7baa2q54kmcnzsd7cusip35/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfoam-2112-v7tnczkuruoewqhama2oun7bxfm7fh7c/platforms/linux64IccDPInt32-spack/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfoam-2112-v7tnczkuruoewqhama2oun7bxfm7fh7c/platforms/linux64IccDPInt32-spack/lib/dummy"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfoam-2112-v7tnczkuruoewqhama2oun7bxfm7fh7c/platforms/linux64IccDPInt32-spack/lib/user-mpi"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfoam-2112-v7tnczkuruoewqhama2oun7bxfm7fh7c/site/2112/platforms/linux64IccDPInt32-spack/lib"] = 1,
            ["/home/samir/OpenFOAM/samir-v2112/platforms/linux64IccDPInt32-spack/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000002112.*intel.*zfinal-.000002021.000000003.*v.000000007.*tn.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/adios2-2.7.1-waacpjlaefoonn7hf27lb5ez7zjwbl4d/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfoam-2112-v7tnczkuruoewqhama2oun7bxfm7fh7c/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfoam-2112-v7tnczkuruoewqhama2oun7bxfm7fh7c/platforms/linux64IccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfoam-2112-v7tnczkuruoewqhama2oun7bxfm7fh7c/site/2112/platforms/linux64IccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openfoam-2112-v7tnczkuruoewqhama2oun7bxfm7fh7c/wmake"] = 1,
            ["/home/samir/OpenFOAM/samir-v2112/platforms/linux64IccDPInt32-spack/bin"] = 1,
          },
          ["wV"] = "000002112.*intel.*zfinal-.000002021.000000003.*v.000000007.*tn.*zfinal",
          whatis = {
            "OpenFOAM is a GPL-opensource C++ CFD-toolbox. This offering is supported by OpenCFD Ltd, producer and distributor of the OpenFOAM software via www.openfoam.com, and owner of the OPENFOAM trademark. OpenCFD Ltd has been developing and releasing OpenFOAM since its debut in 2004.  ",
          },
        },
      },
    },
    ["openfoam-org"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openfoam-org/8-intel-2021.4.0-z3rh"]  = {
          ["Version"] = "8-intel-2021.4.0-z3rh",
          ["canonical"] = "8-intel-2021.4.0-z3rh",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/openfoam-org/8-intel-2021.4.0-z3rh",
          ["help"] = [[
OpenFOAM is a GPL-opensource C++ CFD-toolbox. The openfoam.org release
is managed by the OpenFOAM Foundation Ltd as a licensee of the OPENFOAM
trademark. This offering is not approved or endorsed by OpenCFD Ltd,
producer and distributor of the OpenFOAM software via www.openfoam.com,
and owner of the OPENFOAM trademark.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/ThirdParty/platforms/linux64IccDPInt32/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/ThirdParty/platforms/linux64IccDPInt32/lib/mpi-system"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/platforms/linux64IccDPInt32-spack/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/platforms/linux64IccDPInt32-spack/lib/dummy"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/platforms/linux64IccDPInt32-spack/lib/mpi-system"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/site/8/platforms/linux64IccDPInt32-spack/lib"] = 1,
            ["/home/samir/OpenFOAM/samir-8/platforms/linux64IccDPInt32-spack/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000008.*intel.*zfinal-.000002021.000000004.*z.000000003.*rh.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/platforms/linux64IccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/site/8/platforms/linux64IccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/openfoam-org-8-z3rhurqbfeltsi6koqyziqwndsgii6hn/wmake"] = 1,
            ["/home/samir/OpenFOAM/samir-8/platforms/linux64IccDPInt32-spack/bin"] = 1,
          },
          ["wV"] = "000000008.*intel.*zfinal-.000002021.000000004.*z.000000003.*rh.*zfinal",
          whatis = {
            "OpenFOAM is a GPL-opensource C++ CFD-toolbox. The openfoam.org release is managed by the OpenFOAM Foundation Ltd as a licensee of the OPENFOAM trademark. This offering is not approved or endorsed by OpenCFD Ltd, producer and distributor of the OpenFOAM software via www.openfoam.com, and owner of the OPENFOAM trademark.  ",
          },
        },
      },
    },
    openmolcas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openmolcas/21.02-intel-2021.3.0-ambh"]  = {
          ["Version"] = "21.02-intel-2021.3.0-ambh",
          ["canonical"] = "21.02-intel-2021.3.0-ambh",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/openmolcas/21.02-intel-2021.3.0-ambh",
          ["help"] = [[
OpenMolcas is a quantum chemistry software package. The key feature of
OpenMolcas is the multiconfigurational approach to the electronic
structure.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000021.000000002.*intel.*zfinal-.000002021.000000003.*ambh.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openmolcas-21.02-ambhdbrcggz3kt645sgjbtvifv3sydaw"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/openmolcas-21.02-ambhdbrcggz3kt645sgjbtvifv3sydaw/bin"] = 1,
          },
          ["wV"] = "000000021.000000002.*intel.*zfinal-.000002021.000000003.*ambh.*zfinal",
          whatis = {
            "OpenMolcas is a quantum chemistry software package. The key feature of OpenMolcas is the multiconfigurational approach to the electronic structure. ",
          },
        },
      },
    },
    opennurbs = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["opennurbs/percept-intel-2021.3.0-72bz"]  = {
          ["Version"] = "percept-intel-2021.3.0-72bz",
          ["canonical"] = "percept-intel-2021.3.0-72bz",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/opennurbs/percept-intel-2021.3.0-72bz",
          ["help"] = [[
OpenNURBS is an open-source NURBS-based geometric modeling library and
toolset, with meshing and display / output functions.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "*percept.*intel.*zfinal-.000002021.000000003.*zfinal-.000000072.*bz.*zfinal",
          ["wV"] = "*percept.*intel.*zfinal-.000002021.000000003.*zfinal-.000000072.*bz.*zfinal",
          whatis = {
            "OpenNURBS is an open-source NURBS-based geometric modeling library and toolset, with meshing and display / output functions.  ",
          },
        },
      },
    },
    ["osu-micro-benchmarks"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["osu-micro-benchmarks/5.7.1-gcc-11.2.0-v73q"]  = {
          ["Version"] = "5.7.1-gcc-11.2.0-v73q",
          ["canonical"] = "5.7.1-gcc-11.2.0-v73q",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/osu-micro-benchmarks/5.7.1-gcc-11.2.0-v73q",
          ["help"] = [[
The Ohio MicroBenchmark suite is a collection of independent MPI message
passing performance microbenchmarks developed and written at The Ohio
State University. It includes traditional benchmarks and performance
measures such as latency, bandwidth and host overhead and can be used
for both traditional and GPU-enhanced nodes.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000005.000000007.000000001.*gcc.*zfinal-.000000011.000000002.*v.000000073.*q.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/osu-micro-benchmarks-5.7.1-v73qx7dykk4qm75rvawpcu7n5r7lcley/libexec/osu-micro-benchmarks/mpi/collective"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/osu-micro-benchmarks-5.7.1-v73qx7dykk4qm75rvawpcu7n5r7lcley/libexec/osu-micro-benchmarks/mpi/one-sided"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/osu-micro-benchmarks-5.7.1-v73qx7dykk4qm75rvawpcu7n5r7lcley/libexec/osu-micro-benchmarks/mpi/pt2pt"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/osu-micro-benchmarks-5.7.1-v73qx7dykk4qm75rvawpcu7n5r7lcley/libexec/osu-micro-benchmarks/mpi/startup"] = 1,
          },
          ["wV"] = "000000005.000000007.000000001.*gcc.*zfinal-.000000011.000000002.*v.000000073.*q.*zfinal",
          whatis = {
            "The Ohio MicroBenchmark suite is a collection of independent MPI message passing performance microbenchmarks developed and written at The Ohio State University. It includes traditional benchmarks and performance measures such as latency, bandwidth and host overhead and can be used for both traditional and GPU-enhanced nodes. ",
          },
        },
        ["osu-micro-benchmarks/5.7.1-intel-2021.4.0-rvfc"]  = {
          ["Version"] = "5.7.1-intel-2021.4.0-rvfc",
          ["canonical"] = "5.7.1-intel-2021.4.0-rvfc",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/osu-micro-benchmarks/5.7.1-intel-2021.4.0-rvfc",
          ["help"] = [[
The Ohio MicroBenchmark suite is a collection of independent MPI message
passing performance microbenchmarks developed and written at The Ohio
State University. It includes traditional benchmarks and performance
measures such as latency, bandwidth and host overhead and can be used
for both traditional and GPU-enhanced nodes.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000005.000000007.000000001.*intel.*zfinal-.000002021.000000004.*rvfc.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/osu-micro-benchmarks-5.7.1-rvfcike6z7yhcorau4veegekf2tz6yyy/libexec/osu-micro-benchmarks/mpi/collective"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/osu-micro-benchmarks-5.7.1-rvfcike6z7yhcorau4veegekf2tz6yyy/libexec/osu-micro-benchmarks/mpi/one-sided"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/osu-micro-benchmarks-5.7.1-rvfcike6z7yhcorau4veegekf2tz6yyy/libexec/osu-micro-benchmarks/mpi/pt2pt"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/osu-micro-benchmarks-5.7.1-rvfcike6z7yhcorau4veegekf2tz6yyy/libexec/osu-micro-benchmarks/mpi/startup"] = 1,
          },
          ["wV"] = "000000005.000000007.000000001.*intel.*zfinal-.000002021.000000004.*rvfc.*zfinal",
          whatis = {
            "The Ohio MicroBenchmark suite is a collection of independent MPI message passing performance microbenchmarks developed and written at The Ohio State University. It includes traditional benchmarks and performance measures such as latency, bandwidth and host overhead and can be used for both traditional and GPU-enhanced nodes. ",
          },
        },
      },
    },
    packmol = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["packmol/18.169-intel-2021.3.0-w7ct"]  = {
          ["Version"] = "18.169-intel-2021.3.0-w7ct",
          ["canonical"] = "18.169-intel-2021.3.0-w7ct",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/packmol/18.169-intel-2021.3.0-w7ct",
          ["help"] = [[
Packmol creates an initial point for molecular dynamics simulations by
packing molecules in defined regions of space.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000018.000000169.*intel.*zfinal-.000002021.000000003.*w.000000007.*ct.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/packmol-18.169-w7cthrirwocomvuayb3zcmd2v6yfbuzz/bin"] = 1,
          },
          ["wV"] = "000000018.000000169.*intel.*zfinal-.000002021.000000003.*w.000000007.*ct.*zfinal",
          whatis = {
            "Packmol creates an initial point for molecular dynamics simulations by packing molecules in defined regions of space. ",
          },
        },
      },
    },
    phylip = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["phylip/3.697-intel-2021.3.0-di3b"]  = {
          ["Version"] = "3.697-intel-2021.3.0-di3b",
          ["canonical"] = "3.697-intel-2021.3.0-di3b",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/phylip/3.697-intel-2021.3.0-di3b",
          ["help"] = [[
PHYLIP (the PHYLogeny Inference Package) is a package of programs for
inferring phylogenies (evolutionary trees).

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000697.*intel.*zfinal-.000002021.000000003.*di.000000003.*b.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/phylip-3.697-di3bwjrrhideioa66p63dfzemyuczex7/bin"] = 1,
          },
          ["wV"] = "000000003.000000697.*intel.*zfinal-.000002021.000000003.*di.000000003.*b.*zfinal",
          whatis = {
            "PHYLIP (the PHYLogeny Inference Package) is a package of programs for inferring phylogenies (evolutionary trees). ",
          },
        },
      },
    },
    ["py-anuga-jayashri"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py-anuga-jayashri/interpolate-gcc-11.2.0-qi2j"]  = {
          ["Version"] = "interpolate-gcc-11.2.0-qi2j",
          ["canonical"] = "interpolate-gcc-11.2.0-qi2j",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/py-anuga-jayashri/interpolate-gcc-11.2.0-qi2j",
          ["help"] = "",
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "*interpolate.*gcc.*zfinal-.000000011.000000002.*qi.000000002.*j.*zfinal",
          ["wV"] = "*interpolate.*gcc.*zfinal-.000000011.000000002.*qi.000000002.*j.*zfinal",
          whatis = {
            "ANUGA (pronounced 'AHnooGAH') is open-source software for the simulation of the shallow water equation, in particular it can be used to model tsunamis and floods. ",
          },
        },
      },
    },
    ["py-clustershell"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py-clustershell/1.8-intel-2021.3.0-7yrv"]  = {
          ["Version"] = "1.8-intel-2021.3.0-7yrv",
          ["canonical"] = "1.8-intel-2021.3.0-7yrv",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/py-clustershell/1.8-intel-2021.3.0-7yrv",
          ["help"] = [[
Scalable cluster administration Python framework - Manage node sets node
groups and execute commands on cluster nodes in parallel.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000001.000000008.*intel.*zfinal-.000002021.000000003.*zfinal-.000000007.*yrv.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/py-clustershell-1.8-7yrvpx74y65wwweu5voy5dea7ky3gxlq/bin"] = 1,
          },
          ["wV"] = "000000001.000000008.*intel.*zfinal-.000002021.000000003.*zfinal-.000000007.*yrv.*zfinal",
          whatis = {
            "Scalable cluster administration Python framework - Manage node sets node groups and execute commands on cluster nodes in parallel.  ",
          },
        },
      },
    },
    ["py-memprof"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py-memprof/0.3.6-gcc-10.3.0-77rv"]  = {
          ["Version"] = "0.3.6-gcc-10.3.0-77rv",
          ["canonical"] = "0.3.6-gcc-10.3.0-77rv",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/py-memprof/0.3.6-gcc-10.3.0-77rv",
          ["help"] = [[
memprof logs and plots the memory usage of all the variables during the
execution of the decorated methods.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000000.000000003.000000006.*gcc.*zfinal-.000000010.000000003.*zfinal-.000000077.*rv.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-10.3.0/py-memprof-0.3.6-77rvvkcch7cerhbcuh6nsjpxjqxc2vab/bin"] = 1,
          },
          ["wV"] = "000000000.000000003.000000006.*gcc.*zfinal-.000000010.000000003.*zfinal-.000000077.*rv.*zfinal",
          whatis = {
            "memprof logs and plots the memory usage of all the variables during the execution of the decorated methods. ",
          },
        },
      },
    },
    ["quantum-espresso"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["quantum-espresso/7.0-intel-2021.5.0-vns4"]  = {
          ["Version"] = "7.0-intel-2021.5.0-vns4",
          ["canonical"] = "7.0-intel-2021.5.0-vns4",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/quantum-espresso/7.0-intel-2021.5.0-vns4",
          ["help"] = [[
Quantum ESPRESSO is an integrated suite of Open-Source computer codes
for electronic-structure calculations and materials modeling at the
nanoscale. It is based on density-functional theory, plane waves, and
pseudopotentials.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/quantum-espresso-7.0-vns4j3zdmx4tqnrfytbwcd53jwki7pow/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000007.*intel.*zfinal-.000002021.000000005.*vns.000000004.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/quantum-espresso-7.0-vns4j3zdmx4tqnrfytbwcd53jwki7pow/bin"] = 1,
          },
          ["wV"] = "000000007.*intel.*zfinal-.000002021.000000005.*vns.000000004.*zfinal",
          whatis = {
            "Quantum ESPRESSO is an integrated suite of Open-Source computer codes for electronic-structure calculations and materials modeling at the nanoscale. It is based on density-functional theory, plane waves, and pseudopotentials.  ",
          },
        },
      },
    },
    remhos = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["remhos/1.0-intel-2021.3.0-rmcv"]  = {
          ["Version"] = "1.0-intel-2021.3.0-rmcv",
          ["canonical"] = "1.0-intel-2021.3.0-rmcv",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/remhos/1.0-intel-2021.3.0-rmcv",
          ["help"] = [[
Remhos (REMap High-Order Solver) is a CEED miniapp that performs
monotonic and conservative high-order discontinuous field interpolation
(remap) using DG advection-based spatial discretization and explicit
high-order time-stepping.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000001.*intel.*zfinal-.000002021.000000003.*rmcv.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/remhos-1.0-rmcvj6mbzp4pngk2jsfyu3cvuarkr6ah/bin"] = 1,
          },
          ["wV"] = "000000001.*intel.*zfinal-.000002021.000000003.*rmcv.*zfinal",
          whatis = {
            "Remhos (REMap High-Order Solver) is a CEED miniapp that performs monotonic and conservative high-order discontinuous field interpolation (remap) using DG advection-based spatial discretization and explicit high-order time-stepping.  ",
          },
        },
      },
    },
    scalasca = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalasca/2.6-gcc-11.2.0-6ccy"]  = {
          ["Version"] = "2.6-gcc-11.2.0-6ccy",
          ["canonical"] = "2.6-gcc-11.2.0-6ccy",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/scalasca/2.6-gcc-11.2.0-6ccy",
          ["help"] = [[
Scalasca is a software tool that supports the performance optimization
of parallel programs by measuring and analyzing their runtime behavior.
The analysis identifies potential performance bottlenecks - in
particular those concerning communication and synchronization - and
offers guidance in exploring their causes.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000006.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000006.*ccy.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/scalasca-2.6-6ccy6774ygfcpr6htqfypjlzh5crwvqo/bin"] = 1,
          },
          ["wV"] = "000000002.000000006.*gcc.*zfinal-.000000011.000000002.*zfinal-.000000006.*ccy.*zfinal",
          whatis = {
            "Scalasca is a software tool that supports the performance optimization of parallel programs by measuring and analyzing their runtime behavior. The analysis identifies potential performance bottlenecks - in particular those concerning communication and synchronization - and offers guidance in exploring their causes. ",
          },
        },
        ["scalasca/2.6-gcc-11.2.0-pkcm"]  = {
          ["Version"] = "2.6-gcc-11.2.0-pkcm",
          ["canonical"] = "2.6-gcc-11.2.0-pkcm",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/scalasca/2.6-gcc-11.2.0-pkcm",
          ["help"] = [[
Scalasca is a software tool that supports the performance optimization
of parallel programs by measuring and analyzing their runtime behavior.
The analysis identifies potential performance bottlenecks - in
particular those concerning communication and synchronization - and
offers guidance in exploring their causes.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000006.*gcc.*zfinal-.000000011.000000002.*kcm.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/scalasca-2.6-pkcmnrkvvi4iujpazce762mma7bg5zhw/bin"] = 1,
          },
          ["wV"] = "000000002.000000006.*gcc.*zfinal-.000000011.000000002.*kcm.*zfinal",
          whatis = {
            "Scalasca is a software tool that supports the performance optimization of parallel programs by measuring and analyzing their runtime behavior. The analysis identifies potential performance bottlenecks - in particular those concerning communication and synchronization - and offers guidance in exploring their causes. ",
          },
        },
      },
    },
    scorep = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scorep/7.0-gcc-11.2.0-hfd4"]  = {
          ["Version"] = "7.0-gcc-11.2.0-hfd4",
          ["canonical"] = "7.0-gcc-11.2.0-hfd4",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/scorep/7.0-gcc-11.2.0-hfd4",
          ["help"] = [[
The Score-P measurement infrastructure is a highly scalable and easy-to-
use tool suite for profiling, event tracing, and online analysis of HPC
applications.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000007.*gcc.*zfinal-.000000011.000000002.*hfd.000000004.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/scorep-7.0-hfd4qwrvnvz3cbdswcxonkhzpblcoqjd/bin"] = 1,
          },
          ["wV"] = "000000007.*gcc.*zfinal-.000000011.000000002.*hfd.000000004.*zfinal",
          whatis = {
            "The Score-P measurement infrastructure is a highly scalable and easy-to-use tool suite for profiling, event tracing, and online analysis of HPC applications.  ",
          },
        },
      },
    },
    su2 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["su2/7.2.0-gcc-11.2.0-ifig"]  = {
          ["Version"] = "7.2.0-gcc-11.2.0-ifig",
          ["canonical"] = "7.2.0-gcc-11.2.0-ifig",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/su2/7.2.0-gcc-11.2.0-ifig",
          ["help"] = [[
SU2 is a suite of open-source software tools written in C++ for the
numerical solution of partial differential equations (PDE) and
performing PDE constrained optimization.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000007.000000002.*gcc.*zfinal-.000000011.000000002.*ifig.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/su2-7.2.0-ifigqhtj4nz7fi47kmbgieub57sird6f/bin"] = 1,
          },
          ["wV"] = "000000007.000000002.*gcc.*zfinal-.000000011.000000002.*ifig.*zfinal",
          whatis = {
            "SU2 is a suite of open-source software tools written in C++ for the numerical solution of partial differential equations (PDE) and performing PDE constrained optimization. ",
          },
        },
      },
    },
    tau = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tau/2.30-gcc-11.2.0-toiw"]  = {
          ["Version"] = "2.30-gcc-11.2.0-toiw",
          ["canonical"] = "2.30-gcc-11.2.0-toiw",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/tau/2.30-gcc-11.2.0-toiw",
          ["help"] = [[
A portable profiling and tracing toolkit for performance analysis of
parallel programs written in Fortran, C, C++, UPC, Java, Python.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000002.000000030.*gcc.*zfinal-.000000011.000000002.*toiw.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/tau-2.30-toiwivn4427tcwe46mnhroiy4k3mkgvt/bin"] = 1,
          },
          ["wV"] = "000000002.000000030.*gcc.*zfinal-.000000011.000000002.*toiw.*zfinal",
          whatis = {
            "A portable profiling and tracing toolkit for performance analysis of parallel programs written in Fortran, C, C++, UPC, Java, Python.  ",
          },
        },
      },
    },
    tealeaf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tealeaf/1.0-intel-2021.5.0-hqm3"]  = {
          ["Version"] = "1.0-intel-2021.5.0-hqm3",
          ["canonical"] = "1.0-intel-2021.5.0-hqm3",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/tealeaf/1.0-intel-2021.5.0-hqm3",
          ["help"] = [[
Proxy Application. TeaLeaf is a mini-app that solves the linear heat
conduction equation on a spatially decomposed regularly grid using a 5
point stencil with implicit solvers.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000001.*intel.*zfinal-.000002021.000000005.*hqm.000000003.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/tealeaf-1.0-hqm3kudzhfhqguxewgojf3blaehzp5ke/bin"] = 1,
          },
          ["wV"] = "000000001.*intel.*zfinal-.000002021.000000005.*hqm.000000003.*zfinal",
          whatis = {
            "Proxy Application. TeaLeaf is a mini-app that solves the linear heat conduction equation on a spatially decomposed regularly grid using a 5 point stencil with implicit solvers.  ",
          },
        },
      },
    },
    tycho2 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tycho2/develop-intel-2021.3.0-ctot"]  = {
          ["Version"] = "develop-intel-2021.3.0-ctot",
          ["canonical"] = "develop-intel-2021.3.0-ctot",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/tycho2/develop-intel-2021.3.0-ctot",
          ["help"] = [[
A neutral particle transport mini-app to study performance of sweeps on
unstructured, 3D tetrahedral meshes.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "*develop.*intel.*zfinal-.000002021.000000003.*ctot.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/tycho2-develop-ctotz47qltqeivttwiw2ymm453ihpues/bin"] = 1,
          },
          ["wV"] = "*develop.*intel.*zfinal-.000002021.000000003.*ctot.*zfinal",
          whatis = {
            "A neutral particle transport mini-app to study performance of sweeps on unstructured, 3D tetrahedral meshes.  ",
          },
        },
      },
    },
    vampirtrace = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["vampirtrace/5.14.4-gcc-10.3.0-r7gu"]  = {
          ["Version"] = "5.14.4-gcc-10.3.0-r7gu",
          ["canonical"] = "5.14.4-gcc-10.3.0-r7gu",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/vampirtrace/5.14.4-gcc-10.3.0-r7gu",
          ["help"] = [[
VampirTrace is an open source library that allows detailed logging of
program execution for parallel applications using message passing (MPI)
and threads (OpenMP, Pthreads).

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000005.000000014.000000004.*gcc.*zfinal-.000000010.000000003.*r.000000007.*gu.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-10.3.0/vampirtrace-5.14.4-r7guxe2bpv5ytbqnoea5wmszjyyxngph/bin"] = 1,
          },
          ["wV"] = "000000005.000000014.000000004.*gcc.*zfinal-.000000010.000000003.*r.000000007.*gu.*zfinal",
          whatis = {
            "VampirTrace is an open source library that allows detailed logging of program execution for parallel applications using message passing (MPI) and threads (OpenMP, Pthreads). ",
          },
        },
        ["vampirtrace/5.14.4-gcc-11.2.0-lciy"]  = {
          ["Version"] = "5.14.4-gcc-11.2.0-lciy",
          ["canonical"] = "5.14.4-gcc-11.2.0-lciy",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/vampirtrace/5.14.4-gcc-11.2.0-lciy",
          ["help"] = [[
VampirTrace is an open source library that allows detailed logging of
program execution for parallel applications using message passing (MPI)
and threads (OpenMP, Pthreads).

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000005.000000014.000000004.*gcc.*zfinal-.000000011.000000002.*lciy.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/vampirtrace-5.14.4-lciyei462ewwkysbhfs7p2xxdmtu4h33/bin"] = 1,
          },
          ["wV"] = "000000005.000000014.000000004.*gcc.*zfinal-.000000011.000000002.*lciy.*zfinal",
          whatis = {
            "VampirTrace is an open source library that allows detailed logging of program execution for parallel applications using message passing (MPI) and threads (OpenMP, Pthreads). ",
          },
        },
      },
    },
    wrf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["wrf/4.2-intel-2021.3.0-uws7"]  = {
          ["Version"] = "4.2-intel-2021.3.0-uws7",
          ["canonical"] = "4.2-intel-2021.3.0-uws7",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/wrf/4.2-intel-2021.3.0-uws7",
          ["help"] = [[
The Weather Research and Forecasting (WRF) Model is a next-generation
mesoscale numerical weather prediction system designed for both
atmospheric research and operational forecasting applications.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000004.000000002.*intel.*zfinal-.000002021.000000003.*uws.000000007.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/wrf-4.2-uws7fodprumn4xhaxodjn76vm4e3o7jg/main"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/wrf-4.2-uws7fodprumn4xhaxodjn76vm4e3o7jg/tools"] = 1,
          },
          ["wV"] = "000000004.000000002.*intel.*zfinal-.000002021.000000003.*uws.000000007.*zfinal",
          whatis = {
            "The Weather Research and Forecasting (WRF) Model is a next-generation mesoscale numerical weather prediction system designed for both atmospheric research and operational forecasting applications.  ",
          },
        },
      },
    },
    zlib = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["zlib/1.2.11-intel-2021.4.0-zkpi"]  = {
          ["Version"] = "1.2.11-intel-2021.4.0-zkpi",
          ["canonical"] = "1.2.11-intel-2021.4.0-zkpi",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/zlib/1.2.11-intel-2021.4.0-zkpi",
          ["help"] = [[
A free, general-purpose, legally unencumbered lossless data-compression
library.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.4.0/zlib-1.2.11-zkpidek4mdgnb6t6vvg4vm77hovtaj26/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000001.000000002.000000011.*intel.*zfinal-.000002021.000000004.*zkpi.*zfinal",
          ["wV"] = "000000001.000000002.000000011.*intel.*zfinal-.000002021.000000004.*zkpi.*zfinal",
          whatis = {
            "A free, general-purpose, legally unencumbered lossless data-compression library.  ",
          },
        },
      },
    },
    zoltan = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["zoltan/3.83-gcc-11.2.0-wrv4"]  = {
          ["Version"] = "3.83-gcc-11.2.0-wrv4",
          ["canonical"] = "3.83-gcc-11.2.0-wrv4",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake/zoltan/3.83-gcc-11.2.0-wrv4",
          ["help"] = [[
The Zoltan library is a toolkit of parallel combinatorial algorithms for
parallel, unstructured, and/or adaptive scientific applications.
Zoltan's largest component is a suite of dynamic load-balancing and
partitioning algorithms that increase applications' parallel performance
by reducing idle time. Zoltan also has graph coloring and graph ordering
algorithms, which are useful in task schedulers and parallel
preconditioners.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-cascadelake",
          ["pV"] = "000000003.000000083.*gcc.*zfinal-.000000011.000000002.*wrv.000000004.*zfinal",
          ["wV"] = "000000003.000000083.*gcc.*zfinal-.000000011.000000002.*wrv.000000004.*zfinal",
          whatis = {
            "The Zoltan library is a toolkit of parallel combinatorial algorithms for parallel, unstructured, and/or adaptive scientific applications. Zoltan's largest component is a suite of dynamic load-balancing and partitioning algorithms that increase applications' parallel performance by reducing idle time. Zoltan also has graph coloring and graph ordering algorithms, which are useful in task schedulers and parallel preconditioners. ",
          },
        },
      },
    },
  },
  ["/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512"]  = {
    clustalw = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["clustalw/2.1-gcc-8.3.0-6yq4"]  = {
          ["Version"] = "2.1-gcc-8.3.0-6yq4",
          ["canonical"] = "2.1-gcc-8.3.0-6yq4",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/clustalw/2.1-gcc-8.3.0-6yq4",
          ["help"] = [[
Multiple alignment of nucleic acid and protein sequences.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000002.000000001.*gcc.*zfinal-.000000008.000000003.*zfinal-.000000006.*yq.000000004.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/clustalw-2.1-6yq4fug23hkcaxrbjqoqvcic5svspnqt/bin"] = 1,
          },
          ["wV"] = "000000002.000000001.*gcc.*zfinal-.000000008.000000003.*zfinal-.000000006.*yq.000000004.*zfinal",
          whatis = {
            "Multiple alignment of nucleic acid and protein sequences. ",
          },
        },
      },
    },
    cmake = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["cmake/3.21.3-gcc-12.2.0-cwen"]  = {
          ["Version"] = "3.21.3-gcc-12.2.0-cwen",
          ["canonical"] = "3.21.3-gcc-12.2.0-cwen",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/cmake/3.21.3-gcc-12.2.0-cwen",
          ["help"] = [[
Name   : cmake
Version: 3.21.3
Target : skylake_avx512

A cross-platform, open-source build system. CMake is a family of tools
designed to build, test and package software.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000003.000000021.000000003.*gcc.*zfinal-.000000012.000000002.*cwen.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/cmake-3.21.3-cuo4onwmtocy6ak6b4t5qel5ci3qsuw4/bin"] = 1,
          },
          ["wV"] = "000000003.000000021.000000003.*gcc.*zfinal-.000000012.000000002.*cwen.*zfinal",
          whatis = {
            "A cross-platform, open-source build system. CMake is a family of tools designed to build, test and package software.  ",
          },
        },
      },
    },
    cp2k = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["cp2k/8.2-gcc-8.3.0-t6xr"]  = {
          ["Version"] = "8.2-gcc-8.3.0-t6xr",
          ["canonical"] = "8.2-gcc-8.3.0-t6xr",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/cp2k/8.2-gcc-8.3.0-t6xr",
          ["help"] = [[
CP2K is a quantum chemistry and solid state physics software package
that can perform atomistic simulations of solid state, liquid,
molecular, periodic, material, crystal, and biological systems

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000008.000000002.*gcc.*zfinal-.000000008.000000003.*t.000000006.*xr.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/cp2k-8.2-t6xrdbaqhecwqmhraw3y5li6pte4by6w/bin"] = 1,
          },
          ["wV"] = "000000008.000000002.*gcc.*zfinal-.000000008.000000003.*t.000000006.*xr.*zfinal",
          whatis = {
            "CP2K is a quantum chemistry and solid state physics software package that can perform atomistic simulations of solid state, liquid, molecular, periodic, material, crystal, and biological systems  ",
          },
        },
      },
    },
    gcc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gcc/10.3.0-gcc-8.3.0-zwu4"]  = {
          ["Version"] = "10.3.0-gcc-8.3.0-zwu4",
          ["canonical"] = "10.3.0-gcc-8.3.0-zwu4",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/gcc/10.3.0-gcc-8.3.0-zwu4",
          ["help"] = [[
The GNU Compiler Collection includes front ends for C, C++, Objective-C,
Fortran, Ada, and Go, as well as libraries for these languages.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000010.000000003.*gcc.*zfinal-.000000008.000000003.*zwu.000000004.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/gcc-10.3.0-zwu4bwiwzd6zw7s3djxtpq2kqdlt2nxy/bin"] = 1,
          },
          ["wV"] = "000000010.000000003.*gcc.*zfinal-.000000008.000000003.*zwu.000000004.*zfinal",
          whatis = {
            "The GNU Compiler Collection includes front ends for C, C++, Objective-C, Fortran, Ada, and Go, as well as libraries for these languages. ",
          },
        },
        ["gcc/11.2.0-gcc-8.3.0-fufs"]  = {
          ["Version"] = "11.2.0-gcc-8.3.0-fufs",
          ["canonical"] = "11.2.0-gcc-8.3.0-fufs",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/gcc/11.2.0-gcc-8.3.0-fufs",
          ["help"] = [[
The GNU Compiler Collection includes front ends for C, C++, Objective-C,
Fortran, Ada, and Go, as well as libraries for these languages.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000011.000000002.*gcc.*zfinal-.000000008.000000003.*fufs.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/gcc-11.2.0-fufsigm7go2apn3xzygaw3x266zuxav4/bin"] = 1,
          },
          ["wV"] = "000000011.000000002.*gcc.*zfinal-.000000008.000000003.*fufs.*zfinal",
          whatis = {
            "The GNU Compiler Collection includes front ends for C, C++, Objective-C, Fortran, Ada, and Go, as well as libraries for these languages. ",
          },
        },
      },
    },
    gmake = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gmake/3.82-gcc-12.2.0-axa3"]  = {
          ["Version"] = "3.82-gcc-12.2.0-axa3",
          ["canonical"] = "3.82-gcc-12.2.0-axa3",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/gmake/3.82-gcc-12.2.0-axa3",
          ["help"] = [[
Name   : gmake
Version: 3.82
Target : skylake_avx512

GNU Make is a tool which controls the generation of executables and
other non-source files of a program from the program's source files.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000003.000000082.*gcc.*zfinal-.000000012.000000002.*axa.000000003.*zfinal",
          ["wV"] = "000000003.000000082.*gcc.*zfinal-.000000012.000000002.*axa.000000003.*zfinal",
          whatis = {
            "GNU Make is a tool which controls the generation of executables and other non-source files of a program from the program's source files. ",
          },
        },
      },
    },
    grads = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["grads/2.2.1-gcc-8.3.0-3fqs"]  = {
          ["Version"] = "2.2.1-gcc-8.3.0-3fqs",
          ["canonical"] = "2.2.1-gcc-8.3.0-3fqs",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/grads/2.2.1-gcc-8.3.0-3fqs",
          ["help"] = [[
The Grid Analysis and Display System (GrADS) is an interactive desktop
tool that is used for easy access, manipulation, and visualization of
earth science data. GrADS has two data models for handling gridded and
station data. GrADS supports many data file formats, including binary
(stream or sequential), GRIB (version 1 and 2), NetCDF, HDF (version 4
and 5), and BUFR (for station data).

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000002.000000002.000000001.*gcc.*zfinal-.000000008.000000003.*zfinal-.000000003.*fqs.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/grads-2.2.1-3fqsnlbdlqg46fzkjwbkyibxwbxhdjnm/bin"] = 1,
          },
          ["wV"] = "000000002.000000002.000000001.*gcc.*zfinal-.000000008.000000003.*zfinal-.000000003.*fqs.*zfinal",
          whatis = {
            "The Grid Analysis and Display System (GrADS) is an interactive desktop tool that is used for easy access, manipulation, and visualization of earth science data. GrADS has two data models for handling gridded and station data. GrADS supports many data file formats, including binary (stream or sequential), GRIB (version 1 and 2), NetCDF, HDF (version 4 and 5), and BUFR (for station data). ",
          },
        },
      },
    },
    gromacs = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gromacs/2021.3-gcc-8.3.0-cyar"]  = {
          ["Version"] = "2021.3-gcc-8.3.0-cyar",
          ["canonical"] = "2021.3-gcc-8.3.0-cyar",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/gromacs/2021.3-gcc-8.3.0-cyar",
          ["help"] = [[
GROMACS (GROningen MAchine for Chemical Simulations) is a molecular
dynamics package primarily designed for simulations of proteins, lipids
and nucleic acids. It was originally developed in the Biophysical
Chemistry department of University of Groningen, and is now maintained
by contributors in universities and research centers across the world.
GROMACS is one of the fastest and most popular software packages
available and can run on CPUs as well as GPUs. It is free, open source
released under the GNU General Public License. Starting from version
4.6, GROMACS is released under the GNU Lesser General Public License.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000002021.000000003.*gcc.*zfinal-.000000008.000000003.*cyar.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/gromacs-2021.3-cyaruxrtygisikmuxyvtw2oix2y4mhj6/bin"] = 1,
          },
          ["wV"] = "000002021.000000003.*gcc.*zfinal-.000000008.000000003.*cyar.*zfinal",
          whatis = {
            "GROMACS (GROningen MAchine for Chemical Simulations) is a molecular dynamics package primarily designed for simulations of proteins, lipids and nucleic acids. It was originally developed in the Biophysical Chemistry department of University of Groningen, and is now maintained by contributors in universities and research centers across the world. ",
          },
        },
        ["gromacs/2021.3-gcc-8.3.0-otzu"]  = {
          ["Version"] = "2021.3-gcc-8.3.0-otzu",
          ["canonical"] = "2021.3-gcc-8.3.0-otzu",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/gromacs/2021.3-gcc-8.3.0-otzu",
          ["help"] = [[
GROMACS (GROningen MAchine for Chemical Simulations) is a molecular
dynamics package primarily designed for simulations of proteins, lipids
and nucleic acids. It was originally developed in the Biophysical
Chemistry department of University of Groningen, and is now maintained
by contributors in universities and research centers across the world.
GROMACS is one of the fastest and most popular software packages
available and can run on CPUs as well as GPUs. It is free, open source
released under the GNU General Public License. Starting from version
4.6, GROMACS is released under the GNU Lesser General Public License.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000002021.000000003.*gcc.*zfinal-.000000008.000000003.*otzu.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/gromacs-2021.3-otzuncq63f4dt4tu7k33vxag6iuzpknr/bin"] = 1,
          },
          ["wV"] = "000002021.000000003.*gcc.*zfinal-.000000008.000000003.*otzu.*zfinal",
          whatis = {
            "GROMACS (GROningen MAchine for Chemical Simulations) is a molecular dynamics package primarily designed for simulations of proteins, lipids and nucleic acids. It was originally developed in the Biophysical Chemistry department of University of Groningen, and is now maintained by contributors in universities and research centers across the world. ",
          },
        },
      },
    },
    ["intel-oneapi-compilers"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["intel-oneapi-compilers/2021.3.0-gcc-8.3.0-toom"]  = {
          ["Version"] = "2021.3.0-gcc-8.3.0-toom",
          ["canonical"] = "2021.3.0-gcc-8.3.0-toom",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/intel-oneapi-compilers/2021.3.0-gcc-8.3.0-toom",
          ["help"] = [[
Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and
dpcpp. LICENSE INFORMATION: By downloading and using this software, you
agree to the terms and conditions of the software license agreements at
https://intel.ly/393CijO.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/lib/emu"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/lib/oclfpga/host/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/lib/oclfpga/linux64/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/lib/x64"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000002021.000000003.*gcc.*zfinal-.000000008.000000003.*toom.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/bin/intel64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/lib/oclfpga/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/intel-oneapi-compilers-2021.3.0-toomj3bxfamihqseufyc3suj7ewlgnlq/compiler/2021.3.0/linux/lib/oclfpga/llvm/aocl-bin"] = 1,
          },
          ["wV"] = "000002021.000000003.*gcc.*zfinal-.000000008.000000003.*toom.*zfinal",
          whatis = {
            "Intel oneAPI Compilers. Includes: icc, icpc, ifort, icx, icpx, ifx, and dpcpp. ",
          },
        },
      },
    },
    liggghts = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["liggghts/3.8.0-gcc-8.3.0-6qd2"]  = {
          ["Version"] = "3.8.0-gcc-8.3.0-6qd2",
          ["canonical"] = "3.8.0-gcc-8.3.0-6qd2",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/liggghts/3.8.0-gcc-8.3.0-6qd2",
          ["help"] = [[
Discrete element method particle simulation.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000003.000000008.*gcc.*zfinal-.000000008.000000003.*zfinal-.000000006.*qd.000000002.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/liggghts-3.8.0-6qd234feeq5cmnmeqa5ecddx7mara7ax/bin"] = 1,
          },
          ["wV"] = "000000003.000000008.*gcc.*zfinal-.000000008.000000003.*zfinal-.000000006.*qd.000000002.*zfinal",
          whatis = {
            "Discrete element method particle simulation. ",
          },
        },
      },
    },
    mummer = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mummer/3.23-gcc-8.3.0-qz7p"]  = {
          ["Version"] = "3.23-gcc-8.3.0-qz7p",
          ["canonical"] = "3.23-gcc-8.3.0-qz7p",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/mummer/3.23-gcc-8.3.0-qz7p",
          ["help"] = [[
MUMmer is a system for rapidly aligning entire genomes.

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000003.000000023.*gcc.*zfinal-.000000008.000000003.*qz.000000007.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/mummer-3.23-qz7pnanh4fmm2x2og7u7lhxpxmzyhwnt/bin"] = 1,
          },
          ["wV"] = "000000003.000000023.*gcc.*zfinal-.000000008.000000003.*qz.000000007.*zfinal",
          whatis = {
            "MUMmer is a system for rapidly aligning entire genomes. ",
          },
        },
      },
    },
    openfoam = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openfoam/1912-gcc-8.3.0-h26j"]  = {
          ["Version"] = "1912-gcc-8.3.0-h26j",
          ["canonical"] = "1912-gcc-8.3.0-h26j",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/openfoam/1912-gcc-8.3.0-h26j",
          ["help"] = [[
OpenFOAM is a GPL-opensource C++ CFD-toolbox. This offering is supported
by OpenCFD Ltd, producer and distributor of the OpenFOAM software via
www.openfoam.com, and owner of the OPENFOAM trademark. OpenCFD Ltd has
been developing and releasing OpenFOAM since its debut in 2004.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/adios2-2.7.1-u6qgpl5i4oivycha5nxeesbqr5quqalc/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/boost-1.69.0-r5uiw7l45fpyht6py7zbr3e5xltmgre5/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/cgal-4.13-e4sityv6xuczlfpupl53zdrfxs3jubln/lib64"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-1912-h26jyt3x73bcc32rizgyvzlh463yxpp5/platforms/linux64GccDPInt32-spack/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-1912-h26jyt3x73bcc32rizgyvzlh463yxpp5/platforms/linux64GccDPInt32-spack/lib/dummy"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-1912-h26jyt3x73bcc32rizgyvzlh463yxpp5/platforms/linux64GccDPInt32-spack/lib/mpi-user"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-1912-h26jyt3x73bcc32rizgyvzlh463yxpp5/site/1912/platforms/linux64GccDPInt32-spack/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openmpi-4.1.1-lw4ni75fo755xtyjkechnw7kojg6wjzq/lib"] = 1,
            ["/home/samir/OpenFOAM/samir-v1912/platforms/linux64GccDPInt32-spack/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000001912.*gcc.*zfinal-.000000008.000000003.*h.000000026.*j.*zfinal",
          pathA = {
            ["/home/apps/spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/adios2-2.7.1-jdffgceskegfyppgd7sz5wscrlzejk4m/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-mpi-2019.10.317-r5sbvpwalgjzykz3erbhc7zem2izbbk6/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-mpi-2019.10.317-r5sbvpwalgjzykz3erbhc7zem2izbbk6/compilers_and_libraries_2020.4.317/linux/mpi/intel64/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/intel-mpi-2019.10.317-r5sbvpwalgjzykz3erbhc7zem2izbbk6/compilers_and_libraries_2020.4.317/linux/mpi/intel64/libfabric/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/libfabric-1.13.2-dkuomw2tr4cg7gou7ditesm2s5urn7wt/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/libpng-1.6.37-ocjolukaviqz7eu6qxd6g6vswwurh3yq/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/lz4-1.9.3-2bfqfviat27t25cy3h72voaxswkmrprc/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/gcc-11.2.0/sz-2.1.12-ka5cfwgxp7pp3n6gl7qpxicegavwctzv/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/autoconf-2.69-ceb7nlwfazf2nkv35fl2mpzdopfxef7t/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/automake-1.16.3-yr3cnmznvpsb2gkbud2etgs2ticprnfs/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/berkeley-db-18.1.40-esdh5smf3v2opaptasw3rw4yi4gjuv33/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/bzip2-1.0.8-7y3kw3kjepchrc47pugpsl5hngesuruw/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/cmake-3.21.3-cuo4onwmtocy6ak6b4t5qel5ci3qsuw4/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/diffutils-3.7-jf4k5sfjkgj5zmydrvpgzfvctljq5gea/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/gdbm-1.19-73vofzong2dedmqcj3ghmr2i5j5peyc5/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/libiconv-1.16-zibyn6qblgbpyowppojogw33zwcy3iep/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/libtool-2.4.6-ycssfzg3eirn6usvs6uziyvc3r3vchgu/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/m4-1.4.19-b74iwrelpjlodqw5syc6sx7yzfgt6dy3/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/ncurses-6.2-gwavpmelqt5lmdvhe634owennh637sgz/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/perl-5.34.0-dchhct5agfdgiedeeq6muwr2tizwupvj/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/pkgconf-1.8.0-5j7y6ulbecusvchbvjocqx2vdk6wvzdm/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.3.0/readline-8.1-fm7n7kcprggo7k5rl4xsvfetu3lfdecz/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/berkeley-db-18.1.40-k4v5w5e55oyalvig4qsiosz55hx6p6ul/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/bzip2-1.0.8-zww6j2hnd5fonaa47qvoboe37pfa3vgf/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/cgal-4.13-t5xzgmqfvf4fz7j52jfyggmkb2hxmnyn/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/cmake-3.22.1-ypqd26gzddhjdzvthnn2ldwxwd4q6k44/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/gdbm-1.19-zljjyx2d5sahvarttqlxkobm4dnk6eo3/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/libiconv-1.16-7cfllhbcqulmjmm4rjo4h7sdw7mjmgr2/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/m4-1.4.19-porwyt5c4olanixr6qkq2mflqkmcuzub/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/ncurses-6.2-ektpnf5cnnktupokudrbtohvlz33qokn/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/openssl-1.1.1l-pcrnjr7ipflb74ljes2nbdhbie5eal5r/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/perl-5.34.0-idlgrwnc3onn5goemgujkvmfzuspcwxx/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/pkgconf-1.8.0-tnxn2au7vc3o7tpsh2jptfqagcy37cmw/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-cascadelake/intel-2021.5.0/readline-8.1-w3y4rqyo56suiibs6q7dd6s62iy63j5u/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/adios2-2.7.1-pj4hsavzughv3l2smee4zdjq3xiy7ibu/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/adios2-2.7.1-u6qgpl5i4oivycha5nxeesbqr5quqalc/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/hwloc-2.6.0-iie5gvzfgfa43uj2flsr3vhnjy7iczml/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libevent-2.1.12-bybtf5avje56fcsbukakjid3zhfumuo4/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libfabric-1.13.2-fj4vq7yhdtm37ryfpxtcw2ovlupxelx4/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libiconv-1.16-yo7stnv474bl6banyp47e55sm7diwzvd/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libpng-1.6.37-ldyzdsgzd54qq7etthys455tyzoubepf/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libtool-2.4.6-di7o36krqjxpix6hp2miinyytm57l6cy/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/libxml2-2.9.12-6ozi2nvu6z5e56jfkjpybg7fgcdjgios/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/lz4-1.9.3-by5dktbxs7zkdheqacyoofkkpklmzqyq/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/numactl-2.0.14-432cuzkvcbfaf4gpfs47zhvpmh4sa24m/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openblas-0.3.18-t435bnt4h2vkl5xabvymxtmouspvo76l/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-1912-h26jyt3x73bcc32rizgyvzlh463yxpp5/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-1912-h26jyt3x73bcc32rizgyvzlh463yxpp5/platforms/linux64GccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-1912-h26jyt3x73bcc32rizgyvzlh463yxpp5/site/1912/platforms/linux64GccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-1912-h26jyt3x73bcc32rizgyvzlh463yxpp5/wmake"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openmpi-4.1.1-lw4ni75fo755xtyjkechnw7kojg6wjzq/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/paraview-5.9.1-2vcxytjwaeesxvk44wniwmk7p77aqp4o/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/pcre-8.44-u24tbrkc4f5ubotlmkndzufutondh45n/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/pkgconf-1.8.0-jfxue7nuw7t7kzqvkc7tykaqh37nckti/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/py-cython-0.29.24-2nvyw4c7cz7ybvx6yuifj4ueroic2e2d/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/py-numpy-1.21.4-4pat3afj3ejevpq7vvrli3xfhm3s534f/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/python-3.9.0-onzi5bwdqu5ti6v4o3bhzqqzsqmfauqn/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/swig-4.0.2-gxvjybkwpf4npfzpr2d2el4pghnazcbj/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/sz-2.1.12-jvcy5vqgf6ysgfm77agoayecctbtv2hb/bin"] = 1,
            ["/home/samir/.local/bin"] = 1,
            ["/home/samir/OpenFOAM/samir-v1912/platforms/linux64GccDPInt32-spack/bin"] = 1,
            ["/home/samir/bin"] = 1,
            ["/home/samir/miniconda3/bin"] = 1,
            ["/home/samir/miniconda3/condabin"] = 1,
            ["/opt/ohpc/pub/bin"] = 1,
            ["/opt/ohpc/pub/compiler/gcc/8.3.0/bin"] = 1,
            ["/opt/ohpc/pub/utils/autotools/bin"] = 1,
            ["/opt/ohpc/pub/utils/prun/1.3"] = 1,
            ["/usr/bin"] = 1,
            ["/usr/lib64/qt-3.3/bin"] = 1,
            ["/usr/local/bin"] = 1,
            ["/usr/local/sbin"] = 1,
            ["/usr/sbin"] = 1,
          },
          ["wV"] = "000001912.*gcc.*zfinal-.000000008.000000003.*h.000000026.*j.*zfinal",
          whatis = {
            "OpenFOAM is a GPL-opensource C++ CFD-toolbox. This offering is supported by OpenCFD Ltd, producer and distributor of the OpenFOAM software via www.openfoam.com, and owner of the OPENFOAM trademark. OpenCFD Ltd has been developing and releasing OpenFOAM since its debut in 2004.  ",
          },
        },
      },
    },
    ["openfoam-org"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openfoam-org/8-gcc-8.3.0-ja5b"]  = {
          ["Version"] = "8-gcc-8.3.0-ja5b",
          ["canonical"] = "8-gcc-8.3.0-ja5b",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/openfoam-org/8-gcc-8.3.0-ja5b",
          ["help"] = [[
OpenFOAM is a GPL-opensource C++ CFD-toolbox. The openfoam.org release
is managed by the OpenFOAM Foundation Ltd as a licensee of the OPENFOAM
trademark. This offering is not approved or endorsed by OpenCFD Ltd,
producer and distributor of the OpenFOAM software via www.openfoam.com,
and owner of the OPENFOAM trademark.

]],
          lpathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/ThirdParty/platforms/linux64GccDPInt32/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/ThirdParty/platforms/linux64GccDPInt32/lib/mpi-system"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/platforms/linux64GccDPInt32-spack/lib"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/platforms/linux64GccDPInt32-spack/lib/dummy"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/platforms/linux64GccDPInt32-spack/lib/mpi-system"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/site/8/platforms/linux64GccDPInt32-spack/lib"] = 1,
            ["/home/samir/OpenFOAM/samir-8/platforms/linux64GccDPInt32-spack/lib"] = 1,
          },
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000008.*gcc.*zfinal-.000000008.000000003.*ja.000000005.*b.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/platforms/linux64GccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/site/8/platforms/linux64GccDPInt32-spack/bin"] = 1,
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openfoam-org-8-ja5b2jp4kbxtetnnbr5tpbwfawt27hak/wmake"] = 1,
            ["/home/samir/OpenFOAM/samir-8/platforms/linux64GccDPInt32-spack/bin"] = 1,
          },
          ["wV"] = "000000008.*gcc.*zfinal-.000000008.000000003.*ja.000000005.*b.*zfinal",
          whatis = {
            "OpenFOAM is a GPL-opensource C++ CFD-toolbox. The openfoam.org release is managed by the OpenFOAM Foundation Ltd as a licensee of the OPENFOAM trademark. This offering is not approved or endorsed by OpenCFD Ltd, producer and distributor of the OpenFOAM software via www.openfoam.com, and owner of the OPENFOAM trademark.  ",
          },
        },
      },
    },
    phylip = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["phylip/3.697-gcc-8.3.0-ajvm"]  = {
          ["Version"] = "3.697-gcc-8.3.0-ajvm",
          ["canonical"] = "3.697-gcc-8.3.0-ajvm",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/phylip/3.697-gcc-8.3.0-ajvm",
          ["help"] = [[
PHYLIP (the PHYLogeny Inference Package) is a package of programs for
inferring phylogenies (evolutionary trees).

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000003.000000697.*gcc.*zfinal-.000000008.000000003.*ajvm.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/phylip-3.697-ajvmwtbz75a233gji5ih5hgv76m3tf2l/bin"] = 1,
          },
          ["wV"] = "000000003.000000697.*gcc.*zfinal-.000000008.000000003.*ajvm.*zfinal",
          whatis = {
            "PHYLIP (the PHYLogeny Inference Package) is a package of programs for inferring phylogenies (evolutionary trees). ",
          },
        },
      },
    },
    regcm = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["regcm/4.7.0-gcc-8.3.0-gg4p"]  = {
          ["Version"] = "4.7.0-gcc-8.3.0-gg4p",
          ["canonical"] = "4.7.0-gcc-8.3.0-gg4p",
          ["fn"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512/regcm/4.7.0-gcc-8.3.0-gg4p",
          ["help"] = [[
RegCM, ICTP Regional Climate Model (https://ictp.it).

]],
          ["mpath"] = "/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512",
          ["pV"] = "000000004.000000007.*gcc.*zfinal-.000000008.000000003.*gg.000000004.*zfinal",
          pathA = {
            ["/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/regcm-4.7.0-gg4p3kp6y4wffdutqyxd437ig67qgb25/bin"] = 1,
          },
          ["wV"] = "000000004.000000007.*gcc.*zfinal-.000000008.000000003.*gg.000000004.*zfinal",
          whatis = {
            "RegCM, ICTP Regional Climate Model (https://ictp.it). ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/gnu"]  = {
    numpy = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["numpy/.version.1.12.1"]  = {
          ["Version"] = ".version.1.12.1",
          ["canonical"] = ".version.1.12.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu/numpy/.version.1.12.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu",
          ["pV"] = "*version.000000001.000000012.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000012.000000001.*zfinal",
        },
        ["numpy/1.12.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "NumPy array processing for numbers, strings, records and objects ",
          ["Name"] = "numpy built with gnu compiler ",
          ["Version"] = "1.12.1 ",
          ["canonical"] = "1.12.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu/numpy/1.12.1",
          ["help"] = [[
 
This module loads the numpy library built with the gnu compiler
toolchain.

Version 1.12.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu",
          ["pV"] = "000000001.000000012.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu/numpy/1.12.1/bin"] = 1,
          },
          ["wV"] = "000000001.000000012.000000001.*zfinal",
          whatis = {
            "Name: numpy built with gnu compiler ", "Version: 1.12.1 "
            , "Category: python module "
            , "Description: NumPy array processing for numbers, strings, records and objects ", "URL http://sourceforge.net/projects/numpy ",
          },
        },
      },
    },
    openblas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openblas/.version.0.2.20"]  = {
          ["Version"] = ".version.0.2.20",
          ["canonical"] = ".version.0.2.20",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu/openblas/.version.0.2.20",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu",
          ["pV"] = "*version.000000000.000000002.000000020.*zfinal",
          ["wV"] = "*version.000000000.000000002.000000020.*zfinal",
        },
        ["openblas/0.2.20"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "An optimized BLAS library based on GotoBLAS2 ",
          ["Name"] = "OPENBLAS built with gnu toolchain ",
          ["Version"] = "0.2.20 ",
          ["canonical"] = "0.2.20",
          ["family"] = "openblas",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu/openblas/0.2.20",
          ["help"] = [[
 
This module loads the OPENBLAS library built with the gnu compiler toolchain.

Version 0.2.20


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu/openblas/0.2.20/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu",
          ["pV"] = "000000000.000000002.000000020.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu/openblas/0.2.20/bin"] = 1,
          },
          ["wV"] = "000000000.000000002.000000020.*zfinal",
          whatis = {
            "Name: OPENBLAS built with gnu toolchain ", "Version: 0.2.20 "
            , "Category: runtime library "
            , "Description: An optimized BLAS library based on GotoBLAS2 ", "http://www.openblas.net ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/gnu8"]  = {
    R = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["R/.version.3.6.1"]  = {
          ["Version"] = ".version.3.6.1",
          ["canonical"] = ".version.3.6.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/R/.version.3.6.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000003.000000006.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000006.000000001.*zfinal",
        },
        ["R/3.6.1"]  = {
          ["Category"] = "utility, developer support, user tool ",
          ["Description"] = "R is a language and environment for statistical computing and graphics (S-Plus like). ",
          ["Name"] = "R project for statistical computing built with the gnu8 compiler toolchain. ",
          ["Version"] = "3.6.1 ",
          ["canonical"] = "3.6.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/R/3.6.1",
          ["help"] = [[
 
This module loads the R package for statistical computing.

Version 3.6.1

 

]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/R/3.6.1/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000003.000000006.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/R/3.6.1/bin"] = 1,
          },
          ["wV"] = "000000003.000000006.000000001.*zfinal",
          whatis = {

                        "Name: R project for statistical computing built with the gnu8 compiler toolchain. "
            , "Version: 3.6.1 ", "Category: utility, developer support, user tool "
            , "Keywords: Statistics "
            , "Description: R is a language and environment for statistical computing and graphics (S-Plus like). ", "URL http://www.r-project.org/ ",
          },
        },
      },
    },
    gsl = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gsl/.version.2.6"]  = {
          ["Version"] = ".version.2.6",
          ["canonical"] = ".version.2.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/gsl/.version.2.6",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000002.000000006.*zfinal",
          ["wV"] = "*version.000000002.000000006.*zfinal",
        },
        ["gsl/2.6"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "GNU Scientific Library (GSL) ",
          ["Name"] = "GSL built with gnu8 toolchain ",
          ["Version"] = "2.6 ",
          ["canonical"] = "2.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/gsl/2.6",
          ["help"] = [[
 
This module loads the GSL library built with the gnu8 compiler toolchain.

Version 2.6


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/gsl/2.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000002.000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/gsl/2.6/bin"] = 1,
          },
          ["wV"] = "000000002.000000006.*zfinal",
          whatis = {
            "Name: GSL built with gnu8 toolchain ", "Version: 2.6 "
            , "Category: runtime library ", "Description: GNU Scientific Library (GSL) ", "http://www.gnu.org/software/gsl ",
          },
        },
      },
    },
    hdf5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hdf5/.version.1.10.5"]  = {
          ["Version"] = ".version.1.10.5",
          ["canonical"] = ".version.1.10.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/hdf5/.version.1.10.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000001.000000010.000000005.*zfinal",
          ["wV"] = "*version.000000001.000000010.000000005.*zfinal",
        },
        ["hdf5/1.10.5"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library and file format for storing scientific data ",
          ["Name"] = "HDF5 built with gnu8 toolchain ",
          ["Version"] = "1.10.5 ",
          ["canonical"] = "1.10.5",
          ["family"] = "hdf5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/hdf5/1.10.5",
          ["help"] = [[
 
This module loads the HDF5 library built with the gnu8 compiler toolchain.

Version 1.10.5


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/hdf5/1.10.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000001.000000010.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/hdf5/1.10.5/bin"] = 1,
          },
          ["wV"] = "000000001.000000010.000000005.*zfinal",
          whatis = {
            "Name: HDF5 built with gnu8 toolchain ", "Version: 1.10.5 "
            , "Category: runtime library "
            , "Description: A general purpose library and file format for storing scientific data ", "http://www.hdfgroup.org/HDF5 ",
          },
        },
      },
    },
    likwid = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["likwid/.version.4.3.4"]  = {
          ["Version"] = ".version.4.3.4",
          ["canonical"] = ".version.4.3.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/likwid/.version.4.3.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000004.000000003.000000004.*zfinal",
          ["wV"] = "*version.000000004.000000003.000000004.*zfinal",
        },
        ["likwid/4.3.4"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Toolsuite of command line applications for performance oriented programmers ",
          ["Name"] = "likwid built with gnu8 compiler ",
          ["Version"] = "4.3.4 ",
          ["canonical"] = "4.3.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/likwid/4.3.4",
          ["help"] = [[
 
This module loads the likwid library built with the gnu8 compiler
toolchain.

Version 4.3.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/likwid/4.3.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000004.000000003.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/likwid/4.3.4/bin"] = 1,
          },
          ["wV"] = "000000004.000000003.000000004.*zfinal",
          whatis = {
            "Name: likwid built with gnu8 compiler ", "Version: 4.3.4 "
            , "Category: performance tool "
            , "Description: Toolsuite of command line applications for performance oriented programmers ", "URL https://github.com/RRZE-HPC/likwid ",
          },
        },
      },
    },
    metis = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["metis/.version.5.1.0"]  = {
          ["Version"] = ".version.5.1.0",
          ["canonical"] = ".version.5.1.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/metis/.version.5.1.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000005.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000001.*zfinal",
        },
        ["metis/5.1.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Metis development files ",
          ["Name"] = "METIS built with gnu8 toolchain ",
          ["Version"] = "5.1.0 ",
          ["canonical"] = "5.1.0",
          ["family"] = "metis",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/metis/5.1.0",
          ["help"] = [[
 
This module loads the METIS library built with the gnu8 compiler toolchain.

Version 5.1.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/metis/5.1.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000005.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/metis/5.1.0/bin"] = 1,
          },
          ["wV"] = "000000005.000000001.*zfinal",
          whatis = {
            "Name: METIS built with gnu8 toolchain ", "Version: 5.1.0 "
            , "Category: runtime library ", "Description: Metis development files ", "http://glaros.dtc.umn.edu/gkhome/metis/metis/overview ",
          },
        },
      },
    },
    mpich = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mpich/.version.3.3.1"]  = {
          ["Version"] = ".version.3.3.1",
          ["canonical"] = ".version.3.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/mpich/.version.3.3.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000003.000000003.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000003.000000001.*zfinal",
        },
        ["mpich/3.3.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "MPICH MPI implementation ",
          ["Name"] = "mpich built with gnu8 toolchain ",
          ["URL"] = "http://www.mpich.org ",
          ["Version"] = "3.3.1 ",
          ["canonical"] = "3.3.1",
          ["family"] = "MPI",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/mpich/3.3.1",
          ["help"] = [[
 
This module loads the mpich library built with the gnu8 toolchain.

Version 3.3.1


]],
          lpathA = {
            ["/opt/ohpc/pub/mpi/mpich-gnu8-ohpc/3.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000003.000000003.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/mpi/mpich-gnu8-ohpc/3.3.1/bin"] = 1,
          },
          ["wV"] = "000000003.000000003.000000001.*zfinal",
          whatis = {
            "Name: mpich built with gnu8 toolchain ", "Version: 3.3.1 "
            , "Category: runtime library ", "Description: MPICH MPI implementation ", "URL: http://www.mpich.org ",
          },
        },
      },
    },
    mvapich2 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mvapich2/.version.2.3.2"]  = {
          ["Version"] = ".version.2.3.2",
          ["canonical"] = ".version.2.3.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/mvapich2/.version.2.3.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000002.000000003.000000002.*zfinal",
          ["wV"] = "*version.000000002.000000003.000000002.*zfinal",
        },
        ["mvapich2/2.3.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "OSU MVAPICH2 MPI implementation ",
          ["Name"] = "mvapich2 built with gnu8 toolchain ",
          ["URL"] = "http://mvapich.cse.ohio-state.edu ",
          ["Version"] = "2.3.2 ",
          ["canonical"] = "2.3.2",
          ["family"] = "MPI",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/mvapich2/2.3.2",
          ["help"] = [[
 
This module loads the mvapich2 library built with the gnu8 toolchain.

Version 2.3.2


]],
          lpathA = {
            ["/opt/ohpc/pub/mpi/mvapich2-gnu8/2.3.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000002.000000003.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/mpi/mvapich2-gnu8/2.3.2/bin"] = 1,
          },
          ["wV"] = "000000002.000000003.000000002.*zfinal",
          whatis = {
            "Name: mvapich2 built with gnu8 toolchain ", "Version: 2.3.2 "
            , "Category: runtime library ", "Description: OSU MVAPICH2 MPI implementation ", "URL: http://mvapich.cse.ohio-state.edu ",
          },
        },
      },
    },
    ocr = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ocr/.version.1.0.1"]  = {
          ["Version"] = ".version.1.0.1",
          ["canonical"] = ".version.1.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/ocr/.version.1.0.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000001.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000000.000000001.*zfinal",
        },
        ["ocr/1.0.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Open Community Runtime (OCR) for shared memory ",
          ["Name"] = "OCR for shared memory built with gnu8 toolchain ",
          ["Version"] = "1.0.1 ",
          ["canonical"] = "1.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/ocr/1.0.1",
          ["help"] = [[
 
This module loads the OCR library built with the gnu8 compiler toolchain for shared memory

Version 1.0.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/ocr/1.0.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000001.000000000.000000001.*zfinal",
          ["wV"] = "000000001.000000000.000000001.*zfinal",
          whatis = {
            "Name: OCR for shared memory built with gnu8 toolchain ", "Version: 1.0.1 "
            , "Category: runtime library "
            , "Description: Open Community Runtime (OCR) for shared memory ", "https://xstack.exascale-tech.com/wiki ",
          },
        },
      },
    },
    openblas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openblas/.version.0.3.7"]  = {
          ["Version"] = ".version.0.3.7",
          ["canonical"] = ".version.0.3.7",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/openblas/.version.0.3.7",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000000.000000003.000000007.*zfinal",
          ["wV"] = "*version.000000000.000000003.000000007.*zfinal",
        },
        ["openblas/0.3.7"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "An optimized BLAS library based on GotoBLAS2 ",
          ["Name"] = "OPENBLAS built with gnu8 toolchain ",
          ["Version"] = "0.3.7 ",
          ["canonical"] = "0.3.7",
          ["family"] = "openblas",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/openblas/0.3.7",
          ["help"] = [[
 
This module loads the OPENBLAS library built with the gnu8 compiler toolchain.

Version 0.3.7


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/openblas/0.3.7/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000000.000000003.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/openblas/0.3.7/bin"] = 1,
          },
          ["wV"] = "000000000.000000003.000000007.*zfinal",
          whatis = {
            "Name: OPENBLAS built with gnu8 toolchain ", "Version: 0.3.7 "
            , "Category: runtime library "
            , "Description: An optimized BLAS library based on GotoBLAS2 ", "http://www.openblas.net ",
          },
        },
      },
    },
    pdtoolkit = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["pdtoolkit/.version.3.25"]  = {
          ["Version"] = ".version.3.25",
          ["canonical"] = ".version.3.25",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/pdtoolkit/.version.3.25",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000003.000000025.*zfinal",
          ["wV"] = "*version.000000003.000000025.*zfinal",
        },
        ["pdtoolkit/3.25"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "PDT is a framework for analyzing source code ",
          ["Name"] = "pdtoolkit built with gnu8 compiler ",
          ["Version"] = "3.25 ",
          ["canonical"] = "3.25",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/pdtoolkit/3.25",
          ["help"] = [[
 
This module loads the pdtoolkit library built with the gnu8 compiler
toolchain.

Version 3.25


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/pdtoolkit/3.25/x86_64/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000003.000000025.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/pdtoolkit/3.25/x86_64/bin"] = 1,
          },
          ["wV"] = "000000003.000000025.*zfinal",
          whatis = {
            "Name: pdtoolkit built with gnu8 compiler ", "Version: 3.25 "
            , "Category: runtime library "
            , "Description: PDT is a framework for analyzing source code ", "URL http://www.cs.uoregon.edu/Research/pdt ",
          },
        },
      },
    },
    plasma = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["plasma/2.8.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Parallel Linear Algebra Software for Multicore Architectures ",
          ["Name"] = "plasma built with gnu8 compiler ",
          ["Version"] = "2.8.0 ",
          ["canonical"] = "2.8.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/plasma/2.8.0",
          ["help"] = [[
 
This module loads the plasma library built with the gnu8 compiler
toolchain.

Version 2.8.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/plasma/2.8.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000002.000000008.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/plasma/2.8.0/bin"] = 1,
          },
          ["wV"] = "000000002.000000008.*zfinal",
          whatis = {
            "Name: plasma built with gnu8 compiler ", "Version: 2.8.0 "
            , "Category: runtime library "
            , "Description: Parallel Linear Algebra Software for Multicore Architectures ", "URL https://bitbucket.org/icl/plasma ",
          },
        },
      },
    },
    ["py2-numpy"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-numpy/.version.1.15.3"]  = {
          ["Version"] = ".version.1.15.3",
          ["canonical"] = ".version.1.15.3",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/py2-numpy/.version.1.15.3",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000001.000000015.000000003.*zfinal",
          ["wV"] = "*version.000000001.000000015.000000003.*zfinal",
        },
        ["py2-numpy/1.15.3"]  = {
          ["Category"] = "python module ",
          ["Description"] = "NumPy array processing for numbers, strings, records and objects ",
          ["Name"] = "python-numpy built with gnu8 compiler ",
          ["Version"] = "1.15.3 ",
          ["canonical"] = "1.15.3",
          ["family"] = "numpy",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/py2-numpy/1.15.3",
          ["help"] = [[
 
This module loads the numpy library built with python
and the gnu8 compiler toolchain.

Version 1.15.3


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000001.000000015.000000003.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/numpy/1.15.3/bin"] = 1,
          },
          ["wV"] = "000000001.000000015.000000003.*zfinal",
          whatis = {
            "Name: python-numpy built with gnu8 compiler ", "Version: 1.15.3 "
            , "Category: python module "
            , "Description: NumPy array processing for numbers, strings, records and objects ", "URL http://sourceforge.net/projects/numpy ",
          },
        },
      },
    },
    ["py3-numpy"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-numpy/.version.1.15.3"]  = {
          ["Version"] = ".version.1.15.3",
          ["canonical"] = ".version.1.15.3",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/py3-numpy/.version.1.15.3",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000001.000000015.000000003.*zfinal",
          ["wV"] = "*version.000000001.000000015.000000003.*zfinal",
        },
        ["py3-numpy/1.15.3"]  = {
          ["Category"] = "python module ",
          ["Description"] = "NumPy array processing for numbers, strings, records and objects ",
          ["Name"] = "python34-numpy built with gnu8 compiler ",
          ["Version"] = "1.15.3 ",
          ["canonical"] = "1.15.3",
          ["family"] = "numpy",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/py3-numpy/1.15.3",
          ["help"] = [[
 
This module loads the numpy library built with python34
and the gnu8 compiler toolchain.

Version 1.15.3


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000001.000000015.000000003.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/numpy/1.15.3/bin"] = 1,
          },
          ["wV"] = "000000001.000000015.000000003.*zfinal",
          whatis = {
            "Name: python34-numpy built with gnu8 compiler ", "Version: 1.15.3 "
            , "Category: python module "
            , "Description: NumPy array processing for numbers, strings, records and objects ", "URL http://sourceforge.net/projects/numpy ",
          },
        },
      },
    },
    scotch = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scotch/6.0.6"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Graph, mesh and hypergraph partitioning library ",
          ["Name"] = "scotch built with gnu8 compiler ",
          ["Version"] = "6.0.6 ",
          ["canonical"] = "6.0.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/scotch/6.0.6",
          ["help"] = [[
 
This module loads the scotch library built with the gnu8 compiler
toolchain.

Version 6.0.6


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/scotch/6.0.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000006.000000000.000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/scotch/6.0.6/bin"] = 1,
          },
          ["wV"] = "000000006.000000000.000000006.*zfinal",
          whatis = {
            "Name: scotch built with gnu8 compiler ", "Version: 6.0.6 "
            , "Category: runtime library "
            , "Description: Graph, mesh and hypergraph partitioning library ", "URL http://www.labri.fr/perso/pelegrin/scotch/ ",
          },
        },
      },
    },
    superlu = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["superlu/.version.5.2.1"]  = {
          ["Version"] = ".version.5.2.1",
          ["canonical"] = ".version.5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/superlu/.version.5.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "*version.000000005.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000002.000000001.*zfinal",
        },
        ["superlu/5.2.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library for the direct solution of linear equations ",
          ["Name"] = "superlu built with gnu8 compiler ",
          ["Version"] = "5.2.1 ",
          ["canonical"] = "5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8/superlu/5.2.1",
          ["help"] = [[
 
This module loads the SuperLU library built with the gnu8 compiler
toolchain.
 
Note that this build of SuperLU leverages the OpenBLAS linear algebra libraries.
Consequently, openblas is loaded automatically with this module.

Version 5.2.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/superlu/5.2.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8",
          ["pV"] = "000000005.000000002.000000001.*zfinal",
          ["wV"] = "000000005.000000002.000000001.*zfinal",
          whatis = {
            "Name: superlu built with gnu8 compiler ", "Version: 5.2.1 "
            , "Category: runtime library "
            , "Description: A general purpose library for the direct solution of linear equations ", "http://crd.lbl.gov/~xiaoye/SuperLU/ ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/gnu8-mpich"]  = {
    adios = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["adios/.version.1.13.1"]  = {
          ["Version"] = ".version.1.13.1",
          ["canonical"] = ".version.1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/adios/.version.1.13.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000001.000000013.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000013.000000001.*zfinal",
        },
        ["adios/1.13.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "The Adaptable IO System (ADIOS) ",
          ["Name"] = "ADIOS built with gnu8 compiler and mpich MPI ",
          ["Version"] = "1.13.1 ",
          ["canonical"] = "1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/adios/1.13.1",
          ["help"] = [[
 
This module loads the ADIOS library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 1.13.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/adios/1.13.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000001.000000013.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/adios/1.13.1/bin"] = 1,
          },
          ["wV"] = "000000001.000000013.000000001.*zfinal",
          whatis = {
            "Name: ADIOS built with gnu8 compiler and mpich MPI ", "Version: 1.13.1 "
            , "Category: runtime library ", "Description: The Adaptable IO System (ADIOS) ", "http://www.olcf.ornl.gov/center-projects/adios/ ",
          },
        },
      },
    },
    boost = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["boost/.version.1.71.0"]  = {
          ["Version"] = ".version.1.71.0",
          ["canonical"] = ".version.1.71.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/boost/.version.1.71.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000001.000000071.*zfinal",
          ["wV"] = "*version.000000001.000000071.*zfinal",
        },
        ["boost/1.71.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Boost free peer-reviewed portable C++ source libraries ",
          ["Name"] = "BOOST built with gnu8 compiler and mpich MPI ",
          ["Version"] = "1.71.0 ",
          ["canonical"] = "1.71.0",
          ["family"] = "boost",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/boost/1.71.0",
          ["help"] = [[
 
This module loads the BOOST library built with the gnu8 compiler toolchain
and the mpich MPI stack.

Version 1.71.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/boost/1.71.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000001.000000071.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/boost/1.71.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000071.*zfinal",
          whatis = {
            "Name: BOOST built with gnu8 compiler and mpich MPI ", "Version: 1.71.0 "
            , "Category: runtime library "
            , "Description: Boost free peer-reviewed portable C++ source libraries ", "http://www.boost.org ",
          },
        },
      },
    },
    dimemas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["dimemas/.version.5.4.1"]  = {
          ["Version"] = ".version.5.4.1",
          ["canonical"] = ".version.5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/dimemas/.version.5.4.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000005.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000004.000000001.*zfinal",
        },
        ["dimemas/5.4.1"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Dimemas tool ",
          ["Name"] = "dimemas built with gnu8 compiler and mpich MPI ",
          ["Version"] = "5.4.1 ",
          ["canonical"] = "5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/dimemas/5.4.1",
          ["help"] = [[
 
This module loads the dimemas library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 5.4.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000005.000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/dimemas/5.4.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000004.000000001.*zfinal",
          whatis = {
            "Name: dimemas built with gnu8 compiler and mpich MPI ", "Version: 5.4.1 "
            , "Category: performance tool ", "Description: Dimemas tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    extrae = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["extrae/.version.3.7.0"]  = {
          ["Version"] = ".version.3.7.0",
          ["canonical"] = ".version.3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/extrae/.version.3.7.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000003.000000007.*zfinal",
          ["wV"] = "*version.000000003.000000007.*zfinal",
        },
        ["extrae/3.7.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Extrae tool ",
          ["Name"] = "extrae built with gnu8 compiler and mpich MPI ",
          ["Version"] = "3.7.0 ",
          ["canonical"] = "3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/extrae/3.7.0",
          ["help"] = [[
 
This module loads the extrae library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 3.7.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/extrae/3.7.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/extrae/3.7.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
          whatis = {
            "Name: extrae built with gnu8 compiler and mpich MPI ", "Version: 3.7.0 "
            , "Category: performance tool ", "Description: Extrae tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    fftw = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["fftw/.version.3.3.8"]  = {
          ["Version"] = ".version.3.3.8",
          ["canonical"] = ".version.3.3.8",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/fftw/.version.3.3.8",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000003.000000003.000000008.*zfinal",
          ["wV"] = "*version.000000003.000000003.000000008.*zfinal",
        },
        ["fftw/3.3.8"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A Fast Fourier Transform library ",
          ["Name"] = "fftw built with gnu8 compiler and mpich MPI ",
          ["Version"] = "3.3.8 ",
          ["canonical"] = "3.3.8",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/fftw/3.3.8",
          ["help"] = [[
 
This module loads the fftw library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 3.3.8


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/fftw/3.3.8/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000003.000000003.000000008.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/fftw/3.3.8/bin"] = 1,
          },
          ["wV"] = "000000003.000000003.000000008.*zfinal",
          whatis = {
            "Name: fftw built with gnu8 compiler and mpich MPI ", "Version: 3.3.8 "
            , "Category: runtime library ", "Description: A Fast Fourier Transform library ", "URL http://www.fftw.org ",
          },
        },
      },
    },
    hypre = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hypre/.version.2.18.1"]  = {
          ["Version"] = ".version.2.18.1",
          ["canonical"] = ".version.2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/hypre/.version.2.18.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000002.000000018.000000001.*zfinal",
          ["wV"] = "*version.000000002.000000018.000000001.*zfinal",
        },
        ["hypre/2.18.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Scalable algorithms for solving linear systems of equations ",
          ["Name"] = "hypre built with gnu8 compiler and mpich MPI ",
          ["Version"] = "2.18.1 ",
          ["canonical"] = "2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/hypre/2.18.1",
          ["help"] = [[
 
This module loads the hypre library built with the gnu8 compiler
toolchain and the mpich MPI stack.
 
Note that this build of hypre leverages the superlu and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 2.18.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/hypre/2.18.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000002.000000018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/hypre/2.18.1/bin"] = 1,
          },
          ["wV"] = "000000002.000000018.000000001.*zfinal",
          whatis = {
            "Name: hypre built with gnu8 compiler and mpich MPI ", "Version: 2.18.1 "
            , "Category: runtime library "
            , "Description: Scalable algorithms for solving linear systems of equations ", "http://www.llnl.gov/casc/hypre/ ",
          },
        },
      },
    },
    imb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["imb/.version.2018.1"]  = {
          ["Version"] = ".version.2018.1",
          ["canonical"] = ".version.2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/imb/.version.2018.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000002018.000000001.*zfinal",
          ["wV"] = "*version.000002018.000000001.*zfinal",
        },
        ["imb/2018.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Intel MPI Benchmarks (IMB) ",
          ["Name"] = "imb built with gnu8 compiler and mpich MPI ",
          ["Version"] = "2018.1 ",
          ["canonical"] = "2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/imb/2018.1",
          ["help"] = [[
 
This module loads the imb library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 2018.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000002018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/imb/2018.1/bin"] = 1,
          },
          ["wV"] = "000002018.000000001.*zfinal",
          whatis = {
            "Name: imb built with gnu8 compiler and mpich MPI ", "Version: 2018.1 "
            , "Category: runtime library ", "Description: Intel MPI Benchmarks (IMB) ", "URL https://software.intel.com/en-us/articles/intel-mpi-benchmarks ",
          },
        },
      },
    },
    mfem = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mfem/.version.4.0"]  = {
          ["Version"] = ".version.4.0",
          ["canonical"] = ".version.4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/mfem/.version.4.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000004.*zfinal",
          ["wV"] = "*version.000000004.*zfinal",
        },
        ["mfem/4.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Lightweight, general, scalable C++ library for finite element methods ",
          ["Name"] = "mfem built with gnu8 compiler and mpich MPI ",
          ["Version"] = "4.0 ",
          ["canonical"] = "4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/mfem/4.0",
          ["help"] = [[
 
This module loads the MFEM library built with the gnu8 compiler
toolchain and the mpich MPI stack.
 

Version 4.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/mfem/4.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/mfem/4.0/bin"] = 1,
          },
          ["wV"] = "000000004.*zfinal",
          whatis = {
            "Name: mfem built with gnu8 compiler and mpich MPI ", "Version: 4.0 "
            , "Category: runtime library "
            , "Description: Lightweight, general, scalable C++ library for finite element methods ", "http://mfem.org ",
          },
        },
      },
    },
    mpiP = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mpiP/.version.3.4.1"]  = {
          ["Version"] = ".version.3.4.1",
          ["canonical"] = ".version.3.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/mpiP/.version.3.4.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000003.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000004.000000001.*zfinal",
        },
        ["mpiP/3.4.1"]  = {
          ["Category"] = "Profiling library ",
          ["Description"] = "mpiP: a lightweight profiling library for MPI applications. ",
          ["Name"] = "mpiP built with gnu8 compiler and mpich MPI ",
          ["Version"] = "3.4.1 ",
          ["canonical"] = "3.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/mpiP/3.4.1",
          ["help"] = [[
 
This module loads the mpiP library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 3.4.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/mpiP/3.4.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000003.000000004.000000001.*zfinal",
          ["wV"] = "000000003.000000004.000000001.*zfinal",
          whatis = {
            "Name: mpiP built with gnu8 compiler and mpich MPI ", "Version: 3.4.1 "
            , "Category: Profiling library "
            , "Description: mpiP: a lightweight profiling library for MPI applications. ", "URL http://mpip.sourceforge.net/ ",
          },
        },
      },
    },
    mumps = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mumps/.version.5.2.1"]  = {
          ["Version"] = ".version.5.2.1",
          ["canonical"] = ".version.5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/mumps/.version.5.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000005.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000002.000000001.*zfinal",
        },
        ["mumps/5.2.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A MUltifrontal Massively Parallel Sparse direct Solver ",
          ["Name"] = "mumps built with gnu8 compiler and mpich MPI ",
          ["Version"] = "5.2.1 ",
          ["canonical"] = "5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/mumps/5.2.1",
          ["help"] = [[
 
This module loads the mumps library built with the gnu8 compiler
toolchain and the mpich MPI stack.
 

Version 5.2.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/mumps/5.2.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000005.000000002.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/mumps/5.2.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000002.000000001.*zfinal",
          whatis = {
            "Name: mumps built with gnu8 compiler and mpich MPI ", "Version: 5.2.1 "
            , "Category: runtime library "
            , "Description: A MUltifrontal Massively Parallel Sparse direct Solver ", "http://mumps.enseeiht.fr/ ",
          },
        },
      },
    },
    netcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf/.version.4.7.1"]  = {
          ["Version"] = ".version.4.7.1",
          ["canonical"] = ".version.4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/netcdf/.version.4.7.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000004.000000007.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000007.000000001.*zfinal",
        },
        ["netcdf/4.7.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF built with gnu8 toolchain ",
          ["Version"] = "4.7.1 ",
          ["canonical"] = "4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/netcdf/4.7.1",
          ["help"] = [[
 
This module loads the NetCDF C API built with the gnu8 compiler
toolchain and the mpich MPI stack.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5. Consequently, the phdf5 package is loaded automatically with this module.
A typical compilation step for C applications requiring NetCDF is as follows:
 
$CC -I$NETCDF_INC app.c -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.7.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/netcdf/4.7.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000004.000000007.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/netcdf/4.7.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000007.000000001.*zfinal",
          whatis = {
            "Name: NETCDF built with gnu8 toolchain ", "Version: 4.7.1 "
            , "Category: runtime library "
            , "Description: C Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-cxx"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-cxx/.version.4.3.1"]  = {
          ["Version"] = ".version.4.3.1",
          ["canonical"] = ".version.4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/netcdf-cxx/.version.4.3.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000004.000000003.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000003.000000001.*zfinal",
        },
        ["netcdf-cxx/4.3.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C++ Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_CXX built with gnu8 toolchain ",
          ["Version"] = "4.3.1 ",
          ["canonical"] = "4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/netcdf-cxx/4.3.1",
          ["help"] = [[
 
This module loads the NetCDF C++ API built with the gnu8 compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for C++ applications requiring NetCDF is as follows:
 
$CXX -I$NETCDF_CXX_INC app.cpp -L$NETCDF_CXX_LIB -lnetcdf_c++4 -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.3.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/netcdf-cxx/4.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000004.000000003.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/netcdf-cxx/4.3.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000003.000000001.*zfinal",
          whatis = {
            "Name: NETCDF_CXX built with gnu8 toolchain ", "Version: 4.3.1 "
            , "Category: runtime library "
            , "Description: C++ Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-fortran"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-fortran/.version.4.5.2"]  = {
          ["Version"] = ".version.4.5.2",
          ["canonical"] = ".version.4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/netcdf-fortran/.version.4.5.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000004.000000005.000000002.*zfinal",
          ["wV"] = "*version.000000004.000000005.000000002.*zfinal",
        },
        ["netcdf-fortran/4.5.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Fortran Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_FORTRAN built with gnu8 toolchain ",
          ["Version"] = "4.5.2 ",
          ["canonical"] = "4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/netcdf-fortran/4.5.2",
          ["help"] = [[
 
This module loads the NetCDF Fortran API built with the gnu8 compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for Fortran applications requiring NetCDF is as follows:
 

]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/netcdf-fortran/4.5.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000004.000000005.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/netcdf-fortran/4.5.2/bin"] = 1,
          },
          ["wV"] = "000000004.000000005.000000002.*zfinal",
          whatis = {
            "Name: NETCDF_FORTRAN built with gnu8 toolchain ", "Version: 4.5.2 "
            , "Category: runtime library "
            , "Description: Fortran Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    omb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["omb/.version.5.6.2"]  = {
          ["Version"] = ".version.5.6.2",
          ["canonical"] = ".version.5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/omb/.version.5.6.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000005.000000006.000000002.*zfinal",
          ["wV"] = "*version.000000005.000000006.000000002.*zfinal",
        },
        ["omb/5.6.2"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "OSU Micro-benchmarks ",
          ["Name"] = "OSU Micro-benchmarks built with gnu8 compiler and mpich MPI ",
          ["Version"] = "5.6.2 ",
          ["canonical"] = "5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/omb/5.6.2",
          ["help"] = [[
 
This module loads the OSU Micro-benchmarks built with the gnu8 toolchain
and the mpich MPI stack.

Version 5.6.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000005.000000006.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/omb/5.6.2/bin/osu-micro-benchmarks/mpi/collective"] = 1,
            ["/opt/ohpc/pub/libs/gnu8/mpich/omb/5.6.2/bin/osu-micro-benchmarks/mpi/one-sided"] = 1,
            ["/opt/ohpc/pub/libs/gnu8/mpich/omb/5.6.2/bin/osu-micro-benchmarks/mpi/pt2pt"] = 1,
            ["/opt/ohpc/pub/libs/gnu8/mpich/omb/5.6.2/bin/osu-micro-benchmarks/mpi/startup"] = 1,
          },
          ["wV"] = "000000005.000000006.000000002.*zfinal",
          whatis = {
            "Name: OSU Micro-benchmarks built with gnu8 compiler and mpich MPI "
            , "Version: 5.6.2 ", "Category: performance tool "
            , "Description: OSU Micro-benchmarks ", "http://mvapich.cse.ohio-state.edu/benchmarks/ ",
          },
        },
      },
    },
    opencoarrays = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["opencoarrays/.version.2.8.0"]  = {
          ["Version"] = ".version.2.8.0",
          ["canonical"] = ".version.2.8.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/opencoarrays/.version.2.8.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000002.000000008.*zfinal",
          ["wV"] = "*version.000000002.000000008.*zfinal",
        },
        ["opencoarrays/2.8.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "ABI to leverage the parallel programming features of the Fortran 2018 DIS ",
          ["Name"] = "opencoarrays built with gnu8 compiler and mpich MPI ",
          ["Version"] = "2.8.0 ",
          ["canonical"] = "2.8.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/opencoarrays/2.8.0",
          ["help"] = [[
 
This module loads the OPENCOARRAYS library built with the gnu8 compiler
toolchain and the mpich MPI stack.
 

Version 2.8.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/opencoarrays/2.8.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000002.000000008.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/opencoarrays/2.8.0/bin"] = 1,
          },
          ["wV"] = "000000002.000000008.*zfinal",
          whatis = {
            "Name: opencoarrays built with gnu8 compiler and mpich MPI ", "Version: 2.8.0 "
            , "Category: runtime library "
            , "Description: ABI to leverage the parallel programming features of the Fortran 2018 DIS ", "http://www.opencoarrays.org ",
          },
        },
      },
    },
    petsc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["petsc/.version.3.12.0"]  = {
          ["Version"] = ".version.3.12.0",
          ["canonical"] = ".version.3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/petsc/.version.3.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000003.000000012.*zfinal",
          ["wV"] = "*version.000000003.000000012.*zfinal",
        },
        ["petsc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Portable Extensible Toolkit for Scientific Computation ",
          ["Name"] = "petsc built with gnu8 compiler and mpich MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/petsc/3.12.0",
          ["help"] = [[
 
This module loads the PETSc library built with the gnu8 compiler
toolchain and the mpich MPI stack.
 

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/petsc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000003.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/petsc/3.12.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: petsc built with gnu8 compiler and mpich MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: Portable Extensible Toolkit for Scientific Computation ", "http://www.mcs.anl.gov/petsc/ ",
          },
        },
      },
    },
    phdf5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["phdf5/.version.1.10.5"]  = {
          ["Version"] = ".version.1.10.5",
          ["canonical"] = ".version.1.10.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/phdf5/.version.1.10.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000001.000000010.000000005.*zfinal",
          ["wV"] = "*version.000000001.000000010.000000005.*zfinal",
        },
        ["phdf5/1.10.5"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library and file format for storing scientific data ",
          ["Name"] = "hdf5 built with gnu8 compiler and mpich MPI ",
          ["Version"] = "1.10.5 ",
          ["canonical"] = "1.10.5",
          ["family"] = "hdf5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/phdf5/1.10.5",
          ["help"] = [[
 
This module loads the parallel hdf5 library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 1.10.5


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/hdf5/1.10.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000001.000000010.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/hdf5/1.10.5/bin"] = 1,
          },
          ["wV"] = "000000001.000000010.000000005.*zfinal",
          whatis = {
            "Name: hdf5 built with gnu8 compiler and mpich MPI ", "Version: 1.10.5 "
            , "Category: runtime library "
            , "Description: A general purpose library and file format for storing scientific data ", "http://www.hdfgroup.org/HDF5 ",
          },
        },
      },
    },
    pnetcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["pnetcdf/.version.1.12.0"]  = {
          ["Version"] = ".version.1.12.0",
          ["canonical"] = ".version.1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/pnetcdf/.version.1.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000001.000000012.*zfinal",
          ["wV"] = "*version.000000001.000000012.*zfinal",
        },
        ["pnetcdf/1.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A Parallel NetCDF library (PnetCDF) ",
          ["Name"] = "pnetcdf built with gnu8 compiler and mpich MPI ",
          ["Version"] = "1.12.0 ",
          ["canonical"] = "1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/pnetcdf/1.12.0",
          ["help"] = [[
 
This module loads the pnetcdf library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 1.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/pnetcdf/1.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000001.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/pnetcdf/1.12.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000012.*zfinal",
          whatis = {
            "Name: pnetcdf built with gnu8 compiler and mpich MPI ", "Version: 1.12.0 "
            , "Category: runtime library ", "Description: A Parallel NetCDF library (PnetCDF) ", "URL http://cucis.ece.northwestern.edu/projects/PnetCDF ",
          },
        },
      },
    },
    ptscotch = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ptscotch/6.0.6"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Graph, mesh and hypergraph partitioning library using MPI ",
          ["Name"] = "ptscotch built with gnu8 compiler and mpich MPI ",
          ["Version"] = "6.0.6 ",
          ["canonical"] = "6.0.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/ptscotch/6.0.6",
          ["help"] = [[
 
This module loads the Scotch library built with the gnu8 compiler
toolchain and the mpich MPI stack.
 

Version 6.0.6


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/ptscotch/6.0.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000006.000000000.000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/ptscotch/6.0.6/bin"] = 1,
          },
          ["wV"] = "000000006.000000000.000000006.*zfinal",
          whatis = {
            "Name: ptscotch built with gnu8 compiler and mpich MPI ", "Version: 6.0.6 "
            , "Category: runtime library "
            , "Description: Graph, mesh and hypergraph partitioning library using MPI ", "http://www.labri.fr/perso/pelegrin/scotch/ ",
          },
        },
      },
    },
    ["py2-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-mpi4py/.version.3.0.2"]  = {
          ["Version"] = ".version.3.0.2",
          ["canonical"] = ".version.3.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/py2-mpi4py/.version.3.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000003.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000002.*zfinal",
        },
        ["py2-mpi4py/3.0.2"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python-mpi4py built with gnu8 compiler and mpich ",
          ["Version"] = "3.0.2 ",
          ["canonical"] = "3.0.2",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/py2-mpi4py/3.0.2",
          ["help"] = [[
 
This module loads the python-mpi4py library built with the gnu8 compiler
toolchain and the mpich MPI library.

Version 3.0.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000003.000000000.000000002.*zfinal",
          ["wV"] = "000000003.000000000.000000002.*zfinal",
          whatis = {
            "Name: python-mpi4py built with gnu8 compiler and mpich ", "Version: 3.0.2 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    ["py2-scipy"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-scipy/.version.1.2.1"]  = {
          ["Version"] = ".version.1.2.1",
          ["canonical"] = ".version.1.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/py2-scipy/.version.1.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000001.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000002.000000001.*zfinal",
        },
        ["py2-scipy/1.2.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Scientific Tools for Python ",
          ["Name"] = "%{python3_prefix}-scipy built with gnu8 compiler and mpich ",
          ["Version"] = "1.2.1 ",
          ["canonical"] = "1.2.1",
          ["family"] = "scipy",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/py2-scipy/1.2.1",
          ["help"] = [[
 
This module loads the %{python3_prefix}-scipy library built with the gnu8 compiler
toolchain and the mpich MPI library.

Version 1.2.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000001.000000002.000000001.*zfinal",
          ["wV"] = "000000001.000000002.000000001.*zfinal",
          whatis = {
            "Name: %{python3_prefix}-scipy built with gnu8 compiler and mpich "
            , "Version: 1.2.1 ", "Category: python module "
            , "Description: Scientific Tools for Python ", "URL http://www.scipy.org ",
          },
        },
      },
    },
    ["py3-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-mpi4py/.version.3.0.1"]  = {
          ["Version"] = ".version.3.0.1",
          ["canonical"] = ".version.3.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/py3-mpi4py/.version.3.0.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000003.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000001.*zfinal",
        },
        ["py3-mpi4py/3.0.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python34-mpi4py built with gnu8 compiler and mpich ",
          ["Version"] = "3.0.1 ",
          ["canonical"] = "3.0.1",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/py3-mpi4py/3.0.1",
          ["help"] = [[
 
This module loads the python34-mpi4py library built with the gnu8 compiler
toolchain and the mpich MPI library.

Version 3.0.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000003.000000000.000000001.*zfinal",
          ["wV"] = "000000003.000000000.000000001.*zfinal",
          whatis = {
            "Name: python34-mpi4py built with gnu8 compiler and mpich ", "Version: 3.0.1 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    ["py3-scipy"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-scipy/.version.1.2.1"]  = {
          ["Version"] = ".version.1.2.1",
          ["canonical"] = ".version.1.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/py3-scipy/.version.1.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000001.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000002.000000001.*zfinal",
        },
        ["py3-scipy/1.2.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Scientific Tools for Python ",
          ["Name"] = "%{python3_prefix}-scipy built with gnu8 compiler and mpich ",
          ["Version"] = "1.2.1 ",
          ["canonical"] = "1.2.1",
          ["family"] = "scipy",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/py3-scipy/1.2.1",
          ["help"] = [[
 
This module loads the %{python3_prefix}-scipy library built with the gnu8 compiler
toolchain and the mpich MPI library.

Version 1.2.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000001.000000002.000000001.*zfinal",
          ["wV"] = "000000001.000000002.000000001.*zfinal",
          whatis = {
            "Name: %{python3_prefix}-scipy built with gnu8 compiler and mpich "
            , "Version: 1.2.1 ", "Category: python module "
            , "Description: Scientific Tools for Python ", "URL http://www.scipy.org ",
          },
        },
      },
    },
    scalapack = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalapack/.version.2.0.2"]  = {
          ["Version"] = ".version.2.0.2",
          ["canonical"] = ".version.2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/scalapack/.version.2.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000002.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000002.000000000.000000002.*zfinal",
        },
        ["scalapack/2.0.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A subset of LAPACK routines redesigned for heterogenous computing ",
          ["Name"] = "scalapack built with gnu8 compiler and mpich MPI ",
          ["Version"] = "2.0.2 ",
          ["canonical"] = "2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/scalapack/2.0.2",
          ["help"] = [[
 
This module loads the ScaLAPACK library built with the gnu8 compiler
toolchain and the mpich MPI stack.
 

Version 2.0.2


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/scalapack/2.0.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000002.000000000.000000002.*zfinal",
          ["wV"] = "000000002.000000000.000000002.*zfinal",
          whatis = {
            "Name: scalapack built with gnu8 compiler and mpich MPI ", "Version: 2.0.2 "
            , "Category: runtime library "
            , "Description: A subset of LAPACK routines redesigned for heterogenous computing ", "http://www.netlib.org/lapack-dev/ ",
          },
        },
      },
    },
    scalasca = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalasca/.version.2.5"]  = {
          ["Version"] = ".version.2.5",
          ["canonical"] = ".version.2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/scalasca/.version.2.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000002.000000005.*zfinal",
          ["wV"] = "*version.000000002.000000005.*zfinal",
        },
        ["scalasca/2.5"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Toolset for performance analysis of large-scale parallel applications ",
          ["Name"] = "scalasca built with gnu8 compiler and mpich MPI ",
          ["Version"] = "2.5 ",
          ["canonical"] = "2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/scalasca/2.5",
          ["help"] = [[
 
This module loads the scalasca library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 2.5


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000002.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/scalasca/2.5/bin"] = 1,
          },
          ["wV"] = "000000002.000000005.*zfinal",
          whatis = {
            "Name: scalasca built with gnu8 compiler and mpich MPI ", "Version: 2.5 "
            , "Category: performance tool "
            , "Description: Toolset for performance analysis of large-scale parallel applications ", "URL http://www.scalasca.org ",
          },
        },
      },
    },
    scorep = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scorep/.version.6.0"]  = {
          ["Version"] = ".version.6.0",
          ["canonical"] = ".version.6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/scorep/.version.6.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000006.*zfinal",
          ["wV"] = "*version.000000006.*zfinal",
        },
        ["scorep/6.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Scalable Performance Measurement Infrastructure for Parallel Codes ",
          ["Name"] = "scorep built with gnu8 compiler and mpich MPI ",
          ["Version"] = "6.0 ",
          ["canonical"] = "6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/scorep/6.0",
          ["help"] = [[
 
This module loads the scorep library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 6.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/scorep/6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/scorep/6.0/bin"] = 1,
          },
          ["wV"] = "000000006.*zfinal",
          whatis = {
            "Name: scorep built with gnu8 compiler and mpich MPI ", "Version: 6.0 "
            , "Category: performance tool "
            , "Description: Scalable Performance Measurement Infrastructure for Parallel Codes ", "URL http://www.vi-hps.org/projects/score-p/ ",
          },
        },
      },
    },
    sionlib = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["sionlib/.version.1.7.4"]  = {
          ["Version"] = ".version.1.7.4",
          ["canonical"] = ".version.1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/sionlib/.version.1.7.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000001.000000007.000000004.*zfinal",
          ["wV"] = "*version.000000001.000000007.000000004.*zfinal",
        },
        ["sionlib/1.7.4"]  = {
          ["Category"] = "IO Library ",
          ["Description"] = "Scalable I/O Library for Parallel Access to Task-Local Files ",
          ["Name"] = "sionlib built with gnu8 compiler and mpich MPI ",
          ["Version"] = "1.7.4 ",
          ["canonical"] = "1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/sionlib/1.7.4",
          ["help"] = [[
 
This module loads the sionlib library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 1.7.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/sionlib/1.7.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000001.000000007.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/sionlib/1.7.4/bin"] = 1,
          },
          ["wV"] = "000000001.000000007.000000004.*zfinal",
          whatis = {
            "Name: sionlib built with gnu8 compiler and mpich MPI ", "Version: 1.7.4 "
            , "Category: IO Library "
            , "Description: Scalable I/O Library for Parallel Access to Task-Local Files ", "URL http://www.fz-juelich.de/ias/jsc/EN/Expertise/Support/Software/SIONlib/_node.html ",
          },
        },
      },
    },
    slepc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["slepc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A library for solving large scale sparse eigenvalue problems ",
          ["Name"] = "slepc built with gnu8 compiler and mpich MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/slepc/3.12.0",
          ["help"] = [[
 
This module loads the slepc library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/slepc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000003.000000012.*zfinal",
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: slepc built with gnu8 compiler and mpich MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: A library for solving large scale sparse eigenvalue problems ", "URL http://slepc.upv.es ",
          },
        },
      },
    },
    superlu_dist = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["superlu_dist/.version.6.1.1"]  = {
          ["Version"] = ".version.6.1.1",
          ["canonical"] = ".version.6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/superlu_dist/.version.6.1.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000006.000000001.000000001.*zfinal",
          ["wV"] = "*version.000000006.000000001.000000001.*zfinal",
        },
        ["superlu_dist/6.1.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library for the direct solution of linear equations ",
          ["Name"] = "superlu_dist built with gnu8 compiler and mpich MPI ",
          ["Version"] = "6.1.1 ",
          ["canonical"] = "6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/superlu_dist/6.1.1",
          ["help"] = [[
 
This module loads the SuperLU_dist library built with the gnu8 compiler
toolchain and the mpich MPI stack.
 
Note that this build of SuperLU_dist leverages the metis and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 6.1.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/superlu_dist/6.1.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000006.000000001.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/superlu_dist/6.1.1/bin"] = 1,
          },
          ["wV"] = "000000006.000000001.000000001.*zfinal",
          whatis = {
            "Name: superlu_dist built with gnu8 compiler and mpich MPI ", "Version: 6.1.1 "
            , "Category: runtime library "
            , "Description: A general purpose library for the direct solution of linear equations ", "http://crd-legacy.lbl.gov/~xiaoye/SuperLU/ ",
          },
        },
      },
    },
    tau = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tau/.version.2.28"]  = {
          ["Version"] = ".version.2.28",
          ["canonical"] = ".version.2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/tau/.version.2.28",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000002.000000028.*zfinal",
          ["wV"] = "*version.000000002.000000028.*zfinal",
        },
        ["tau/2.28"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Tuning and Analysis Utilities Profiling Package ",
          ["Name"] = "tau built with gnu8 compiler ",
          ["Version"] = "2.28 ",
          ["canonical"] = "2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/tau/2.28",
          ["help"] = [[
 
This module loads the tau library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 2.28


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/tau/2.28/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000002.000000028.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/tau/2.28/bin"] = 1,
          },
          ["wV"] = "000000002.000000028.*zfinal",
          whatis = {
            "Name: tau built with gnu8 compiler ", "Version: 2.28 "
            , "Category: runtime library "
            , "Description: Tuning and Analysis Utilities Profiling Package ", "URL http://www.cs.uoregon.edu/research/tau/home.php ",
          },
        },
      },
    },
    trilinos = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["trilinos/.version.12.14.1"]  = {
          ["Version"] = ".version.12.14.1",
          ["canonical"] = ".version.12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/trilinos/.version.12.14.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "*version.000000012.000000014.000000001.*zfinal",
          ["wV"] = "*version.000000012.000000014.000000001.*zfinal",
        },
        ["trilinos/12.14.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A collection of libraries of numerical algorithms ",
          ["Name"] = "trilinos built with gnu8 compiler and mpich MPI ",
          ["Version"] = "12.14.1 ",
          ["canonical"] = "12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich/trilinos/12.14.1",
          ["help"] = [[
 
This module loads the trilinos library built with the gnu8 compiler
toolchain and the mpich MPI stack.

Version 12.14.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/trilinos/12.14.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mpich",
          ["pV"] = "000000012.000000014.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mpich/trilinos/12.14.1/bin"] = 1,
          },
          ["wV"] = "000000012.000000014.000000001.*zfinal",
          whatis = {
            "Name: trilinos built with gnu8 compiler and mpich MPI ", "Version: 12.14.1 "
            , "Category: runtime library "
            , "Description: A collection of libraries of numerical algorithms ", "URL https://trilinos.org/ ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/gnu8-mvapich2"]  = {
    adios = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["adios/.version.1.13.1"]  = {
          ["Version"] = ".version.1.13.1",
          ["canonical"] = ".version.1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/adios/.version.1.13.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000001.000000013.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000013.000000001.*zfinal",
        },
        ["adios/1.13.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "The Adaptable IO System (ADIOS) ",
          ["Name"] = "ADIOS built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "1.13.1 ",
          ["canonical"] = "1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/adios/1.13.1",
          ["help"] = [[
 
This module loads the ADIOS library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 1.13.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/adios/1.13.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000001.000000013.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/adios/1.13.1/bin"] = 1,
          },
          ["wV"] = "000000001.000000013.000000001.*zfinal",
          whatis = {
            "Name: ADIOS built with gnu8 compiler and mvapich2 MPI ", "Version: 1.13.1 "
            , "Category: runtime library ", "Description: The Adaptable IO System (ADIOS) ", "http://www.olcf.ornl.gov/center-projects/adios/ ",
          },
        },
      },
    },
    boost = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["boost/.version.1.71.0"]  = {
          ["Version"] = ".version.1.71.0",
          ["canonical"] = ".version.1.71.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/boost/.version.1.71.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000001.000000071.*zfinal",
          ["wV"] = "*version.000000001.000000071.*zfinal",
        },
        ["boost/1.71.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Boost free peer-reviewed portable C++ source libraries ",
          ["Name"] = "BOOST built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "1.71.0 ",
          ["canonical"] = "1.71.0",
          ["family"] = "boost",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/boost/1.71.0",
          ["help"] = [[
 
This module loads the BOOST library built with the gnu8 compiler toolchain
and the mvapich2 MPI stack.

Version 1.71.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/boost/1.71.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000001.000000071.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/boost/1.71.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000071.*zfinal",
          whatis = {
            "Name: BOOST built with gnu8 compiler and mvapich2 MPI ", "Version: 1.71.0 "
            , "Category: runtime library "
            , "Description: Boost free peer-reviewed portable C++ source libraries ", "http://www.boost.org ",
          },
        },
      },
    },
    dimemas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["dimemas/.version.5.4.1"]  = {
          ["Version"] = ".version.5.4.1",
          ["canonical"] = ".version.5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/dimemas/.version.5.4.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000005.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000004.000000001.*zfinal",
        },
        ["dimemas/5.4.1"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Dimemas tool ",
          ["Name"] = "dimemas built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "5.4.1 ",
          ["canonical"] = "5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/dimemas/5.4.1",
          ["help"] = [[
 
This module loads the dimemas library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 5.4.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000005.000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/dimemas/5.4.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000004.000000001.*zfinal",
          whatis = {
            "Name: dimemas built with gnu8 compiler and mvapich2 MPI ", "Version: 5.4.1 "
            , "Category: performance tool ", "Description: Dimemas tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    extrae = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["extrae/.version.3.7.0"]  = {
          ["Version"] = ".version.3.7.0",
          ["canonical"] = ".version.3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/extrae/.version.3.7.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000003.000000007.*zfinal",
          ["wV"] = "*version.000000003.000000007.*zfinal",
        },
        ["extrae/3.7.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Extrae tool ",
          ["Name"] = "extrae built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "3.7.0 ",
          ["canonical"] = "3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/extrae/3.7.0",
          ["help"] = [[
 
This module loads the extrae library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 3.7.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/extrae/3.7.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/extrae/3.7.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
          whatis = {
            "Name: extrae built with gnu8 compiler and mvapich2 MPI ", "Version: 3.7.0 "
            , "Category: performance tool ", "Description: Extrae tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    imb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["imb/.version.2018.1"]  = {
          ["Version"] = ".version.2018.1",
          ["canonical"] = ".version.2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/imb/.version.2018.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000002018.000000001.*zfinal",
          ["wV"] = "*version.000002018.000000001.*zfinal",
        },
        ["imb/2018.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Intel MPI Benchmarks (IMB) ",
          ["Name"] = "imb built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "2018.1 ",
          ["canonical"] = "2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/imb/2018.1",
          ["help"] = [[
 
This module loads the imb library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 2018.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000002018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/imb/2018.1/bin"] = 1,
          },
          ["wV"] = "000002018.000000001.*zfinal",
          whatis = {
            "Name: imb built with gnu8 compiler and mvapich2 MPI ", "Version: 2018.1 "
            , "Category: runtime library ", "Description: Intel MPI Benchmarks (IMB) ", "URL https://software.intel.com/en-us/articles/intel-mpi-benchmarks ",
          },
        },
      },
    },
    mpiP = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mpiP/.version.3.4.1"]  = {
          ["Version"] = ".version.3.4.1",
          ["canonical"] = ".version.3.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/mpiP/.version.3.4.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000003.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000004.000000001.*zfinal",
        },
        ["mpiP/3.4.1"]  = {
          ["Category"] = "Profiling library ",
          ["Description"] = "mpiP: a lightweight profiling library for MPI applications. ",
          ["Name"] = "mpiP built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "3.4.1 ",
          ["canonical"] = "3.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/mpiP/3.4.1",
          ["help"] = [[
 
This module loads the mpiP library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 3.4.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/mpiP/3.4.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000003.000000004.000000001.*zfinal",
          ["wV"] = "000000003.000000004.000000001.*zfinal",
          whatis = {
            "Name: mpiP built with gnu8 compiler and mvapich2 MPI ", "Version: 3.4.1 "
            , "Category: Profiling library "
            , "Description: mpiP: a lightweight profiling library for MPI applications. ", "URL http://mpip.sourceforge.net/ ",
          },
        },
      },
    },
    netcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf/.version.4.7.1"]  = {
          ["Version"] = ".version.4.7.1",
          ["canonical"] = ".version.4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/netcdf/.version.4.7.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000004.000000007.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000007.000000001.*zfinal",
        },
        ["netcdf/4.7.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF built with gnu8 toolchain ",
          ["Version"] = "4.7.1 ",
          ["canonical"] = "4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/netcdf/4.7.1",
          ["help"] = [[
 
This module loads the NetCDF C API built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5. Consequently, the phdf5 package is loaded automatically with this module.
A typical compilation step for C applications requiring NetCDF is as follows:
 
$CC -I$NETCDF_INC app.c -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.7.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/netcdf/4.7.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000004.000000007.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/netcdf/4.7.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000007.000000001.*zfinal",
          whatis = {
            "Name: NETCDF built with gnu8 toolchain ", "Version: 4.7.1 "
            , "Category: runtime library "
            , "Description: C Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-cxx"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-cxx/.version.4.3.1"]  = {
          ["Version"] = ".version.4.3.1",
          ["canonical"] = ".version.4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/netcdf-cxx/.version.4.3.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000004.000000003.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000003.000000001.*zfinal",
        },
        ["netcdf-cxx/4.3.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C++ Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_CXX built with gnu8 toolchain ",
          ["Version"] = "4.3.1 ",
          ["canonical"] = "4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/netcdf-cxx/4.3.1",
          ["help"] = [[
 
This module loads the NetCDF C++ API built with the gnu8 compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for C++ applications requiring NetCDF is as follows:
 
$CXX -I$NETCDF_CXX_INC app.cpp -L$NETCDF_CXX_LIB -lnetcdf_c++4 -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.3.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/netcdf-cxx/4.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000004.000000003.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/netcdf-cxx/4.3.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000003.000000001.*zfinal",
          whatis = {
            "Name: NETCDF_CXX built with gnu8 toolchain ", "Version: 4.3.1 "
            , "Category: runtime library "
            , "Description: C++ Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-fortran"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-fortran/.version.4.5.2"]  = {
          ["Version"] = ".version.4.5.2",
          ["canonical"] = ".version.4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/netcdf-fortran/.version.4.5.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000004.000000005.000000002.*zfinal",
          ["wV"] = "*version.000000004.000000005.000000002.*zfinal",
        },
        ["netcdf-fortran/4.5.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Fortran Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_FORTRAN built with gnu8 toolchain ",
          ["Version"] = "4.5.2 ",
          ["canonical"] = "4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/netcdf-fortran/4.5.2",
          ["help"] = [[
 
This module loads the NetCDF Fortran API built with the gnu8 compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for Fortran applications requiring NetCDF is as follows:
 

]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/netcdf-fortran/4.5.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000004.000000005.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/netcdf-fortran/4.5.2/bin"] = 1,
          },
          ["wV"] = "000000004.000000005.000000002.*zfinal",
          whatis = {
            "Name: NETCDF_FORTRAN built with gnu8 toolchain ", "Version: 4.5.2 "
            , "Category: runtime library "
            , "Description: Fortran Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    omb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["omb/.version.5.6.2"]  = {
          ["Version"] = ".version.5.6.2",
          ["canonical"] = ".version.5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/omb/.version.5.6.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000005.000000006.000000002.*zfinal",
          ["wV"] = "*version.000000005.000000006.000000002.*zfinal",
        },
        ["omb/5.6.2"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "OSU Micro-benchmarks ",
          ["Name"] = "OSU Micro-benchmarks built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "5.6.2 ",
          ["canonical"] = "5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/omb/5.6.2",
          ["help"] = [[
 
This module loads the OSU Micro-benchmarks built with the gnu8 toolchain
and the mvapich2 MPI stack.

Version 5.6.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000005.000000006.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/omb/5.6.2/bin/osu-micro-benchmarks/mpi/collective"] = 1,
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/omb/5.6.2/bin/osu-micro-benchmarks/mpi/one-sided"] = 1,
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/omb/5.6.2/bin/osu-micro-benchmarks/mpi/pt2pt"] = 1,
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/omb/5.6.2/bin/osu-micro-benchmarks/mpi/startup"] = 1,
          },
          ["wV"] = "000000005.000000006.000000002.*zfinal",
          whatis = {
            "Name: OSU Micro-benchmarks built with gnu8 compiler and mvapich2 MPI "
            , "Version: 5.6.2 ", "Category: performance tool "
            , "Description: OSU Micro-benchmarks ", "http://mvapich.cse.ohio-state.edu/benchmarks/ ",
          },
        },
      },
    },
    phdf5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["phdf5/.version.1.10.5"]  = {
          ["Version"] = ".version.1.10.5",
          ["canonical"] = ".version.1.10.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/phdf5/.version.1.10.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000001.000000010.000000005.*zfinal",
          ["wV"] = "*version.000000001.000000010.000000005.*zfinal",
        },
        ["phdf5/1.10.5"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library and file format for storing scientific data ",
          ["Name"] = "hdf5 built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "1.10.5 ",
          ["canonical"] = "1.10.5",
          ["family"] = "hdf5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/phdf5/1.10.5",
          ["help"] = [[
 
This module loads the parallel hdf5 library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 1.10.5


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/hdf5/1.10.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000001.000000010.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/hdf5/1.10.5/bin"] = 1,
          },
          ["wV"] = "000000001.000000010.000000005.*zfinal",
          whatis = {
            "Name: hdf5 built with gnu8 compiler and mvapich2 MPI ", "Version: 1.10.5 "
            , "Category: runtime library "
            , "Description: A general purpose library and file format for storing scientific data ", "http://www.hdfgroup.org/HDF5 ",
          },
        },
      },
    },
    pnetcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["pnetcdf/.version.1.12.0"]  = {
          ["Version"] = ".version.1.12.0",
          ["canonical"] = ".version.1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/pnetcdf/.version.1.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000001.000000012.*zfinal",
          ["wV"] = "*version.000000001.000000012.*zfinal",
        },
        ["pnetcdf/1.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A Parallel NetCDF library (PnetCDF) ",
          ["Name"] = "pnetcdf built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "1.12.0 ",
          ["canonical"] = "1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/pnetcdf/1.12.0",
          ["help"] = [[
 
This module loads the pnetcdf library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 1.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/pnetcdf/1.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000001.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/pnetcdf/1.12.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000012.*zfinal",
          whatis = {
            "Name: pnetcdf built with gnu8 compiler and mvapich2 MPI ", "Version: 1.12.0 "
            , "Category: runtime library ", "Description: A Parallel NetCDF library (PnetCDF) ", "URL http://cucis.ece.northwestern.edu/projects/PnetCDF ",
          },
        },
      },
    },
    ["py2-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-mpi4py/.version.3.0.2"]  = {
          ["Version"] = ".version.3.0.2",
          ["canonical"] = ".version.3.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/py2-mpi4py/.version.3.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000003.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000002.*zfinal",
        },
        ["py2-mpi4py/3.0.2"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python-mpi4py built with gnu8 compiler and mvapich2 ",
          ["Version"] = "3.0.2 ",
          ["canonical"] = "3.0.2",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/py2-mpi4py/3.0.2",
          ["help"] = [[
 
This module loads the python-mpi4py library built with the gnu8 compiler
toolchain and the mvapich2 MPI library.

Version 3.0.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000003.000000000.000000002.*zfinal",
          ["wV"] = "000000003.000000000.000000002.*zfinal",
          whatis = {
            "Name: python-mpi4py built with gnu8 compiler and mvapich2 ", "Version: 3.0.2 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    ["py2-scipy"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-scipy/.version.1.2.1"]  = {
          ["Version"] = ".version.1.2.1",
          ["canonical"] = ".version.1.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/py2-scipy/.version.1.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000001.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000002.000000001.*zfinal",
        },
        ["py2-scipy/1.2.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Scientific Tools for Python ",
          ["Name"] = "%{python3_prefix}-scipy built with gnu8 compiler and mvapich2 ",
          ["Version"] = "1.2.1 ",
          ["canonical"] = "1.2.1",
          ["family"] = "scipy",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/py2-scipy/1.2.1",
          ["help"] = [[
 
This module loads the %{python3_prefix}-scipy library built with the gnu8 compiler
toolchain and the mvapich2 MPI library.

Version 1.2.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000001.000000002.000000001.*zfinal",
          ["wV"] = "000000001.000000002.000000001.*zfinal",
          whatis = {
            "Name: %{python3_prefix}-scipy built with gnu8 compiler and mvapich2 "
            , "Version: 1.2.1 ", "Category: python module "
            , "Description: Scientific Tools for Python ", "URL http://www.scipy.org ",
          },
        },
      },
    },
    ["py3-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-mpi4py/.version.3.0.1"]  = {
          ["Version"] = ".version.3.0.1",
          ["canonical"] = ".version.3.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/py3-mpi4py/.version.3.0.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000003.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000001.*zfinal",
        },
        ["py3-mpi4py/3.0.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python34-mpi4py built with gnu8 compiler and mvapich2 ",
          ["Version"] = "3.0.1 ",
          ["canonical"] = "3.0.1",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/py3-mpi4py/3.0.1",
          ["help"] = [[
 
This module loads the python34-mpi4py library built with the gnu8 compiler
toolchain and the mvapich2 MPI library.

Version 3.0.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000003.000000000.000000001.*zfinal",
          ["wV"] = "000000003.000000000.000000001.*zfinal",
          whatis = {
            "Name: python34-mpi4py built with gnu8 compiler and mvapich2 ", "Version: 3.0.1 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    ["py3-scipy"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-scipy/.version.1.2.1"]  = {
          ["Version"] = ".version.1.2.1",
          ["canonical"] = ".version.1.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/py3-scipy/.version.1.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000001.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000002.000000001.*zfinal",
        },
        ["py3-scipy/1.2.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Scientific Tools for Python ",
          ["Name"] = "%{python3_prefix}-scipy built with gnu8 compiler and mvapich2 ",
          ["Version"] = "1.2.1 ",
          ["canonical"] = "1.2.1",
          ["family"] = "scipy",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/py3-scipy/1.2.1",
          ["help"] = [[
 
This module loads the %{python3_prefix}-scipy library built with the gnu8 compiler
toolchain and the mvapich2 MPI library.

Version 1.2.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000001.000000002.000000001.*zfinal",
          ["wV"] = "000000001.000000002.000000001.*zfinal",
          whatis = {
            "Name: %{python3_prefix}-scipy built with gnu8 compiler and mvapich2 "
            , "Version: 1.2.1 ", "Category: python module "
            , "Description: Scientific Tools for Python ", "URL http://www.scipy.org ",
          },
        },
      },
    },
    scalasca = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalasca/.version.2.5"]  = {
          ["Version"] = ".version.2.5",
          ["canonical"] = ".version.2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/scalasca/.version.2.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000002.000000005.*zfinal",
          ["wV"] = "*version.000000002.000000005.*zfinal",
        },
        ["scalasca/2.5"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Toolset for performance analysis of large-scale parallel applications ",
          ["Name"] = "scalasca built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "2.5 ",
          ["canonical"] = "2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/scalasca/2.5",
          ["help"] = [[
 
This module loads the scalasca library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 2.5


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000002.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/scalasca/2.5/bin"] = 1,
          },
          ["wV"] = "000000002.000000005.*zfinal",
          whatis = {
            "Name: scalasca built with gnu8 compiler and mvapich2 MPI ", "Version: 2.5 "
            , "Category: performance tool "
            , "Description: Toolset for performance analysis of large-scale parallel applications ", "URL http://www.scalasca.org ",
          },
        },
      },
    },
    scorep = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scorep/.version.6.0"]  = {
          ["Version"] = ".version.6.0",
          ["canonical"] = ".version.6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/scorep/.version.6.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000006.*zfinal",
          ["wV"] = "*version.000000006.*zfinal",
        },
        ["scorep/6.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Scalable Performance Measurement Infrastructure for Parallel Codes ",
          ["Name"] = "scorep built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "6.0 ",
          ["canonical"] = "6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/scorep/6.0",
          ["help"] = [[
 
This module loads the scorep library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 6.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/scorep/6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/scorep/6.0/bin"] = 1,
          },
          ["wV"] = "000000006.*zfinal",
          whatis = {
            "Name: scorep built with gnu8 compiler and mvapich2 MPI ", "Version: 6.0 "
            , "Category: performance tool "
            , "Description: Scalable Performance Measurement Infrastructure for Parallel Codes ", "URL http://www.vi-hps.org/projects/score-p/ ",
          },
        },
      },
    },
    sionlib = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["sionlib/.version.1.7.4"]  = {
          ["Version"] = ".version.1.7.4",
          ["canonical"] = ".version.1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/sionlib/.version.1.7.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000001.000000007.000000004.*zfinal",
          ["wV"] = "*version.000000001.000000007.000000004.*zfinal",
        },
        ["sionlib/1.7.4"]  = {
          ["Category"] = "IO Library ",
          ["Description"] = "Scalable I/O Library for Parallel Access to Task-Local Files ",
          ["Name"] = "sionlib built with gnu8 compiler and mvapich2 MPI ",
          ["Version"] = "1.7.4 ",
          ["canonical"] = "1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/sionlib/1.7.4",
          ["help"] = [[
 
This module loads the sionlib library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 1.7.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/sionlib/1.7.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000001.000000007.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/sionlib/1.7.4/bin"] = 1,
          },
          ["wV"] = "000000001.000000007.000000004.*zfinal",
          whatis = {
            "Name: sionlib built with gnu8 compiler and mvapich2 MPI ", "Version: 1.7.4 "
            , "Category: IO Library "
            , "Description: Scalable I/O Library for Parallel Access to Task-Local Files ", "URL http://www.fz-juelich.de/ias/jsc/EN/Expertise/Support/Software/SIONlib/_node.html ",
          },
        },
      },
    },
    tau = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tau/.version.2.28"]  = {
          ["Version"] = ".version.2.28",
          ["canonical"] = ".version.2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/tau/.version.2.28",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "*version.000000002.000000028.*zfinal",
          ["wV"] = "*version.000000002.000000028.*zfinal",
        },
        ["tau/2.28"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Tuning and Analysis Utilities Profiling Package ",
          ["Name"] = "tau built with gnu8 compiler ",
          ["Version"] = "2.28 ",
          ["canonical"] = "2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2/tau/2.28",
          ["help"] = [[
 
This module loads the tau library built with the gnu8 compiler
toolchain and the mvapich2 MPI stack.

Version 2.28


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/tau/2.28/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/gnu8-mvapich2",
          ["pV"] = "000000002.000000028.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/gnu8/mvapich2/tau/2.28/bin"] = 1,
          },
          ["wV"] = "000000002.000000028.*zfinal",
          whatis = {
            "Name: tau built with gnu8 compiler ", "Version: 2.28 "
            , "Category: runtime library "
            , "Description: Tuning and Analysis Utilities Profiling Package ", "URL http://www.cs.uoregon.edu/research/tau/home.php ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/intel"]  = {
    hdf5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hdf5/.version.1.10.5"]  = {
          ["Version"] = ".version.1.10.5",
          ["canonical"] = ".version.1.10.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/hdf5/.version.1.10.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000001.000000010.000000005.*zfinal",
          ["wV"] = "*version.000000001.000000010.000000005.*zfinal",
        },
        ["hdf5/1.10.5"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library and file format for storing scientific data ",
          ["Name"] = "HDF5 built with intel toolchain ",
          ["Version"] = "1.10.5 ",
          ["canonical"] = "1.10.5",
          ["family"] = "hdf5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/hdf5/1.10.5",
          ["help"] = [[
 
This module loads the HDF5 library built with the intel compiler toolchain.

Version 1.10.5


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/hdf5/1.10.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000001.000000010.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/hdf5/1.10.5/bin"] = 1,
          },
          ["wV"] = "000000001.000000010.000000005.*zfinal",
          whatis = {
            "Name: HDF5 built with intel toolchain ", "Version: 1.10.5 "
            , "Category: runtime library "
            , "Description: A general purpose library and file format for storing scientific data ", "http://www.hdfgroup.org/HDF5 ",
          },
        },
      },
    },
    impi = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["impi/2018.4.274"]  = {
          ["Category"] = "library, runtime support ",
          ["Description"] = "Intel MPI Library (C/C++/Fortran for x86_64) ",
          ["Name"] = "Intel MPI ",
          ["URL"] = "http://software.intel.com/en-us/articles/intel-mpi-library/ ",
          ["Version"] = "2018.4.274 ",
          ["canonical"] = "2018.4.274",
          ["family"] = "MPI",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/impi/2018.4.274",
          ["help"] = [[
 
This module loads the Intel MPI environment
 
mpiifort     (Fortran source)
mpiicc       (C   source)
mpiicpc      (C++ source)
 
Version 2018.4.274
 

]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000002018.000000004.000000274.*zfinal",
          ["wV"] = "000002018.000000004.000000274.*zfinal",
          whatis = {
            "Name: Intel MPI ", "Version: 2018.4.274 ", "Category: library, runtime support "
            , "Description: Intel MPI Library (C/C++/Fortran for x86_64) ", "URL: http://software.intel.com/en-us/articles/intel-mpi-library/ ",
          },
        },
      },
    },
    likwid = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["likwid/.version.4.3.4"]  = {
          ["Version"] = ".version.4.3.4",
          ["canonical"] = ".version.4.3.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/likwid/.version.4.3.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000004.000000003.000000004.*zfinal",
          ["wV"] = "*version.000000004.000000003.000000004.*zfinal",
        },
        ["likwid/4.3.4"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Toolsuite of command line applications for performance oriented programmers ",
          ["Name"] = "likwid built with intel compiler ",
          ["Version"] = "4.3.4 ",
          ["canonical"] = "4.3.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/likwid/4.3.4",
          ["help"] = [[
 
This module loads the likwid library built with the intel compiler
toolchain.

Version 4.3.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/likwid/4.3.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000004.000000003.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/likwid/4.3.4/bin"] = 1,
          },
          ["wV"] = "000000004.000000003.000000004.*zfinal",
          whatis = {
            "Name: likwid built with intel compiler ", "Version: 4.3.4 "
            , "Category: performance tool "
            , "Description: Toolsuite of command line applications for performance oriented programmers ", "URL https://github.com/RRZE-HPC/likwid ",
          },
        },
      },
    },
    metis = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["metis/.version.5.1.0"]  = {
          ["Version"] = ".version.5.1.0",
          ["canonical"] = ".version.5.1.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/metis/.version.5.1.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000005.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000001.*zfinal",
        },
        ["metis/5.1.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Metis development files ",
          ["Name"] = "METIS built with intel toolchain ",
          ["Version"] = "5.1.0 ",
          ["canonical"] = "5.1.0",
          ["family"] = "metis",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/metis/5.1.0",
          ["help"] = [[
 
This module loads the METIS library built with the intel compiler toolchain.

Version 5.1.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/metis/5.1.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000005.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/metis/5.1.0/bin"] = 1,
          },
          ["wV"] = "000000005.000000001.*zfinal",
          whatis = {
            "Name: METIS built with intel toolchain ", "Version: 5.1.0 "
            , "Category: runtime library ", "Description: Metis development files ", "http://glaros.dtc.umn.edu/gkhome/metis/metis/overview ",
          },
        },
      },
    },
    mpich = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mpich/.version.3.3.1"]  = {
          ["Version"] = ".version.3.3.1",
          ["canonical"] = ".version.3.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/mpich/.version.3.3.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000003.000000003.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000003.000000001.*zfinal",
        },
        ["mpich/3.3.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "MPICH MPI implementation ",
          ["Name"] = "mpich built with intel toolchain ",
          ["URL"] = "http://www.mpich.org ",
          ["Version"] = "3.3.1 ",
          ["canonical"] = "3.3.1",
          ["family"] = "MPI",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/mpich/3.3.1",
          ["help"] = [[
 
This module loads the mpich library built with the intel toolchain.

Version 3.3.1


]],
          lpathA = {
            ["/opt/ohpc/pub/mpi/mpich-intel-ohpc/3.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000003.000000003.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/mpi/mpich-intel-ohpc/3.3.1/bin"] = 1,
          },
          ["wV"] = "000000003.000000003.000000001.*zfinal",
          whatis = {
            "Name: mpich built with intel toolchain ", "Version: 3.3.1 "
            , "Category: runtime library ", "Description: MPICH MPI implementation ", "URL: http://www.mpich.org ",
          },
        },
      },
    },
    mvapich2 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mvapich2/.version.2.3.2"]  = {
          ["Version"] = ".version.2.3.2",
          ["canonical"] = ".version.2.3.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/mvapich2/.version.2.3.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000002.000000003.000000002.*zfinal",
          ["wV"] = "*version.000000002.000000003.000000002.*zfinal",
        },
        ["mvapich2/2.3.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "OSU MVAPICH2 MPI implementation ",
          ["Name"] = "mvapich2 built with intel toolchain ",
          ["URL"] = "http://mvapich.cse.ohio-state.edu ",
          ["Version"] = "2.3.2 ",
          ["canonical"] = "2.3.2",
          ["family"] = "MPI",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/mvapich2/2.3.2",
          ["help"] = [[
 
This module loads the mvapich2 library built with the intel toolchain.

Version 2.3.2


]],
          lpathA = {
            ["/opt/ohpc/pub/mpi/mvapich2-intel/2.3.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000002.000000003.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/mpi/mvapich2-intel/2.3.2/bin"] = 1,
          },
          ["wV"] = "000000002.000000003.000000002.*zfinal",
          whatis = {
            "Name: mvapich2 built with intel toolchain ", "Version: 2.3.2 "
            , "Category: runtime library ", "Description: OSU MVAPICH2 MPI implementation ", "URL: http://mvapich.cse.ohio-state.edu ",
          },
        },
      },
    },
    ocr = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ocr/.version.1.0.1"]  = {
          ["Version"] = ".version.1.0.1",
          ["canonical"] = ".version.1.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/ocr/.version.1.0.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000001.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000000.000000001.*zfinal",
        },
        ["ocr/1.0.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Open Community Runtime (OCR) for shared memory ",
          ["Name"] = "OCR for shared memory built with intel toolchain ",
          ["Version"] = "1.0.1 ",
          ["canonical"] = "1.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/ocr/1.0.1",
          ["help"] = [[
 
This module loads the OCR library built with the intel compiler toolchain for shared memory

Version 1.0.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/ocr/1.0.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000001.000000000.000000001.*zfinal",
          ["wV"] = "000000001.000000000.000000001.*zfinal",
          whatis = {
            "Name: OCR for shared memory built with intel toolchain ", "Version: 1.0.1 "
            , "Category: runtime library "
            , "Description: Open Community Runtime (OCR) for shared memory ", "https://xstack.exascale-tech.com/wiki ",
          },
        },
      },
    },
    openmpi3 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openmpi3/.version.3.1.4"]  = {
          ["Version"] = ".version.3.1.4",
          ["canonical"] = ".version.3.1.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/openmpi3/.version.3.1.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000003.000000001.000000004.*zfinal",
          ["wV"] = "*version.000000003.000000001.000000004.*zfinal",
        },
        ["openmpi3/3.1.4"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A powerful implementation of MPI ",
          ["Name"] = "openmpi3 built with intel toolchain ",
          ["URL"] = "http://www.open-mpi.org ",
          ["Version"] = "3.1.4 ",
          ["canonical"] = "3.1.4",
          ["family"] = "MPI",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/openmpi3/3.1.4",
          ["help"] = [[
 
This module loads the openmpi3 library built with the intel toolchain.

Version 3.1.4


]],
          lpathA = {
            ["/opt/ohpc/pub/mpi/openmpi3-intel/3.1.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000003.000000001.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/mpi/openmpi3-intel/3.1.4/bin"] = 1,
          },
          ["wV"] = "000000003.000000001.000000004.*zfinal",
          whatis = {
            "Name: openmpi3 built with intel toolchain ", "Version: 3.1.4 "
            , "Category: runtime library ", "Description: A powerful implementation of MPI ", "URL: http://www.open-mpi.org ",
          },
        },
      },
    },
    pdtoolkit = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["pdtoolkit/.version.3.25"]  = {
          ["Version"] = ".version.3.25",
          ["canonical"] = ".version.3.25",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/pdtoolkit/.version.3.25",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000003.000000025.*zfinal",
          ["wV"] = "*version.000000003.000000025.*zfinal",
        },
        ["pdtoolkit/3.25"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "PDT is a framework for analyzing source code ",
          ["Name"] = "pdtoolkit built with intel compiler ",
          ["Version"] = "3.25 ",
          ["canonical"] = "3.25",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/pdtoolkit/3.25",
          ["help"] = [[
 
This module loads the pdtoolkit library built with the intel compiler
toolchain.

Version 3.25


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/pdtoolkit/3.25/x86_64/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000003.000000025.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/pdtoolkit/3.25/x86_64/bin"] = 1,
          },
          ["wV"] = "000000003.000000025.*zfinal",
          whatis = {
            "Name: pdtoolkit built with intel compiler ", "Version: 3.25 "
            , "Category: runtime library "
            , "Description: PDT is a framework for analyzing source code ", "URL http://www.cs.uoregon.edu/Research/pdt ",
          },
        },
      },
    },
    plasma = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["plasma/2.8.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Parallel Linear Algebra Software for Multicore Architectures ",
          ["Name"] = "plasma built with intel compiler ",
          ["Version"] = "2.8.0 ",
          ["canonical"] = "2.8.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/plasma/2.8.0",
          ["help"] = [[
 
This module loads the plasma library built with the intel compiler
toolchain.

Version 2.8.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/plasma/2.8.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000002.000000008.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/plasma/2.8.0/bin"] = 1,
          },
          ["wV"] = "000000002.000000008.*zfinal",
          whatis = {
            "Name: plasma built with intel compiler ", "Version: 2.8.0 "
            , "Category: runtime library "
            , "Description: Parallel Linear Algebra Software for Multicore Architectures ", "URL https://bitbucket.org/icl/plasma ",
          },
        },
      },
    },
    ["py2-numpy"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-numpy/.version.1.15.3"]  = {
          ["Version"] = ".version.1.15.3",
          ["canonical"] = ".version.1.15.3",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/py2-numpy/.version.1.15.3",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000001.000000015.000000003.*zfinal",
          ["wV"] = "*version.000000001.000000015.000000003.*zfinal",
        },
        ["py2-numpy/1.15.3"]  = {
          ["Category"] = "python module ",
          ["Description"] = "NumPy array processing for numbers, strings, records and objects ",
          ["Name"] = "python-numpy built with intel compiler ",
          ["Version"] = "1.15.3 ",
          ["canonical"] = "1.15.3",
          ["family"] = "numpy",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/py2-numpy/1.15.3",
          ["help"] = [[
 
This module loads the numpy library built with python
and the intel compiler toolchain.

Version 1.15.3


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000001.000000015.000000003.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/numpy/1.15.3/bin"] = 1,
          },
          ["wV"] = "000000001.000000015.000000003.*zfinal",
          whatis = {
            "Name: python-numpy built with intel compiler ", "Version: 1.15.3 "
            , "Category: python module "
            , "Description: NumPy array processing for numbers, strings, records and objects ", "URL http://sourceforge.net/projects/numpy ",
          },
        },
      },
    },
    ["py3-numpy"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-numpy/.version.1.15.3"]  = {
          ["Version"] = ".version.1.15.3",
          ["canonical"] = ".version.1.15.3",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/py3-numpy/.version.1.15.3",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000001.000000015.000000003.*zfinal",
          ["wV"] = "*version.000000001.000000015.000000003.*zfinal",
        },
        ["py3-numpy/1.15.3"]  = {
          ["Category"] = "python module ",
          ["Description"] = "NumPy array processing for numbers, strings, records and objects ",
          ["Name"] = "python34-numpy built with intel compiler ",
          ["Version"] = "1.15.3 ",
          ["canonical"] = "1.15.3",
          ["family"] = "numpy",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/py3-numpy/1.15.3",
          ["help"] = [[
 
This module loads the numpy library built with python34
and the intel compiler toolchain.

Version 1.15.3


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000001.000000015.000000003.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/numpy/1.15.3/bin"] = 1,
          },
          ["wV"] = "000000001.000000015.000000003.*zfinal",
          whatis = {
            "Name: python34-numpy built with intel compiler ", "Version: 1.15.3 "
            , "Category: python module "
            , "Description: NumPy array processing for numbers, strings, records and objects ", "URL http://sourceforge.net/projects/numpy ",
          },
        },
      },
    },
    scotch = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scotch/6.0.6"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Graph, mesh and hypergraph partitioning library ",
          ["Name"] = "scotch built with intel compiler ",
          ["Version"] = "6.0.6 ",
          ["canonical"] = "6.0.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/scotch/6.0.6",
          ["help"] = [[
 
This module loads the scotch library built with the intel compiler
toolchain.

Version 6.0.6


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/scotch/6.0.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000006.000000000.000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/scotch/6.0.6/bin"] = 1,
          },
          ["wV"] = "000000006.000000000.000000006.*zfinal",
          whatis = {
            "Name: scotch built with intel compiler ", "Version: 6.0.6 "
            , "Category: runtime library "
            , "Description: Graph, mesh and hypergraph partitioning library ", "URL http://www.labri.fr/perso/pelegrin/scotch/ ",
          },
        },
      },
    },
    superlu = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["superlu/.version.5.2.1"]  = {
          ["Version"] = ".version.5.2.1",
          ["canonical"] = ".version.5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/superlu/.version.5.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "*version.000000005.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000002.000000001.*zfinal",
        },
        ["superlu/5.2.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library for the direct solution of linear equations ",
          ["Name"] = "superlu built with intel compiler ",
          ["Version"] = "5.2.1 ",
          ["canonical"] = "5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel/superlu/5.2.1",
          ["help"] = [[
 
This module loads the SuperLU library built with the intel compiler
toolchain.
 
Note that this build of SuperLU leverages the OpenBLAS linear algebra libraries.
Consequently, openblas is loaded automatically with this module.

Version 5.2.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/superlu/5.2.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel",
          ["pV"] = "000000005.000000002.000000001.*zfinal",
          ["wV"] = "000000005.000000002.000000001.*zfinal",
          whatis = {
            "Name: superlu built with intel compiler ", "Version: 5.2.1 "
            , "Category: runtime library "
            , "Description: A general purpose library for the direct solution of linear equations ", "http://crd.lbl.gov/~xiaoye/SuperLU/ ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/intel-impi"]  = {
    adios = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["adios/.version.1.13.1"]  = {
          ["Version"] = ".version.1.13.1",
          ["canonical"] = ".version.1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/adios/.version.1.13.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000001.000000013.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000013.000000001.*zfinal",
        },
        ["adios/1.13.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "The Adaptable IO System (ADIOS) ",
          ["Name"] = "ADIOS built with intel compiler and impi MPI ",
          ["Version"] = "1.13.1 ",
          ["canonical"] = "1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/adios/1.13.1",
          ["help"] = [[
 
This module loads the ADIOS library built with the intel compiler
toolchain and the impi MPI stack.

Version 1.13.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/adios/1.13.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000001.000000013.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/adios/1.13.1/bin"] = 1,
          },
          ["wV"] = "000000001.000000013.000000001.*zfinal",
          whatis = {
            "Name: ADIOS built with intel compiler and impi MPI ", "Version: 1.13.1 "
            , "Category: runtime library ", "Description: The Adaptable IO System (ADIOS) ", "http://www.olcf.ornl.gov/center-projects/adios/ ",
          },
        },
      },
    },
    boost = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["boost/.version.1.71.0"]  = {
          ["Version"] = ".version.1.71.0",
          ["canonical"] = ".version.1.71.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/boost/.version.1.71.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000001.000000071.*zfinal",
          ["wV"] = "*version.000000001.000000071.*zfinal",
        },
        ["boost/1.71.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Boost free peer-reviewed portable C++ source libraries ",
          ["Name"] = "BOOST built with intel compiler and impi MPI ",
          ["Version"] = "1.71.0 ",
          ["canonical"] = "1.71.0",
          ["family"] = "boost",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/boost/1.71.0",
          ["help"] = [[
 
This module loads the BOOST library built with the intel compiler toolchain
and the impi MPI stack.

Version 1.71.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/boost/1.71.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000001.000000071.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/boost/1.71.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000071.*zfinal",
          whatis = {
            "Name: BOOST built with intel compiler and impi MPI ", "Version: 1.71.0 "
            , "Category: runtime library "
            , "Description: Boost free peer-reviewed portable C++ source libraries ", "http://www.boost.org ",
          },
        },
      },
    },
    dimemas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["dimemas/.version.5.4.1"]  = {
          ["Version"] = ".version.5.4.1",
          ["canonical"] = ".version.5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/dimemas/.version.5.4.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000005.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000004.000000001.*zfinal",
        },
        ["dimemas/5.4.1"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Dimemas tool ",
          ["Name"] = "dimemas built with intel compiler and impi MPI ",
          ["Version"] = "5.4.1 ",
          ["canonical"] = "5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/dimemas/5.4.1",
          ["help"] = [[
 
This module loads the dimemas library built with the intel compiler
toolchain and the impi MPI stack.

Version 5.4.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000005.000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/dimemas/5.4.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000004.000000001.*zfinal",
          whatis = {
            "Name: dimemas built with intel compiler and impi MPI ", "Version: 5.4.1 "
            , "Category: performance tool ", "Description: Dimemas tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    extrae = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["extrae/.version.3.7.0"]  = {
          ["Version"] = ".version.3.7.0",
          ["canonical"] = ".version.3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/extrae/.version.3.7.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000003.000000007.*zfinal",
          ["wV"] = "*version.000000003.000000007.*zfinal",
        },
        ["extrae/3.7.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Extrae tool ",
          ["Name"] = "extrae built with intel compiler and impi MPI ",
          ["Version"] = "3.7.0 ",
          ["canonical"] = "3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/extrae/3.7.0",
          ["help"] = [[
 
This module loads the extrae library built with the intel compiler
toolchain and the impi MPI stack.

Version 3.7.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/extrae/3.7.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/extrae/3.7.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
          whatis = {
            "Name: extrae built with intel compiler and impi MPI ", "Version: 3.7.0 "
            , "Category: performance tool ", "Description: Extrae tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    hypre = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hypre/.version.2.18.1"]  = {
          ["Version"] = ".version.2.18.1",
          ["canonical"] = ".version.2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/hypre/.version.2.18.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000002.000000018.000000001.*zfinal",
          ["wV"] = "*version.000000002.000000018.000000001.*zfinal",
        },
        ["hypre/2.18.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Scalable algorithms for solving linear systems of equations ",
          ["Name"] = "hypre built with intel compiler and impi MPI ",
          ["Version"] = "2.18.1 ",
          ["canonical"] = "2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/hypre/2.18.1",
          ["help"] = [[
 
This module loads the hypre library built with the intel compiler
toolchain and the impi MPI stack.
 
Note that this build of hypre leverages the superlu and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 2.18.1


]],
          lpathA = {
            ["%{MKLROOT}/lib/intel64"] = 1,
            ["/opt/ohpc/pub/libs/intel/impi/hypre/2.18.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000002.000000018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/hypre/2.18.1/bin"] = 1,
          },
          ["wV"] = "000000002.000000018.000000001.*zfinal",
          whatis = {
            "Name: hypre built with intel compiler and impi MPI ", "Version: 2.18.1 "
            , "Category: runtime library "
            , "Description: Scalable algorithms for solving linear systems of equations ", "http://www.llnl.gov/casc/hypre/ ",
          },
        },
      },
    },
    imb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["imb/.version.2018.1"]  = {
          ["Version"] = ".version.2018.1",
          ["canonical"] = ".version.2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/imb/.version.2018.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000002018.000000001.*zfinal",
          ["wV"] = "*version.000002018.000000001.*zfinal",
        },
        ["imb/2018.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Intel MPI Benchmarks (IMB) ",
          ["Name"] = "imb built with intel compiler and impi MPI ",
          ["Version"] = "2018.1 ",
          ["canonical"] = "2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/imb/2018.1",
          ["help"] = [[
 
This module loads the imb library built with the intel compiler
toolchain and the impi MPI stack.

Version 2018.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000002018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/imb/2018.1/bin"] = 1,
          },
          ["wV"] = "000002018.000000001.*zfinal",
          whatis = {
            "Name: imb built with intel compiler and impi MPI ", "Version: 2018.1 "
            , "Category: runtime library ", "Description: Intel MPI Benchmarks (IMB) ", "URL https://software.intel.com/en-us/articles/intel-mpi-benchmarks ",
          },
        },
      },
    },
    mfem = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mfem/.version.4.0"]  = {
          ["Version"] = ".version.4.0",
          ["canonical"] = ".version.4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/mfem/.version.4.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000004.*zfinal",
          ["wV"] = "*version.000000004.*zfinal",
        },
        ["mfem/4.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Lightweight, general, scalable C++ library for finite element methods ",
          ["Name"] = "mfem built with intel compiler and impi MPI ",
          ["Version"] = "4.0 ",
          ["canonical"] = "4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/mfem/4.0",
          ["help"] = [[
 
This module loads the MFEM library built with the intel compiler
toolchain and the impi MPI stack.
 

Version 4.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/mfem/4.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/mfem/4.0/bin"] = 1,
          },
          ["wV"] = "000000004.*zfinal",
          whatis = {
            "Name: mfem built with intel compiler and impi MPI ", "Version: 4.0 "
            , "Category: runtime library "
            , "Description: Lightweight, general, scalable C++ library for finite element methods ", "http://mfem.org ",
          },
        },
      },
    },
    mumps = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mumps/.version.5.2.1"]  = {
          ["Version"] = ".version.5.2.1",
          ["canonical"] = ".version.5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/mumps/.version.5.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000005.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000002.000000001.*zfinal",
        },
        ["mumps/5.2.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A MUltifrontal Massively Parallel Sparse direct Solver ",
          ["Name"] = "mumps built with intel compiler and impi MPI ",
          ["Version"] = "5.2.1 ",
          ["canonical"] = "5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/mumps/5.2.1",
          ["help"] = [[
 
This module loads the mumps library built with the intel compiler
toolchain and the impi MPI stack.
 

Version 5.2.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/mumps/5.2.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000005.000000002.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/mumps/5.2.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000002.000000001.*zfinal",
          whatis = {
            "Name: mumps built with intel compiler and impi MPI ", "Version: 5.2.1 "
            , "Category: runtime library "
            , "Description: A MUltifrontal Massively Parallel Sparse direct Solver ", "http://mumps.enseeiht.fr/ ",
          },
        },
      },
    },
    netcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf/.version.4.7.1"]  = {
          ["Version"] = ".version.4.7.1",
          ["canonical"] = ".version.4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/netcdf/.version.4.7.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000004.000000007.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000007.000000001.*zfinal",
        },
        ["netcdf/4.7.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF built with intel toolchain ",
          ["Version"] = "4.7.1 ",
          ["canonical"] = "4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/netcdf/4.7.1",
          ["help"] = [[
 
This module loads the NetCDF C API built with the intel compiler
toolchain and the impi MPI stack.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5. Consequently, the phdf5 package is loaded automatically with this module.
A typical compilation step for C applications requiring NetCDF is as follows:
 
$CC -I$NETCDF_INC app.c -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.7.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/netcdf/4.7.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000004.000000007.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/netcdf/4.7.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000007.000000001.*zfinal",
          whatis = {
            "Name: NETCDF built with intel toolchain ", "Version: 4.7.1 "
            , "Category: runtime library "
            , "Description: C Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-cxx"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-cxx/.version.4.3.1"]  = {
          ["Version"] = ".version.4.3.1",
          ["canonical"] = ".version.4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/netcdf-cxx/.version.4.3.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000004.000000003.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000003.000000001.*zfinal",
        },
        ["netcdf-cxx/4.3.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C++ Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_CXX built with intel toolchain ",
          ["Version"] = "4.3.1 ",
          ["canonical"] = "4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/netcdf-cxx/4.3.1",
          ["help"] = [[
 
This module loads the NetCDF C++ API built with the intel compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for C++ applications requiring NetCDF is as follows:
 
$CXX -I$NETCDF_CXX_INC app.cpp -L$NETCDF_CXX_LIB -lnetcdf_c++4 -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.3.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/netcdf-cxx/4.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000004.000000003.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/netcdf-cxx/4.3.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000003.000000001.*zfinal",
          whatis = {
            "Name: NETCDF_CXX built with intel toolchain ", "Version: 4.3.1 "
            , "Category: runtime library "
            , "Description: C++ Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-fortran"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-fortran/.version.4.5.2"]  = {
          ["Version"] = ".version.4.5.2",
          ["canonical"] = ".version.4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/netcdf-fortran/.version.4.5.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000004.000000005.000000002.*zfinal",
          ["wV"] = "*version.000000004.000000005.000000002.*zfinal",
        },
        ["netcdf-fortran/4.5.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Fortran Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_FORTRAN built with intel toolchain ",
          ["Version"] = "4.5.2 ",
          ["canonical"] = "4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/netcdf-fortran/4.5.2",
          ["help"] = [[
 
This module loads the NetCDF Fortran API built with the intel compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for Fortran applications requiring NetCDF is as follows:
 

]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/netcdf-fortran/4.5.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000004.000000005.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/netcdf-fortran/4.5.2/bin"] = 1,
          },
          ["wV"] = "000000004.000000005.000000002.*zfinal",
          whatis = {
            "Name: NETCDF_FORTRAN built with intel toolchain ", "Version: 4.5.2 "
            , "Category: runtime library "
            , "Description: Fortran Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    omb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["omb/.version.5.6.2"]  = {
          ["Version"] = ".version.5.6.2",
          ["canonical"] = ".version.5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/omb/.version.5.6.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000005.000000006.000000002.*zfinal",
          ["wV"] = "*version.000000005.000000006.000000002.*zfinal",
        },
        ["omb/5.6.2"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "OSU Micro-benchmarks ",
          ["Name"] = "OSU Micro-benchmarks built with intel compiler and impi MPI ",
          ["Version"] = "5.6.2 ",
          ["canonical"] = "5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/omb/5.6.2",
          ["help"] = [[
 
This module loads the OSU Micro-benchmarks built with the intel toolchain
and the impi MPI stack.

Version 5.6.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000005.000000006.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/omb/5.6.2/bin/osu-micro-benchmarks/mpi/collective"] = 1,
            ["/opt/ohpc/pub/libs/intel/impi/omb/5.6.2/bin/osu-micro-benchmarks/mpi/one-sided"] = 1,
            ["/opt/ohpc/pub/libs/intel/impi/omb/5.6.2/bin/osu-micro-benchmarks/mpi/pt2pt"] = 1,
            ["/opt/ohpc/pub/libs/intel/impi/omb/5.6.2/bin/osu-micro-benchmarks/mpi/startup"] = 1,
          },
          ["wV"] = "000000005.000000006.000000002.*zfinal",
          whatis = {
            "Name: OSU Micro-benchmarks built with intel compiler and impi MPI "
            , "Version: 5.6.2 ", "Category: performance tool "
            , "Description: OSU Micro-benchmarks ", "http://mvapich.cse.ohio-state.edu/benchmarks/ ",
          },
        },
      },
    },
    petsc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["petsc/.version.3.12.0"]  = {
          ["Version"] = ".version.3.12.0",
          ["canonical"] = ".version.3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/petsc/.version.3.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000003.000000012.*zfinal",
          ["wV"] = "*version.000000003.000000012.*zfinal",
        },
        ["petsc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Portable Extensible Toolkit for Scientific Computation ",
          ["Name"] = "petsc built with intel compiler and impi MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/petsc/3.12.0",
          ["help"] = [[
 
This module loads the PETSc library built with the intel compiler
toolchain and the impi MPI stack.
 

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/petsc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000003.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/petsc/3.12.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: petsc built with intel compiler and impi MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: Portable Extensible Toolkit for Scientific Computation ", "http://www.mcs.anl.gov/petsc/ ",
          },
        },
      },
    },
    phdf5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["phdf5/.version.1.10.5"]  = {
          ["Version"] = ".version.1.10.5",
          ["canonical"] = ".version.1.10.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/phdf5/.version.1.10.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000001.000000010.000000005.*zfinal",
          ["wV"] = "*version.000000001.000000010.000000005.*zfinal",
        },
        ["phdf5/1.10.5"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library and file format for storing scientific data ",
          ["Name"] = "hdf5 built with intel compiler and impi MPI ",
          ["Version"] = "1.10.5 ",
          ["canonical"] = "1.10.5",
          ["family"] = "hdf5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/phdf5/1.10.5",
          ["help"] = [[
 
This module loads the parallel hdf5 library built with the intel compiler
toolchain and the impi MPI stack.

Version 1.10.5


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/hdf5/1.10.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000001.000000010.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/hdf5/1.10.5/bin"] = 1,
          },
          ["wV"] = "000000001.000000010.000000005.*zfinal",
          whatis = {
            "Name: hdf5 built with intel compiler and impi MPI ", "Version: 1.10.5 "
            , "Category: runtime library "
            , "Description: A general purpose library and file format for storing scientific data ", "http://www.hdfgroup.org/HDF5 ",
          },
        },
      },
    },
    pnetcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["pnetcdf/.version.1.12.0"]  = {
          ["Version"] = ".version.1.12.0",
          ["canonical"] = ".version.1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/pnetcdf/.version.1.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000001.000000012.*zfinal",
          ["wV"] = "*version.000000001.000000012.*zfinal",
        },
        ["pnetcdf/1.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A Parallel NetCDF library (PnetCDF) ",
          ["Name"] = "pnetcdf built with intel compiler and impi MPI ",
          ["Version"] = "1.12.0 ",
          ["canonical"] = "1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/pnetcdf/1.12.0",
          ["help"] = [[
 
This module loads the pnetcdf library built with the intel compiler
toolchain and the impi MPI stack.

Version 1.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/pnetcdf/1.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000001.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/pnetcdf/1.12.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000012.*zfinal",
          whatis = {
            "Name: pnetcdf built with intel compiler and impi MPI ", "Version: 1.12.0 "
            , "Category: runtime library ", "Description: A Parallel NetCDF library (PnetCDF) ", "URL http://cucis.ece.northwestern.edu/projects/PnetCDF ",
          },
        },
      },
    },
    ptscotch = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ptscotch/6.0.6"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Graph, mesh and hypergraph partitioning library using MPI ",
          ["Name"] = "ptscotch built with intel compiler and impi MPI ",
          ["Version"] = "6.0.6 ",
          ["canonical"] = "6.0.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/ptscotch/6.0.6",
          ["help"] = [[
 
This module loads the Scotch library built with the intel compiler
toolchain and the impi MPI stack.
 

Version 6.0.6


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/ptscotch/6.0.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000006.000000000.000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/ptscotch/6.0.6/bin"] = 1,
          },
          ["wV"] = "000000006.000000000.000000006.*zfinal",
          whatis = {
            "Name: ptscotch built with intel compiler and impi MPI ", "Version: 6.0.6 "
            , "Category: runtime library "
            , "Description: Graph, mesh and hypergraph partitioning library using MPI ", "http://www.labri.fr/perso/pelegrin/scotch/ ",
          },
        },
      },
    },
    ["py2-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-mpi4py/.version.3.0.2"]  = {
          ["Version"] = ".version.3.0.2",
          ["canonical"] = ".version.3.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/py2-mpi4py/.version.3.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000003.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000002.*zfinal",
        },
        ["py2-mpi4py/3.0.2"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python-mpi4py built with intel compiler and impi ",
          ["Version"] = "3.0.2 ",
          ["canonical"] = "3.0.2",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/py2-mpi4py/3.0.2",
          ["help"] = [[
 
This module loads the python-mpi4py library built with the intel compiler
toolchain and the impi MPI library.

Version 3.0.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000003.000000000.000000002.*zfinal",
          ["wV"] = "000000003.000000000.000000002.*zfinal",
          whatis = {
            "Name: python-mpi4py built with intel compiler and impi ", "Version: 3.0.2 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    ["py3-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-mpi4py/.version.3.0.1"]  = {
          ["Version"] = ".version.3.0.1",
          ["canonical"] = ".version.3.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/py3-mpi4py/.version.3.0.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000003.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000001.*zfinal",
        },
        ["py3-mpi4py/3.0.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python34-mpi4py built with intel compiler and impi ",
          ["Version"] = "3.0.1 ",
          ["canonical"] = "3.0.1",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/py3-mpi4py/3.0.1",
          ["help"] = [[
 
This module loads the python34-mpi4py library built with the intel compiler
toolchain and the impi MPI library.

Version 3.0.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000003.000000000.000000001.*zfinal",
          ["wV"] = "000000003.000000000.000000001.*zfinal",
          whatis = {
            "Name: python34-mpi4py built with intel compiler and impi ", "Version: 3.0.1 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    scalapack = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalapack/.version.2.0.2"]  = {
          ["Version"] = ".version.2.0.2",
          ["canonical"] = ".version.2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/scalapack/.version.2.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000002.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000002.000000000.000000002.*zfinal",
        },
        ["scalapack/2.0.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A subset of LAPACK routines redesigned for heterogenous computing ",
          ["Name"] = "scalapack built with intel compiler and impi MPI ",
          ["Version"] = "2.0.2 ",
          ["canonical"] = "2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/scalapack/2.0.2",
          ["help"] = [[
 
This module loads the ScaLAPACK library built with the intel compiler
toolchain and the impi MPI stack.
 

Version 2.0.2


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/scalapack/2.0.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000002.000000000.000000002.*zfinal",
          ["wV"] = "000000002.000000000.000000002.*zfinal",
          whatis = {
            "Name: scalapack built with intel compiler and impi MPI ", "Version: 2.0.2 "
            , "Category: runtime library "
            , "Description: A subset of LAPACK routines redesigned for heterogenous computing ", "http://www.netlib.org/lapack-dev/ ",
          },
        },
      },
    },
    scalasca = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalasca/.version.2.5"]  = {
          ["Version"] = ".version.2.5",
          ["canonical"] = ".version.2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/scalasca/.version.2.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000002.000000005.*zfinal",
          ["wV"] = "*version.000000002.000000005.*zfinal",
        },
        ["scalasca/2.5"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Toolset for performance analysis of large-scale parallel applications ",
          ["Name"] = "scalasca built with intel compiler and impi MPI ",
          ["Version"] = "2.5 ",
          ["canonical"] = "2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/scalasca/2.5",
          ["help"] = [[
 
This module loads the scalasca library built with the intel compiler
toolchain and the impi MPI stack.

Version 2.5


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000002.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/scalasca/2.5/bin"] = 1,
          },
          ["wV"] = "000000002.000000005.*zfinal",
          whatis = {
            "Name: scalasca built with intel compiler and impi MPI ", "Version: 2.5 "
            , "Category: performance tool "
            , "Description: Toolset for performance analysis of large-scale parallel applications ", "URL http://www.scalasca.org ",
          },
        },
      },
    },
    scorep = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scorep/.version.6.0"]  = {
          ["Version"] = ".version.6.0",
          ["canonical"] = ".version.6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/scorep/.version.6.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000006.*zfinal",
          ["wV"] = "*version.000000006.*zfinal",
        },
        ["scorep/6.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Scalable Performance Measurement Infrastructure for Parallel Codes ",
          ["Name"] = "scorep built with intel compiler and impi MPI ",
          ["Version"] = "6.0 ",
          ["canonical"] = "6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/scorep/6.0",
          ["help"] = [[
 
This module loads the scorep library built with the intel compiler
toolchain and the impi MPI stack.

Version 6.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/scorep/6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/scorep/6.0/bin"] = 1,
          },
          ["wV"] = "000000006.*zfinal",
          whatis = {
            "Name: scorep built with intel compiler and impi MPI ", "Version: 6.0 "
            , "Category: performance tool "
            , "Description: Scalable Performance Measurement Infrastructure for Parallel Codes ", "URL http://www.vi-hps.org/projects/score-p/ ",
          },
        },
      },
    },
    sionlib = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["sionlib/.version.1.7.4"]  = {
          ["Version"] = ".version.1.7.4",
          ["canonical"] = ".version.1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/sionlib/.version.1.7.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000001.000000007.000000004.*zfinal",
          ["wV"] = "*version.000000001.000000007.000000004.*zfinal",
        },
        ["sionlib/1.7.4"]  = {
          ["Category"] = "IO Library ",
          ["Description"] = "Scalable I/O Library for Parallel Access to Task-Local Files ",
          ["Name"] = "sionlib built with intel compiler and impi MPI ",
          ["Version"] = "1.7.4 ",
          ["canonical"] = "1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/sionlib/1.7.4",
          ["help"] = [[
 
This module loads the sionlib library built with the intel compiler
toolchain and the impi MPI stack.

Version 1.7.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/sionlib/1.7.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000001.000000007.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/sionlib/1.7.4/bin"] = 1,
          },
          ["wV"] = "000000001.000000007.000000004.*zfinal",
          whatis = {
            "Name: sionlib built with intel compiler and impi MPI ", "Version: 1.7.4 "
            , "Category: IO Library "
            , "Description: Scalable I/O Library for Parallel Access to Task-Local Files ", "URL http://www.fz-juelich.de/ias/jsc/EN/Expertise/Support/Software/SIONlib/_node.html ",
          },
        },
      },
    },
    slepc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["slepc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A library for solving large scale sparse eigenvalue problems ",
          ["Name"] = "slepc built with intel compiler and impi MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/slepc/3.12.0",
          ["help"] = [[
 
This module loads the slepc library built with the intel compiler
toolchain and the impi MPI stack.

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/slepc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000003.000000012.*zfinal",
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: slepc built with intel compiler and impi MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: A library for solving large scale sparse eigenvalue problems ", "URL http://slepc.upv.es ",
          },
        },
      },
    },
    superlu_dist = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["superlu_dist/.version.6.1.1"]  = {
          ["Version"] = ".version.6.1.1",
          ["canonical"] = ".version.6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/superlu_dist/.version.6.1.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000006.000000001.000000001.*zfinal",
          ["wV"] = "*version.000000006.000000001.000000001.*zfinal",
        },
        ["superlu_dist/6.1.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library for the direct solution of linear equations ",
          ["Name"] = "superlu_dist built with intel compiler and impi MPI ",
          ["Version"] = "6.1.1 ",
          ["canonical"] = "6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/superlu_dist/6.1.1",
          ["help"] = [[
 
This module loads the SuperLU_dist library built with the intel compiler
toolchain and the impi MPI stack.
 
Note that this build of SuperLU_dist leverages the metis and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 6.1.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/superlu_dist/6.1.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000006.000000001.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/superlu_dist/6.1.1/bin"] = 1,
          },
          ["wV"] = "000000006.000000001.000000001.*zfinal",
          whatis = {
            "Name: superlu_dist built with intel compiler and impi MPI ", "Version: 6.1.1 "
            , "Category: runtime library "
            , "Description: A general purpose library for the direct solution of linear equations ", "http://crd-legacy.lbl.gov/~xiaoye/SuperLU/ ",
          },
        },
      },
    },
    tau = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tau/.version.2.28"]  = {
          ["Version"] = ".version.2.28",
          ["canonical"] = ".version.2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/tau/.version.2.28",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000002.000000028.*zfinal",
          ["wV"] = "*version.000000002.000000028.*zfinal",
        },
        ["tau/2.28"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Tuning and Analysis Utilities Profiling Package ",
          ["Name"] = "tau built with intel compiler ",
          ["Version"] = "2.28 ",
          ["canonical"] = "2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/tau/2.28",
          ["help"] = [[
 
This module loads the tau library built with the intel compiler
toolchain and the impi MPI stack.

Version 2.28


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/tau/2.28/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000002.000000028.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/tau/2.28/bin"] = 1,
          },
          ["wV"] = "000000002.000000028.*zfinal",
          whatis = {
            "Name: tau built with intel compiler ", "Version: 2.28 "
            , "Category: runtime library "
            , "Description: Tuning and Analysis Utilities Profiling Package ", "URL http://www.cs.uoregon.edu/research/tau/home.php ",
          },
        },
      },
    },
    trilinos = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["trilinos/.version.12.14.1"]  = {
          ["Version"] = ".version.12.14.1",
          ["canonical"] = ".version.12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/trilinos/.version.12.14.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "*version.000000012.000000014.000000001.*zfinal",
          ["wV"] = "*version.000000012.000000014.000000001.*zfinal",
        },
        ["trilinos/12.14.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A collection of libraries of numerical algorithms ",
          ["Name"] = "trilinos built with intel compiler and impi MPI ",
          ["Version"] = "12.14.1 ",
          ["canonical"] = "12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-impi/trilinos/12.14.1",
          ["help"] = [[
 
This module loads the trilinos library built with the intel compiler
toolchain and the impi MPI stack.

Version 12.14.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/impi/trilinos/12.14.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-impi",
          ["pV"] = "000000012.000000014.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/impi/trilinos/12.14.1/bin"] = 1,
          },
          ["wV"] = "000000012.000000014.000000001.*zfinal",
          whatis = {
            "Name: trilinos built with intel compiler and impi MPI ", "Version: 12.14.1 "
            , "Category: runtime library "
            , "Description: A collection of libraries of numerical algorithms ", "URL https://trilinos.org/ ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/intel-mpich"]  = {
    adios = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["adios/.version.1.13.1"]  = {
          ["Version"] = ".version.1.13.1",
          ["canonical"] = ".version.1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/adios/.version.1.13.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000001.000000013.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000013.000000001.*zfinal",
        },
        ["adios/1.13.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "The Adaptable IO System (ADIOS) ",
          ["Name"] = "ADIOS built with intel compiler and mpich MPI ",
          ["Version"] = "1.13.1 ",
          ["canonical"] = "1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/adios/1.13.1",
          ["help"] = [[
 
This module loads the ADIOS library built with the intel compiler
toolchain and the mpich MPI stack.

Version 1.13.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/adios/1.13.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000001.000000013.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/adios/1.13.1/bin"] = 1,
          },
          ["wV"] = "000000001.000000013.000000001.*zfinal",
          whatis = {
            "Name: ADIOS built with intel compiler and mpich MPI ", "Version: 1.13.1 "
            , "Category: runtime library ", "Description: The Adaptable IO System (ADIOS) ", "http://www.olcf.ornl.gov/center-projects/adios/ ",
          },
        },
      },
    },
    boost = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["boost/.version.1.71.0"]  = {
          ["Version"] = ".version.1.71.0",
          ["canonical"] = ".version.1.71.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/boost/.version.1.71.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000001.000000071.*zfinal",
          ["wV"] = "*version.000000001.000000071.*zfinal",
        },
        ["boost/1.71.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Boost free peer-reviewed portable C++ source libraries ",
          ["Name"] = "BOOST built with intel compiler and mpich MPI ",
          ["Version"] = "1.71.0 ",
          ["canonical"] = "1.71.0",
          ["family"] = "boost",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/boost/1.71.0",
          ["help"] = [[
 
This module loads the BOOST library built with the intel compiler toolchain
and the mpich MPI stack.

Version 1.71.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/boost/1.71.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000001.000000071.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/boost/1.71.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000071.*zfinal",
          whatis = {
            "Name: BOOST built with intel compiler and mpich MPI ", "Version: 1.71.0 "
            , "Category: runtime library "
            , "Description: Boost free peer-reviewed portable C++ source libraries ", "http://www.boost.org ",
          },
        },
      },
    },
    dimemas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["dimemas/.version.5.4.1"]  = {
          ["Version"] = ".version.5.4.1",
          ["canonical"] = ".version.5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/dimemas/.version.5.4.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000005.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000004.000000001.*zfinal",
        },
        ["dimemas/5.4.1"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Dimemas tool ",
          ["Name"] = "dimemas built with intel compiler and mpich MPI ",
          ["Version"] = "5.4.1 ",
          ["canonical"] = "5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/dimemas/5.4.1",
          ["help"] = [[
 
This module loads the dimemas library built with the intel compiler
toolchain and the mpich MPI stack.

Version 5.4.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000005.000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/dimemas/5.4.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000004.000000001.*zfinal",
          whatis = {
            "Name: dimemas built with intel compiler and mpich MPI ", "Version: 5.4.1 "
            , "Category: performance tool ", "Description: Dimemas tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    extrae = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["extrae/.version.3.7.0"]  = {
          ["Version"] = ".version.3.7.0",
          ["canonical"] = ".version.3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/extrae/.version.3.7.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000003.000000007.*zfinal",
          ["wV"] = "*version.000000003.000000007.*zfinal",
        },
        ["extrae/3.7.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Extrae tool ",
          ["Name"] = "extrae built with intel compiler and mpich MPI ",
          ["Version"] = "3.7.0 ",
          ["canonical"] = "3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/extrae/3.7.0",
          ["help"] = [[
 
This module loads the extrae library built with the intel compiler
toolchain and the mpich MPI stack.

Version 3.7.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/extrae/3.7.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/extrae/3.7.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
          whatis = {
            "Name: extrae built with intel compiler and mpich MPI ", "Version: 3.7.0 "
            , "Category: performance tool ", "Description: Extrae tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    hypre = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hypre/.version.2.18.1"]  = {
          ["Version"] = ".version.2.18.1",
          ["canonical"] = ".version.2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/hypre/.version.2.18.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000002.000000018.000000001.*zfinal",
          ["wV"] = "*version.000000002.000000018.000000001.*zfinal",
        },
        ["hypre/2.18.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Scalable algorithms for solving linear systems of equations ",
          ["Name"] = "hypre built with intel compiler and mpich MPI ",
          ["Version"] = "2.18.1 ",
          ["canonical"] = "2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/hypre/2.18.1",
          ["help"] = [[
 
This module loads the hypre library built with the intel compiler
toolchain and the mpich MPI stack.
 
Note that this build of hypre leverages the superlu and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 2.18.1


]],
          lpathA = {
            ["%{MKLROOT}/lib/intel64"] = 1,
            ["/opt/ohpc/pub/libs/intel/mpich/hypre/2.18.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000002.000000018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/hypre/2.18.1/bin"] = 1,
          },
          ["wV"] = "000000002.000000018.000000001.*zfinal",
          whatis = {
            "Name: hypre built with intel compiler and mpich MPI ", "Version: 2.18.1 "
            , "Category: runtime library "
            , "Description: Scalable algorithms for solving linear systems of equations ", "http://www.llnl.gov/casc/hypre/ ",
          },
        },
      },
    },
    imb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["imb/.version.2018.1"]  = {
          ["Version"] = ".version.2018.1",
          ["canonical"] = ".version.2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/imb/.version.2018.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000002018.000000001.*zfinal",
          ["wV"] = "*version.000002018.000000001.*zfinal",
        },
        ["imb/2018.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Intel MPI Benchmarks (IMB) ",
          ["Name"] = "imb built with intel compiler and mpich MPI ",
          ["Version"] = "2018.1 ",
          ["canonical"] = "2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/imb/2018.1",
          ["help"] = [[
 
This module loads the imb library built with the intel compiler
toolchain and the mpich MPI stack.

Version 2018.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000002018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/imb/2018.1/bin"] = 1,
          },
          ["wV"] = "000002018.000000001.*zfinal",
          whatis = {
            "Name: imb built with intel compiler and mpich MPI ", "Version: 2018.1 "
            , "Category: runtime library ", "Description: Intel MPI Benchmarks (IMB) ", "URL https://software.intel.com/en-us/articles/intel-mpi-benchmarks ",
          },
        },
      },
    },
    mfem = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mfem/.version.4.0"]  = {
          ["Version"] = ".version.4.0",
          ["canonical"] = ".version.4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/mfem/.version.4.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000004.*zfinal",
          ["wV"] = "*version.000000004.*zfinal",
        },
        ["mfem/4.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Lightweight, general, scalable C++ library for finite element methods ",
          ["Name"] = "mfem built with intel compiler and mpich MPI ",
          ["Version"] = "4.0 ",
          ["canonical"] = "4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/mfem/4.0",
          ["help"] = [[
 
This module loads the MFEM library built with the intel compiler
toolchain and the mpich MPI stack.
 

Version 4.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/mfem/4.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/mfem/4.0/bin"] = 1,
          },
          ["wV"] = "000000004.*zfinal",
          whatis = {
            "Name: mfem built with intel compiler and mpich MPI ", "Version: 4.0 "
            , "Category: runtime library "
            , "Description: Lightweight, general, scalable C++ library for finite element methods ", "http://mfem.org ",
          },
        },
      },
    },
    mumps = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mumps/.version.5.2.1"]  = {
          ["Version"] = ".version.5.2.1",
          ["canonical"] = ".version.5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/mumps/.version.5.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000005.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000002.000000001.*zfinal",
        },
        ["mumps/5.2.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A MUltifrontal Massively Parallel Sparse direct Solver ",
          ["Name"] = "mumps built with intel compiler and mpich MPI ",
          ["Version"] = "5.2.1 ",
          ["canonical"] = "5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/mumps/5.2.1",
          ["help"] = [[
 
This module loads the mumps library built with the intel compiler
toolchain and the mpich MPI stack.
 

Version 5.2.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/mumps/5.2.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000005.000000002.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/mumps/5.2.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000002.000000001.*zfinal",
          whatis = {
            "Name: mumps built with intel compiler and mpich MPI ", "Version: 5.2.1 "
            , "Category: runtime library "
            , "Description: A MUltifrontal Massively Parallel Sparse direct Solver ", "http://mumps.enseeiht.fr/ ",
          },
        },
      },
    },
    netcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf/.version.4.7.1"]  = {
          ["Version"] = ".version.4.7.1",
          ["canonical"] = ".version.4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/netcdf/.version.4.7.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000004.000000007.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000007.000000001.*zfinal",
        },
        ["netcdf/4.7.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF built with intel toolchain ",
          ["Version"] = "4.7.1 ",
          ["canonical"] = "4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/netcdf/4.7.1",
          ["help"] = [[
 
This module loads the NetCDF C API built with the intel compiler
toolchain and the mpich MPI stack.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5. Consequently, the phdf5 package is loaded automatically with this module.
A typical compilation step for C applications requiring NetCDF is as follows:
 
$CC -I$NETCDF_INC app.c -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.7.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/netcdf/4.7.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000004.000000007.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/netcdf/4.7.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000007.000000001.*zfinal",
          whatis = {
            "Name: NETCDF built with intel toolchain ", "Version: 4.7.1 "
            , "Category: runtime library "
            , "Description: C Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-cxx"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-cxx/.version.4.3.1"]  = {
          ["Version"] = ".version.4.3.1",
          ["canonical"] = ".version.4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/netcdf-cxx/.version.4.3.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000004.000000003.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000003.000000001.*zfinal",
        },
        ["netcdf-cxx/4.3.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C++ Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_CXX built with intel toolchain ",
          ["Version"] = "4.3.1 ",
          ["canonical"] = "4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/netcdf-cxx/4.3.1",
          ["help"] = [[
 
This module loads the NetCDF C++ API built with the intel compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for C++ applications requiring NetCDF is as follows:
 
$CXX -I$NETCDF_CXX_INC app.cpp -L$NETCDF_CXX_LIB -lnetcdf_c++4 -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.3.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/netcdf-cxx/4.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000004.000000003.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/netcdf-cxx/4.3.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000003.000000001.*zfinal",
          whatis = {
            "Name: NETCDF_CXX built with intel toolchain ", "Version: 4.3.1 "
            , "Category: runtime library "
            , "Description: C++ Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-fortran"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-fortran/.version.4.5.2"]  = {
          ["Version"] = ".version.4.5.2",
          ["canonical"] = ".version.4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/netcdf-fortran/.version.4.5.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000004.000000005.000000002.*zfinal",
          ["wV"] = "*version.000000004.000000005.000000002.*zfinal",
        },
        ["netcdf-fortran/4.5.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Fortran Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_FORTRAN built with intel toolchain ",
          ["Version"] = "4.5.2 ",
          ["canonical"] = "4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/netcdf-fortran/4.5.2",
          ["help"] = [[
 
This module loads the NetCDF Fortran API built with the intel compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for Fortran applications requiring NetCDF is as follows:
 

]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/netcdf-fortran/4.5.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000004.000000005.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/netcdf-fortran/4.5.2/bin"] = 1,
          },
          ["wV"] = "000000004.000000005.000000002.*zfinal",
          whatis = {
            "Name: NETCDF_FORTRAN built with intel toolchain ", "Version: 4.5.2 "
            , "Category: runtime library "
            , "Description: Fortran Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    omb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["omb/.version.5.6.2"]  = {
          ["Version"] = ".version.5.6.2",
          ["canonical"] = ".version.5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/omb/.version.5.6.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000005.000000006.000000002.*zfinal",
          ["wV"] = "*version.000000005.000000006.000000002.*zfinal",
        },
        ["omb/5.6.2"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "OSU Micro-benchmarks ",
          ["Name"] = "OSU Micro-benchmarks built with intel compiler and mpich MPI ",
          ["Version"] = "5.6.2 ",
          ["canonical"] = "5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/omb/5.6.2",
          ["help"] = [[
 
This module loads the OSU Micro-benchmarks built with the intel toolchain
and the mpich MPI stack.

Version 5.6.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000005.000000006.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/omb/5.6.2/bin/osu-micro-benchmarks/mpi/collective"] = 1,
            ["/opt/ohpc/pub/libs/intel/mpich/omb/5.6.2/bin/osu-micro-benchmarks/mpi/one-sided"] = 1,
            ["/opt/ohpc/pub/libs/intel/mpich/omb/5.6.2/bin/osu-micro-benchmarks/mpi/pt2pt"] = 1,
            ["/opt/ohpc/pub/libs/intel/mpich/omb/5.6.2/bin/osu-micro-benchmarks/mpi/startup"] = 1,
          },
          ["wV"] = "000000005.000000006.000000002.*zfinal",
          whatis = {
            "Name: OSU Micro-benchmarks built with intel compiler and mpich MPI "
            , "Version: 5.6.2 ", "Category: performance tool "
            , "Description: OSU Micro-benchmarks ", "http://mvapich.cse.ohio-state.edu/benchmarks/ ",
          },
        },
      },
    },
    petsc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["petsc/.version.3.12.0"]  = {
          ["Version"] = ".version.3.12.0",
          ["canonical"] = ".version.3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/petsc/.version.3.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000003.000000012.*zfinal",
          ["wV"] = "*version.000000003.000000012.*zfinal",
        },
        ["petsc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Portable Extensible Toolkit for Scientific Computation ",
          ["Name"] = "petsc built with intel compiler and mpich MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/petsc/3.12.0",
          ["help"] = [[
 
This module loads the PETSc library built with the intel compiler
toolchain and the mpich MPI stack.
 

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/petsc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000003.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/petsc/3.12.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: petsc built with intel compiler and mpich MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: Portable Extensible Toolkit for Scientific Computation ", "http://www.mcs.anl.gov/petsc/ ",
          },
        },
      },
    },
    phdf5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["phdf5/.version.1.10.5"]  = {
          ["Version"] = ".version.1.10.5",
          ["canonical"] = ".version.1.10.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/phdf5/.version.1.10.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000001.000000010.000000005.*zfinal",
          ["wV"] = "*version.000000001.000000010.000000005.*zfinal",
        },
        ["phdf5/1.10.5"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library and file format for storing scientific data ",
          ["Name"] = "hdf5 built with intel compiler and mpich MPI ",
          ["Version"] = "1.10.5 ",
          ["canonical"] = "1.10.5",
          ["family"] = "hdf5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/phdf5/1.10.5",
          ["help"] = [[
 
This module loads the parallel hdf5 library built with the intel compiler
toolchain and the mpich MPI stack.

Version 1.10.5


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/hdf5/1.10.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000001.000000010.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/hdf5/1.10.5/bin"] = 1,
          },
          ["wV"] = "000000001.000000010.000000005.*zfinal",
          whatis = {
            "Name: hdf5 built with intel compiler and mpich MPI ", "Version: 1.10.5 "
            , "Category: runtime library "
            , "Description: A general purpose library and file format for storing scientific data ", "http://www.hdfgroup.org/HDF5 ",
          },
        },
      },
    },
    pnetcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["pnetcdf/.version.1.12.0"]  = {
          ["Version"] = ".version.1.12.0",
          ["canonical"] = ".version.1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/pnetcdf/.version.1.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000001.000000012.*zfinal",
          ["wV"] = "*version.000000001.000000012.*zfinal",
        },
        ["pnetcdf/1.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A Parallel NetCDF library (PnetCDF) ",
          ["Name"] = "pnetcdf built with intel compiler and mpich MPI ",
          ["Version"] = "1.12.0 ",
          ["canonical"] = "1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/pnetcdf/1.12.0",
          ["help"] = [[
 
This module loads the pnetcdf library built with the intel compiler
toolchain and the mpich MPI stack.

Version 1.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/pnetcdf/1.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000001.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/pnetcdf/1.12.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000012.*zfinal",
          whatis = {
            "Name: pnetcdf built with intel compiler and mpich MPI ", "Version: 1.12.0 "
            , "Category: runtime library ", "Description: A Parallel NetCDF library (PnetCDF) ", "URL http://cucis.ece.northwestern.edu/projects/PnetCDF ",
          },
        },
      },
    },
    ptscotch = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ptscotch/6.0.6"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Graph, mesh and hypergraph partitioning library using MPI ",
          ["Name"] = "ptscotch built with intel compiler and mpich MPI ",
          ["Version"] = "6.0.6 ",
          ["canonical"] = "6.0.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/ptscotch/6.0.6",
          ["help"] = [[
 
This module loads the Scotch library built with the intel compiler
toolchain and the mpich MPI stack.
 

Version 6.0.6


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/ptscotch/6.0.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000006.000000000.000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/ptscotch/6.0.6/bin"] = 1,
          },
          ["wV"] = "000000006.000000000.000000006.*zfinal",
          whatis = {
            "Name: ptscotch built with intel compiler and mpich MPI ", "Version: 6.0.6 "
            , "Category: runtime library "
            , "Description: Graph, mesh and hypergraph partitioning library using MPI ", "http://www.labri.fr/perso/pelegrin/scotch/ ",
          },
        },
      },
    },
    ["py2-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-mpi4py/.version.3.0.2"]  = {
          ["Version"] = ".version.3.0.2",
          ["canonical"] = ".version.3.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/py2-mpi4py/.version.3.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000003.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000002.*zfinal",
        },
        ["py2-mpi4py/3.0.2"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python-mpi4py built with intel compiler and mpich ",
          ["Version"] = "3.0.2 ",
          ["canonical"] = "3.0.2",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/py2-mpi4py/3.0.2",
          ["help"] = [[
 
This module loads the python-mpi4py library built with the intel compiler
toolchain and the mpich MPI library.

Version 3.0.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000003.000000000.000000002.*zfinal",
          ["wV"] = "000000003.000000000.000000002.*zfinal",
          whatis = {
            "Name: python-mpi4py built with intel compiler and mpich ", "Version: 3.0.2 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    ["py3-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-mpi4py/.version.3.0.1"]  = {
          ["Version"] = ".version.3.0.1",
          ["canonical"] = ".version.3.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/py3-mpi4py/.version.3.0.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000003.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000001.*zfinal",
        },
        ["py3-mpi4py/3.0.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python34-mpi4py built with intel compiler and mpich ",
          ["Version"] = "3.0.1 ",
          ["canonical"] = "3.0.1",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/py3-mpi4py/3.0.1",
          ["help"] = [[
 
This module loads the python34-mpi4py library built with the intel compiler
toolchain and the mpich MPI library.

Version 3.0.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000003.000000000.000000001.*zfinal",
          ["wV"] = "000000003.000000000.000000001.*zfinal",
          whatis = {
            "Name: python34-mpi4py built with intel compiler and mpich ", "Version: 3.0.1 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    scalapack = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalapack/.version.2.0.2"]  = {
          ["Version"] = ".version.2.0.2",
          ["canonical"] = ".version.2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/scalapack/.version.2.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000002.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000002.000000000.000000002.*zfinal",
        },
        ["scalapack/2.0.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A subset of LAPACK routines redesigned for heterogenous computing ",
          ["Name"] = "scalapack built with intel compiler and mpich MPI ",
          ["Version"] = "2.0.2 ",
          ["canonical"] = "2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/scalapack/2.0.2",
          ["help"] = [[
 
This module loads the ScaLAPACK library built with the intel compiler
toolchain and the mpich MPI stack.
 

Version 2.0.2


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/scalapack/2.0.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000002.000000000.000000002.*zfinal",
          ["wV"] = "000000002.000000000.000000002.*zfinal",
          whatis = {
            "Name: scalapack built with intel compiler and mpich MPI ", "Version: 2.0.2 "
            , "Category: runtime library "
            , "Description: A subset of LAPACK routines redesigned for heterogenous computing ", "http://www.netlib.org/lapack-dev/ ",
          },
        },
      },
    },
    scalasca = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalasca/.version.2.5"]  = {
          ["Version"] = ".version.2.5",
          ["canonical"] = ".version.2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/scalasca/.version.2.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000002.000000005.*zfinal",
          ["wV"] = "*version.000000002.000000005.*zfinal",
        },
        ["scalasca/2.5"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Toolset for performance analysis of large-scale parallel applications ",
          ["Name"] = "scalasca built with intel compiler and mpich MPI ",
          ["Version"] = "2.5 ",
          ["canonical"] = "2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/scalasca/2.5",
          ["help"] = [[
 
This module loads the scalasca library built with the intel compiler
toolchain and the mpich MPI stack.

Version 2.5


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000002.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/scalasca/2.5/bin"] = 1,
          },
          ["wV"] = "000000002.000000005.*zfinal",
          whatis = {
            "Name: scalasca built with intel compiler and mpich MPI ", "Version: 2.5 "
            , "Category: performance tool "
            , "Description: Toolset for performance analysis of large-scale parallel applications ", "URL http://www.scalasca.org ",
          },
        },
      },
    },
    scorep = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scorep/.version.6.0"]  = {
          ["Version"] = ".version.6.0",
          ["canonical"] = ".version.6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/scorep/.version.6.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000006.*zfinal",
          ["wV"] = "*version.000000006.*zfinal",
        },
        ["scorep/6.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Scalable Performance Measurement Infrastructure for Parallel Codes ",
          ["Name"] = "scorep built with intel compiler and mpich MPI ",
          ["Version"] = "6.0 ",
          ["canonical"] = "6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/scorep/6.0",
          ["help"] = [[
 
This module loads the scorep library built with the intel compiler
toolchain and the mpich MPI stack.

Version 6.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/scorep/6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/scorep/6.0/bin"] = 1,
          },
          ["wV"] = "000000006.*zfinal",
          whatis = {
            "Name: scorep built with intel compiler and mpich MPI ", "Version: 6.0 "
            , "Category: performance tool "
            , "Description: Scalable Performance Measurement Infrastructure for Parallel Codes ", "URL http://www.vi-hps.org/projects/score-p/ ",
          },
        },
      },
    },
    sionlib = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["sionlib/.version.1.7.4"]  = {
          ["Version"] = ".version.1.7.4",
          ["canonical"] = ".version.1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/sionlib/.version.1.7.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000001.000000007.000000004.*zfinal",
          ["wV"] = "*version.000000001.000000007.000000004.*zfinal",
        },
        ["sionlib/1.7.4"]  = {
          ["Category"] = "IO Library ",
          ["Description"] = "Scalable I/O Library for Parallel Access to Task-Local Files ",
          ["Name"] = "sionlib built with intel compiler and mpich MPI ",
          ["Version"] = "1.7.4 ",
          ["canonical"] = "1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/sionlib/1.7.4",
          ["help"] = [[
 
This module loads the sionlib library built with the intel compiler
toolchain and the mpich MPI stack.

Version 1.7.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/sionlib/1.7.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000001.000000007.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/sionlib/1.7.4/bin"] = 1,
          },
          ["wV"] = "000000001.000000007.000000004.*zfinal",
          whatis = {
            "Name: sionlib built with intel compiler and mpich MPI ", "Version: 1.7.4 "
            , "Category: IO Library "
            , "Description: Scalable I/O Library for Parallel Access to Task-Local Files ", "URL http://www.fz-juelich.de/ias/jsc/EN/Expertise/Support/Software/SIONlib/_node.html ",
          },
        },
      },
    },
    slepc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["slepc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A library for solving large scale sparse eigenvalue problems ",
          ["Name"] = "slepc built with intel compiler and mpich MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/slepc/3.12.0",
          ["help"] = [[
 
This module loads the slepc library built with the intel compiler
toolchain and the mpich MPI stack.

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/slepc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000003.000000012.*zfinal",
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: slepc built with intel compiler and mpich MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: A library for solving large scale sparse eigenvalue problems ", "URL http://slepc.upv.es ",
          },
        },
      },
    },
    superlu_dist = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["superlu_dist/.version.6.1.1"]  = {
          ["Version"] = ".version.6.1.1",
          ["canonical"] = ".version.6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/superlu_dist/.version.6.1.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000006.000000001.000000001.*zfinal",
          ["wV"] = "*version.000000006.000000001.000000001.*zfinal",
        },
        ["superlu_dist/6.1.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library for the direct solution of linear equations ",
          ["Name"] = "superlu_dist built with intel compiler and mpich MPI ",
          ["Version"] = "6.1.1 ",
          ["canonical"] = "6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/superlu_dist/6.1.1",
          ["help"] = [[
 
This module loads the SuperLU_dist library built with the intel compiler
toolchain and the mpich MPI stack.
 
Note that this build of SuperLU_dist leverages the metis and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 6.1.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/superlu_dist/6.1.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000006.000000001.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/superlu_dist/6.1.1/bin"] = 1,
          },
          ["wV"] = "000000006.000000001.000000001.*zfinal",
          whatis = {
            "Name: superlu_dist built with intel compiler and mpich MPI ", "Version: 6.1.1 "
            , "Category: runtime library "
            , "Description: A general purpose library for the direct solution of linear equations ", "http://crd-legacy.lbl.gov/~xiaoye/SuperLU/ ",
          },
        },
      },
    },
    tau = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tau/.version.2.28"]  = {
          ["Version"] = ".version.2.28",
          ["canonical"] = ".version.2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/tau/.version.2.28",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000002.000000028.*zfinal",
          ["wV"] = "*version.000000002.000000028.*zfinal",
        },
        ["tau/2.28"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Tuning and Analysis Utilities Profiling Package ",
          ["Name"] = "tau built with intel compiler ",
          ["Version"] = "2.28 ",
          ["canonical"] = "2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/tau/2.28",
          ["help"] = [[
 
This module loads the tau library built with the intel compiler
toolchain and the mpich MPI stack.

Version 2.28


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/tau/2.28/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000002.000000028.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/tau/2.28/bin"] = 1,
          },
          ["wV"] = "000000002.000000028.*zfinal",
          whatis = {
            "Name: tau built with intel compiler ", "Version: 2.28 "
            , "Category: runtime library "
            , "Description: Tuning and Analysis Utilities Profiling Package ", "URL http://www.cs.uoregon.edu/research/tau/home.php ",
          },
        },
      },
    },
    trilinos = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["trilinos/.version.12.14.1"]  = {
          ["Version"] = ".version.12.14.1",
          ["canonical"] = ".version.12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/trilinos/.version.12.14.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "*version.000000012.000000014.000000001.*zfinal",
          ["wV"] = "*version.000000012.000000014.000000001.*zfinal",
        },
        ["trilinos/12.14.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A collection of libraries of numerical algorithms ",
          ["Name"] = "trilinos built with intel compiler and mpich MPI ",
          ["Version"] = "12.14.1 ",
          ["canonical"] = "12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mpich/trilinos/12.14.1",
          ["help"] = [[
 
This module loads the trilinos library built with the intel compiler
toolchain and the mpich MPI stack.

Version 12.14.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/trilinos/12.14.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mpich",
          ["pV"] = "000000012.000000014.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mpich/trilinos/12.14.1/bin"] = 1,
          },
          ["wV"] = "000000012.000000014.000000001.*zfinal",
          whatis = {
            "Name: trilinos built with intel compiler and mpich MPI ", "Version: 12.14.1 "
            , "Category: runtime library "
            , "Description: A collection of libraries of numerical algorithms ", "URL https://trilinos.org/ ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/intel-mvapich2"]  = {
    adios = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["adios/.version.1.13.1"]  = {
          ["Version"] = ".version.1.13.1",
          ["canonical"] = ".version.1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/adios/.version.1.13.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000001.000000013.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000013.000000001.*zfinal",
        },
        ["adios/1.13.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "The Adaptable IO System (ADIOS) ",
          ["Name"] = "ADIOS built with intel compiler and mvapich2 MPI ",
          ["Version"] = "1.13.1 ",
          ["canonical"] = "1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/adios/1.13.1",
          ["help"] = [[
 
This module loads the ADIOS library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 1.13.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/adios/1.13.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000001.000000013.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/adios/1.13.1/bin"] = 1,
          },
          ["wV"] = "000000001.000000013.000000001.*zfinal",
          whatis = {
            "Name: ADIOS built with intel compiler and mvapich2 MPI ", "Version: 1.13.1 "
            , "Category: runtime library ", "Description: The Adaptable IO System (ADIOS) ", "http://www.olcf.ornl.gov/center-projects/adios/ ",
          },
        },
      },
    },
    boost = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["boost/.version.1.71.0"]  = {
          ["Version"] = ".version.1.71.0",
          ["canonical"] = ".version.1.71.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/boost/.version.1.71.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000001.000000071.*zfinal",
          ["wV"] = "*version.000000001.000000071.*zfinal",
        },
        ["boost/1.71.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Boost free peer-reviewed portable C++ source libraries ",
          ["Name"] = "BOOST built with intel compiler and mvapich2 MPI ",
          ["Version"] = "1.71.0 ",
          ["canonical"] = "1.71.0",
          ["family"] = "boost",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/boost/1.71.0",
          ["help"] = [[
 
This module loads the BOOST library built with the intel compiler toolchain
and the mvapich2 MPI stack.

Version 1.71.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/boost/1.71.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000001.000000071.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/boost/1.71.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000071.*zfinal",
          whatis = {
            "Name: BOOST built with intel compiler and mvapich2 MPI ", "Version: 1.71.0 "
            , "Category: runtime library "
            , "Description: Boost free peer-reviewed portable C++ source libraries ", "http://www.boost.org ",
          },
        },
      },
    },
    dimemas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["dimemas/.version.5.4.1"]  = {
          ["Version"] = ".version.5.4.1",
          ["canonical"] = ".version.5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/dimemas/.version.5.4.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000005.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000004.000000001.*zfinal",
        },
        ["dimemas/5.4.1"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Dimemas tool ",
          ["Name"] = "dimemas built with intel compiler and mvapich2 MPI ",
          ["Version"] = "5.4.1 ",
          ["canonical"] = "5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/dimemas/5.4.1",
          ["help"] = [[
 
This module loads the dimemas library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 5.4.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000005.000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/dimemas/5.4.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000004.000000001.*zfinal",
          whatis = {
            "Name: dimemas built with intel compiler and mvapich2 MPI ", "Version: 5.4.1 "
            , "Category: performance tool ", "Description: Dimemas tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    extrae = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["extrae/.version.3.7.0"]  = {
          ["Version"] = ".version.3.7.0",
          ["canonical"] = ".version.3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/extrae/.version.3.7.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000003.000000007.*zfinal",
          ["wV"] = "*version.000000003.000000007.*zfinal",
        },
        ["extrae/3.7.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Extrae tool ",
          ["Name"] = "extrae built with intel compiler and mvapich2 MPI ",
          ["Version"] = "3.7.0 ",
          ["canonical"] = "3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/extrae/3.7.0",
          ["help"] = [[
 
This module loads the extrae library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 3.7.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/extrae/3.7.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/extrae/3.7.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
          whatis = {
            "Name: extrae built with intel compiler and mvapich2 MPI ", "Version: 3.7.0 "
            , "Category: performance tool ", "Description: Extrae tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    hypre = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hypre/.version.2.18.1"]  = {
          ["Version"] = ".version.2.18.1",
          ["canonical"] = ".version.2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/hypre/.version.2.18.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000002.000000018.000000001.*zfinal",
          ["wV"] = "*version.000000002.000000018.000000001.*zfinal",
        },
        ["hypre/2.18.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Scalable algorithms for solving linear systems of equations ",
          ["Name"] = "hypre built with intel compiler and mvapich2 MPI ",
          ["Version"] = "2.18.1 ",
          ["canonical"] = "2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/hypre/2.18.1",
          ["help"] = [[
 
This module loads the hypre library built with the intel compiler
toolchain and the mvapich2 MPI stack.
 
Note that this build of hypre leverages the superlu and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 2.18.1


]],
          lpathA = {
            ["%{MKLROOT}/lib/intel64"] = 1,
            ["/opt/ohpc/pub/libs/intel/mvapich2/hypre/2.18.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000002.000000018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/hypre/2.18.1/bin"] = 1,
          },
          ["wV"] = "000000002.000000018.000000001.*zfinal",
          whatis = {
            "Name: hypre built with intel compiler and mvapich2 MPI ", "Version: 2.18.1 "
            , "Category: runtime library "
            , "Description: Scalable algorithms for solving linear systems of equations ", "http://www.llnl.gov/casc/hypre/ ",
          },
        },
      },
    },
    imb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["imb/.version.2018.1"]  = {
          ["Version"] = ".version.2018.1",
          ["canonical"] = ".version.2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/imb/.version.2018.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000002018.000000001.*zfinal",
          ["wV"] = "*version.000002018.000000001.*zfinal",
        },
        ["imb/2018.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Intel MPI Benchmarks (IMB) ",
          ["Name"] = "imb built with intel compiler and mvapich2 MPI ",
          ["Version"] = "2018.1 ",
          ["canonical"] = "2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/imb/2018.1",
          ["help"] = [[
 
This module loads the imb library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 2018.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000002018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/imb/2018.1/bin"] = 1,
          },
          ["wV"] = "000002018.000000001.*zfinal",
          whatis = {
            "Name: imb built with intel compiler and mvapich2 MPI ", "Version: 2018.1 "
            , "Category: runtime library ", "Description: Intel MPI Benchmarks (IMB) ", "URL https://software.intel.com/en-us/articles/intel-mpi-benchmarks ",
          },
        },
      },
    },
    mfem = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mfem/.version.4.0"]  = {
          ["Version"] = ".version.4.0",
          ["canonical"] = ".version.4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/mfem/.version.4.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000004.*zfinal",
          ["wV"] = "*version.000000004.*zfinal",
        },
        ["mfem/4.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Lightweight, general, scalable C++ library for finite element methods ",
          ["Name"] = "mfem built with intel compiler and mvapich2 MPI ",
          ["Version"] = "4.0 ",
          ["canonical"] = "4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/mfem/4.0",
          ["help"] = [[
 
This module loads the MFEM library built with the intel compiler
toolchain and the mvapich2 MPI stack.
 

Version 4.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/mfem/4.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/mfem/4.0/bin"] = 1,
          },
          ["wV"] = "000000004.*zfinal",
          whatis = {
            "Name: mfem built with intel compiler and mvapich2 MPI ", "Version: 4.0 "
            , "Category: runtime library "
            , "Description: Lightweight, general, scalable C++ library for finite element methods ", "http://mfem.org ",
          },
        },
      },
    },
    mumps = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mumps/.version.5.2.1"]  = {
          ["Version"] = ".version.5.2.1",
          ["canonical"] = ".version.5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/mumps/.version.5.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000005.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000002.000000001.*zfinal",
        },
        ["mumps/5.2.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A MUltifrontal Massively Parallel Sparse direct Solver ",
          ["Name"] = "mumps built with intel compiler and mvapich2 MPI ",
          ["Version"] = "5.2.1 ",
          ["canonical"] = "5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/mumps/5.2.1",
          ["help"] = [[
 
This module loads the mumps library built with the intel compiler
toolchain and the mvapich2 MPI stack.
 

Version 5.2.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/mumps/5.2.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000005.000000002.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/mumps/5.2.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000002.000000001.*zfinal",
          whatis = {
            "Name: mumps built with intel compiler and mvapich2 MPI ", "Version: 5.2.1 "
            , "Category: runtime library "
            , "Description: A MUltifrontal Massively Parallel Sparse direct Solver ", "http://mumps.enseeiht.fr/ ",
          },
        },
      },
    },
    netcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf/.version.4.7.1"]  = {
          ["Version"] = ".version.4.7.1",
          ["canonical"] = ".version.4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/netcdf/.version.4.7.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000004.000000007.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000007.000000001.*zfinal",
        },
        ["netcdf/4.7.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF built with intel toolchain ",
          ["Version"] = "4.7.1 ",
          ["canonical"] = "4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/netcdf/4.7.1",
          ["help"] = [[
 
This module loads the NetCDF C API built with the intel compiler
toolchain and the mvapich2 MPI stack.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5. Consequently, the phdf5 package is loaded automatically with this module.
A typical compilation step for C applications requiring NetCDF is as follows:
 
$CC -I$NETCDF_INC app.c -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.7.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/netcdf/4.7.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000004.000000007.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/netcdf/4.7.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000007.000000001.*zfinal",
          whatis = {
            "Name: NETCDF built with intel toolchain ", "Version: 4.7.1 "
            , "Category: runtime library "
            , "Description: C Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-cxx"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-cxx/.version.4.3.1"]  = {
          ["Version"] = ".version.4.3.1",
          ["canonical"] = ".version.4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/netcdf-cxx/.version.4.3.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000004.000000003.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000003.000000001.*zfinal",
        },
        ["netcdf-cxx/4.3.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C++ Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_CXX built with intel toolchain ",
          ["Version"] = "4.3.1 ",
          ["canonical"] = "4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/netcdf-cxx/4.3.1",
          ["help"] = [[
 
This module loads the NetCDF C++ API built with the intel compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for C++ applications requiring NetCDF is as follows:
 
$CXX -I$NETCDF_CXX_INC app.cpp -L$NETCDF_CXX_LIB -lnetcdf_c++4 -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.3.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/netcdf-cxx/4.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000004.000000003.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/netcdf-cxx/4.3.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000003.000000001.*zfinal",
          whatis = {
            "Name: NETCDF_CXX built with intel toolchain ", "Version: 4.3.1 "
            , "Category: runtime library "
            , "Description: C++ Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-fortran"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-fortran/.version.4.5.2"]  = {
          ["Version"] = ".version.4.5.2",
          ["canonical"] = ".version.4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/netcdf-fortran/.version.4.5.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000004.000000005.000000002.*zfinal",
          ["wV"] = "*version.000000004.000000005.000000002.*zfinal",
        },
        ["netcdf-fortran/4.5.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Fortran Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_FORTRAN built with intel toolchain ",
          ["Version"] = "4.5.2 ",
          ["canonical"] = "4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/netcdf-fortran/4.5.2",
          ["help"] = [[
 
This module loads the NetCDF Fortran API built with the intel compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for Fortran applications requiring NetCDF is as follows:
 

]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/netcdf-fortran/4.5.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000004.000000005.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/netcdf-fortran/4.5.2/bin"] = 1,
          },
          ["wV"] = "000000004.000000005.000000002.*zfinal",
          whatis = {
            "Name: NETCDF_FORTRAN built with intel toolchain ", "Version: 4.5.2 "
            , "Category: runtime library "
            , "Description: Fortran Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    omb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["omb/.version.5.6.2"]  = {
          ["Version"] = ".version.5.6.2",
          ["canonical"] = ".version.5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/omb/.version.5.6.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000005.000000006.000000002.*zfinal",
          ["wV"] = "*version.000000005.000000006.000000002.*zfinal",
        },
        ["omb/5.6.2"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "OSU Micro-benchmarks ",
          ["Name"] = "OSU Micro-benchmarks built with intel compiler and mvapich2 MPI ",
          ["Version"] = "5.6.2 ",
          ["canonical"] = "5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/omb/5.6.2",
          ["help"] = [[
 
This module loads the OSU Micro-benchmarks built with the intel toolchain
and the mvapich2 MPI stack.

Version 5.6.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000005.000000006.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/omb/5.6.2/bin/osu-micro-benchmarks/mpi/collective"] = 1,
            ["/opt/ohpc/pub/libs/intel/mvapich2/omb/5.6.2/bin/osu-micro-benchmarks/mpi/one-sided"] = 1,
            ["/opt/ohpc/pub/libs/intel/mvapich2/omb/5.6.2/bin/osu-micro-benchmarks/mpi/pt2pt"] = 1,
            ["/opt/ohpc/pub/libs/intel/mvapich2/omb/5.6.2/bin/osu-micro-benchmarks/mpi/startup"] = 1,
          },
          ["wV"] = "000000005.000000006.000000002.*zfinal",
          whatis = {
            "Name: OSU Micro-benchmarks built with intel compiler and mvapich2 MPI "
            , "Version: 5.6.2 ", "Category: performance tool "
            , "Description: OSU Micro-benchmarks ", "http://mvapich.cse.ohio-state.edu/benchmarks/ ",
          },
        },
      },
    },
    petsc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["petsc/.version.3.12.0"]  = {
          ["Version"] = ".version.3.12.0",
          ["canonical"] = ".version.3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/petsc/.version.3.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000003.000000012.*zfinal",
          ["wV"] = "*version.000000003.000000012.*zfinal",
        },
        ["petsc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Portable Extensible Toolkit for Scientific Computation ",
          ["Name"] = "petsc built with intel compiler and mvapich2 MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/petsc/3.12.0",
          ["help"] = [[
 
This module loads the PETSc library built with the intel compiler
toolchain and the mvapich2 MPI stack.
 

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/petsc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000003.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/petsc/3.12.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: petsc built with intel compiler and mvapich2 MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: Portable Extensible Toolkit for Scientific Computation ", "http://www.mcs.anl.gov/petsc/ ",
          },
        },
      },
    },
    phdf5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["phdf5/.version.1.10.5"]  = {
          ["Version"] = ".version.1.10.5",
          ["canonical"] = ".version.1.10.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/phdf5/.version.1.10.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000001.000000010.000000005.*zfinal",
          ["wV"] = "*version.000000001.000000010.000000005.*zfinal",
        },
        ["phdf5/1.10.5"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library and file format for storing scientific data ",
          ["Name"] = "hdf5 built with intel compiler and mvapich2 MPI ",
          ["Version"] = "1.10.5 ",
          ["canonical"] = "1.10.5",
          ["family"] = "hdf5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/phdf5/1.10.5",
          ["help"] = [[
 
This module loads the parallel hdf5 library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 1.10.5


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/hdf5/1.10.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000001.000000010.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/hdf5/1.10.5/bin"] = 1,
          },
          ["wV"] = "000000001.000000010.000000005.*zfinal",
          whatis = {
            "Name: hdf5 built with intel compiler and mvapich2 MPI ", "Version: 1.10.5 "
            , "Category: runtime library "
            , "Description: A general purpose library and file format for storing scientific data ", "http://www.hdfgroup.org/HDF5 ",
          },
        },
      },
    },
    pnetcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["pnetcdf/.version.1.12.0"]  = {
          ["Version"] = ".version.1.12.0",
          ["canonical"] = ".version.1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/pnetcdf/.version.1.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000001.000000012.*zfinal",
          ["wV"] = "*version.000000001.000000012.*zfinal",
        },
        ["pnetcdf/1.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A Parallel NetCDF library (PnetCDF) ",
          ["Name"] = "pnetcdf built with intel compiler and mvapich2 MPI ",
          ["Version"] = "1.12.0 ",
          ["canonical"] = "1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/pnetcdf/1.12.0",
          ["help"] = [[
 
This module loads the pnetcdf library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 1.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/pnetcdf/1.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000001.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/pnetcdf/1.12.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000012.*zfinal",
          whatis = {
            "Name: pnetcdf built with intel compiler and mvapich2 MPI ", "Version: 1.12.0 "
            , "Category: runtime library ", "Description: A Parallel NetCDF library (PnetCDF) ", "URL http://cucis.ece.northwestern.edu/projects/PnetCDF ",
          },
        },
      },
    },
    ptscotch = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ptscotch/6.0.6"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Graph, mesh and hypergraph partitioning library using MPI ",
          ["Name"] = "ptscotch built with intel compiler and mvapich2 MPI ",
          ["Version"] = "6.0.6 ",
          ["canonical"] = "6.0.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/ptscotch/6.0.6",
          ["help"] = [[
 
This module loads the Scotch library built with the intel compiler
toolchain and the mvapich2 MPI stack.
 

Version 6.0.6


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/ptscotch/6.0.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000006.000000000.000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/ptscotch/6.0.6/bin"] = 1,
          },
          ["wV"] = "000000006.000000000.000000006.*zfinal",
          whatis = {
            "Name: ptscotch built with intel compiler and mvapich2 MPI ", "Version: 6.0.6 "
            , "Category: runtime library "
            , "Description: Graph, mesh and hypergraph partitioning library using MPI ", "http://www.labri.fr/perso/pelegrin/scotch/ ",
          },
        },
      },
    },
    ["py2-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-mpi4py/.version.3.0.2"]  = {
          ["Version"] = ".version.3.0.2",
          ["canonical"] = ".version.3.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/py2-mpi4py/.version.3.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000003.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000002.*zfinal",
        },
        ["py2-mpi4py/3.0.2"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python-mpi4py built with intel compiler and mvapich2 ",
          ["Version"] = "3.0.2 ",
          ["canonical"] = "3.0.2",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/py2-mpi4py/3.0.2",
          ["help"] = [[
 
This module loads the python-mpi4py library built with the intel compiler
toolchain and the mvapich2 MPI library.

Version 3.0.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000003.000000000.000000002.*zfinal",
          ["wV"] = "000000003.000000000.000000002.*zfinal",
          whatis = {
            "Name: python-mpi4py built with intel compiler and mvapich2 ", "Version: 3.0.2 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    ["py3-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-mpi4py/.version.3.0.1"]  = {
          ["Version"] = ".version.3.0.1",
          ["canonical"] = ".version.3.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/py3-mpi4py/.version.3.0.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000003.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000001.*zfinal",
        },
        ["py3-mpi4py/3.0.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python34-mpi4py built with intel compiler and mvapich2 ",
          ["Version"] = "3.0.1 ",
          ["canonical"] = "3.0.1",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/py3-mpi4py/3.0.1",
          ["help"] = [[
 
This module loads the python34-mpi4py library built with the intel compiler
toolchain and the mvapich2 MPI library.

Version 3.0.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000003.000000000.000000001.*zfinal",
          ["wV"] = "000000003.000000000.000000001.*zfinal",
          whatis = {
            "Name: python34-mpi4py built with intel compiler and mvapich2 "
            , "Version: 3.0.1 ", "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    scalapack = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalapack/.version.2.0.2"]  = {
          ["Version"] = ".version.2.0.2",
          ["canonical"] = ".version.2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/scalapack/.version.2.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000002.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000002.000000000.000000002.*zfinal",
        },
        ["scalapack/2.0.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A subset of LAPACK routines redesigned for heterogenous computing ",
          ["Name"] = "scalapack built with intel compiler and mvapich2 MPI ",
          ["Version"] = "2.0.2 ",
          ["canonical"] = "2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/scalapack/2.0.2",
          ["help"] = [[
 
This module loads the ScaLAPACK library built with the intel compiler
toolchain and the mvapich2 MPI stack.
 

Version 2.0.2


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/scalapack/2.0.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000002.000000000.000000002.*zfinal",
          ["wV"] = "000000002.000000000.000000002.*zfinal",
          whatis = {
            "Name: scalapack built with intel compiler and mvapich2 MPI ", "Version: 2.0.2 "
            , "Category: runtime library "
            , "Description: A subset of LAPACK routines redesigned for heterogenous computing ", "http://www.netlib.org/lapack-dev/ ",
          },
        },
      },
    },
    scalasca = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalasca/.version.2.5"]  = {
          ["Version"] = ".version.2.5",
          ["canonical"] = ".version.2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/scalasca/.version.2.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000002.000000005.*zfinal",
          ["wV"] = "*version.000000002.000000005.*zfinal",
        },
        ["scalasca/2.5"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Toolset for performance analysis of large-scale parallel applications ",
          ["Name"] = "scalasca built with intel compiler and mvapich2 MPI ",
          ["Version"] = "2.5 ",
          ["canonical"] = "2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/scalasca/2.5",
          ["help"] = [[
 
This module loads the scalasca library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 2.5


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000002.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/scalasca/2.5/bin"] = 1,
          },
          ["wV"] = "000000002.000000005.*zfinal",
          whatis = {
            "Name: scalasca built with intel compiler and mvapich2 MPI ", "Version: 2.5 "
            , "Category: performance tool "
            , "Description: Toolset for performance analysis of large-scale parallel applications ", "URL http://www.scalasca.org ",
          },
        },
      },
    },
    scorep = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scorep/.version.6.0"]  = {
          ["Version"] = ".version.6.0",
          ["canonical"] = ".version.6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/scorep/.version.6.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000006.*zfinal",
          ["wV"] = "*version.000000006.*zfinal",
        },
        ["scorep/6.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Scalable Performance Measurement Infrastructure for Parallel Codes ",
          ["Name"] = "scorep built with intel compiler and mvapich2 MPI ",
          ["Version"] = "6.0 ",
          ["canonical"] = "6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/scorep/6.0",
          ["help"] = [[
 
This module loads the scorep library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 6.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/scorep/6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/scorep/6.0/bin"] = 1,
          },
          ["wV"] = "000000006.*zfinal",
          whatis = {
            "Name: scorep built with intel compiler and mvapich2 MPI ", "Version: 6.0 "
            , "Category: performance tool "
            , "Description: Scalable Performance Measurement Infrastructure for Parallel Codes ", "URL http://www.vi-hps.org/projects/score-p/ ",
          },
        },
      },
    },
    sionlib = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["sionlib/.version.1.7.4"]  = {
          ["Version"] = ".version.1.7.4",
          ["canonical"] = ".version.1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/sionlib/.version.1.7.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000001.000000007.000000004.*zfinal",
          ["wV"] = "*version.000000001.000000007.000000004.*zfinal",
        },
        ["sionlib/1.7.4"]  = {
          ["Category"] = "IO Library ",
          ["Description"] = "Scalable I/O Library for Parallel Access to Task-Local Files ",
          ["Name"] = "sionlib built with intel compiler and mvapich2 MPI ",
          ["Version"] = "1.7.4 ",
          ["canonical"] = "1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/sionlib/1.7.4",
          ["help"] = [[
 
This module loads the sionlib library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 1.7.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/sionlib/1.7.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000001.000000007.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/sionlib/1.7.4/bin"] = 1,
          },
          ["wV"] = "000000001.000000007.000000004.*zfinal",
          whatis = {
            "Name: sionlib built with intel compiler and mvapich2 MPI ", "Version: 1.7.4 "
            , "Category: IO Library "
            , "Description: Scalable I/O Library for Parallel Access to Task-Local Files ", "URL http://www.fz-juelich.de/ias/jsc/EN/Expertise/Support/Software/SIONlib/_node.html ",
          },
        },
      },
    },
    slepc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["slepc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A library for solving large scale sparse eigenvalue problems ",
          ["Name"] = "slepc built with intel compiler and mvapich2 MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/slepc/3.12.0",
          ["help"] = [[
 
This module loads the slepc library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/slepc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000003.000000012.*zfinal",
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: slepc built with intel compiler and mvapich2 MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: A library for solving large scale sparse eigenvalue problems ", "URL http://slepc.upv.es ",
          },
        },
      },
    },
    superlu_dist = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["superlu_dist/.version.6.1.1"]  = {
          ["Version"] = ".version.6.1.1",
          ["canonical"] = ".version.6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/superlu_dist/.version.6.1.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000006.000000001.000000001.*zfinal",
          ["wV"] = "*version.000000006.000000001.000000001.*zfinal",
        },
        ["superlu_dist/6.1.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library for the direct solution of linear equations ",
          ["Name"] = "superlu_dist built with intel compiler and mvapich2 MPI ",
          ["Version"] = "6.1.1 ",
          ["canonical"] = "6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/superlu_dist/6.1.1",
          ["help"] = [[
 
This module loads the SuperLU_dist library built with the intel compiler
toolchain and the mvapich2 MPI stack.
 
Note that this build of SuperLU_dist leverages the metis and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 6.1.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/superlu_dist/6.1.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000006.000000001.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/superlu_dist/6.1.1/bin"] = 1,
          },
          ["wV"] = "000000006.000000001.000000001.*zfinal",
          whatis = {
            "Name: superlu_dist built with intel compiler and mvapich2 MPI "
            , "Version: 6.1.1 ", "Category: runtime library "
            , "Description: A general purpose library for the direct solution of linear equations ", "http://crd-legacy.lbl.gov/~xiaoye/SuperLU/ ",
          },
        },
      },
    },
    tau = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tau/.version.2.28"]  = {
          ["Version"] = ".version.2.28",
          ["canonical"] = ".version.2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/tau/.version.2.28",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000002.000000028.*zfinal",
          ["wV"] = "*version.000000002.000000028.*zfinal",
        },
        ["tau/2.28"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Tuning and Analysis Utilities Profiling Package ",
          ["Name"] = "tau built with intel compiler ",
          ["Version"] = "2.28 ",
          ["canonical"] = "2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/tau/2.28",
          ["help"] = [[
 
This module loads the tau library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 2.28


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/tau/2.28/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000002.000000028.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/tau/2.28/bin"] = 1,
          },
          ["wV"] = "000000002.000000028.*zfinal",
          whatis = {
            "Name: tau built with intel compiler ", "Version: 2.28 "
            , "Category: runtime library "
            , "Description: Tuning and Analysis Utilities Profiling Package ", "URL http://www.cs.uoregon.edu/research/tau/home.php ",
          },
        },
      },
    },
    trilinos = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["trilinos/.version.12.14.1"]  = {
          ["Version"] = ".version.12.14.1",
          ["canonical"] = ".version.12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/trilinos/.version.12.14.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "*version.000000012.000000014.000000001.*zfinal",
          ["wV"] = "*version.000000012.000000014.000000001.*zfinal",
        },
        ["trilinos/12.14.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A collection of libraries of numerical algorithms ",
          ["Name"] = "trilinos built with intel compiler and mvapich2 MPI ",
          ["Version"] = "12.14.1 ",
          ["canonical"] = "12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2/trilinos/12.14.1",
          ["help"] = [[
 
This module loads the trilinos library built with the intel compiler
toolchain and the mvapich2 MPI stack.

Version 12.14.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/trilinos/12.14.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-mvapich2",
          ["pV"] = "000000012.000000014.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/mvapich2/trilinos/12.14.1/bin"] = 1,
          },
          ["wV"] = "000000012.000000014.000000001.*zfinal",
          whatis = {
            "Name: trilinos built with intel compiler and mvapich2 MPI ", "Version: 12.14.1 "
            , "Category: runtime library "
            , "Description: A collection of libraries of numerical algorithms ", "URL https://trilinos.org/ ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/moduledeps/intel-openmpi3"]  = {
    adios = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["adios/.version.1.13.1"]  = {
          ["Version"] = ".version.1.13.1",
          ["canonical"] = ".version.1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/adios/.version.1.13.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000001.000000013.000000001.*zfinal",
          ["wV"] = "*version.000000001.000000013.000000001.*zfinal",
        },
        ["adios/1.13.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "The Adaptable IO System (ADIOS) ",
          ["Name"] = "ADIOS built with intel compiler and openmpi3 MPI ",
          ["Version"] = "1.13.1 ",
          ["canonical"] = "1.13.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/adios/1.13.1",
          ["help"] = [[
 
This module loads the ADIOS library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 1.13.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/adios/1.13.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000001.000000013.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/adios/1.13.1/bin"] = 1,
          },
          ["wV"] = "000000001.000000013.000000001.*zfinal",
          whatis = {
            "Name: ADIOS built with intel compiler and openmpi3 MPI ", "Version: 1.13.1 "
            , "Category: runtime library ", "Description: The Adaptable IO System (ADIOS) ", "http://www.olcf.ornl.gov/center-projects/adios/ ",
          },
        },
      },
    },
    boost = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["boost/.version.1.71.0"]  = {
          ["Version"] = ".version.1.71.0",
          ["canonical"] = ".version.1.71.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/boost/.version.1.71.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000001.000000071.*zfinal",
          ["wV"] = "*version.000000001.000000071.*zfinal",
        },
        ["boost/1.71.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Boost free peer-reviewed portable C++ source libraries ",
          ["Name"] = "BOOST built with intel compiler and openmpi3 MPI ",
          ["Version"] = "1.71.0 ",
          ["canonical"] = "1.71.0",
          ["family"] = "boost",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/boost/1.71.0",
          ["help"] = [[
 
This module loads the BOOST library built with the intel compiler toolchain
and the openmpi3 MPI stack.

Version 1.71.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/boost/1.71.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000001.000000071.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/boost/1.71.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000071.*zfinal",
          whatis = {
            "Name: BOOST built with intel compiler and openmpi3 MPI ", "Version: 1.71.0 "
            , "Category: runtime library "
            , "Description: Boost free peer-reviewed portable C++ source libraries ", "http://www.boost.org ",
          },
        },
      },
    },
    dimemas = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["dimemas/.version.5.4.1"]  = {
          ["Version"] = ".version.5.4.1",
          ["canonical"] = ".version.5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/dimemas/.version.5.4.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000005.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000004.000000001.*zfinal",
        },
        ["dimemas/5.4.1"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Dimemas tool ",
          ["Name"] = "dimemas built with intel compiler and openmpi3 MPI ",
          ["Version"] = "5.4.1 ",
          ["canonical"] = "5.4.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/dimemas/5.4.1",
          ["help"] = [[
 
This module loads the dimemas library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 5.4.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000005.000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/dimemas/5.4.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000004.000000001.*zfinal",
          whatis = {
            "Name: dimemas built with intel compiler and openmpi3 MPI ", "Version: 5.4.1 "
            , "Category: performance tool ", "Description: Dimemas tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    extrae = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["extrae/.version.3.7.0"]  = {
          ["Version"] = ".version.3.7.0",
          ["canonical"] = ".version.3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/extrae/.version.3.7.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000003.000000007.*zfinal",
          ["wV"] = "*version.000000003.000000007.*zfinal",
        },
        ["extrae/3.7.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Extrae tool ",
          ["Name"] = "extrae built with intel compiler and openmpi3 MPI ",
          ["Version"] = "3.7.0 ",
          ["canonical"] = "3.7.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/extrae/3.7.0",
          ["help"] = [[
 
This module loads the extrae library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 3.7.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/extrae/3.7.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/extrae/3.7.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
          whatis = {
            "Name: extrae built with intel compiler and openmpi3 MPI ", "Version: 3.7.0 "
            , "Category: performance tool ", "Description: Extrae tool ", "URL https://tools.bsc.es ",
          },
        },
      },
    },
    hypre = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hypre/.version.2.18.1"]  = {
          ["Version"] = ".version.2.18.1",
          ["canonical"] = ".version.2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/hypre/.version.2.18.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000002.000000018.000000001.*zfinal",
          ["wV"] = "*version.000000002.000000018.000000001.*zfinal",
        },
        ["hypre/2.18.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Scalable algorithms for solving linear systems of equations ",
          ["Name"] = "hypre built with intel compiler and openmpi3 MPI ",
          ["Version"] = "2.18.1 ",
          ["canonical"] = "2.18.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/hypre/2.18.1",
          ["help"] = [[
 
This module loads the hypre library built with the intel compiler
toolchain and the openmpi3 MPI stack.
 
Note that this build of hypre leverages the superlu and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 2.18.1


]],
          lpathA = {
            ["%{MKLROOT}/lib/intel64"] = 1,
            ["/opt/ohpc/pub/libs/intel/openmpi3/hypre/2.18.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000002.000000018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/hypre/2.18.1/bin"] = 1,
          },
          ["wV"] = "000000002.000000018.000000001.*zfinal",
          whatis = {
            "Name: hypre built with intel compiler and openmpi3 MPI ", "Version: 2.18.1 "
            , "Category: runtime library "
            , "Description: Scalable algorithms for solving linear systems of equations ", "http://www.llnl.gov/casc/hypre/ ",
          },
        },
      },
    },
    imb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["imb/.version.2018.1"]  = {
          ["Version"] = ".version.2018.1",
          ["canonical"] = ".version.2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/imb/.version.2018.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000002018.000000001.*zfinal",
          ["wV"] = "*version.000002018.000000001.*zfinal",
        },
        ["imb/2018.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Intel MPI Benchmarks (IMB) ",
          ["Name"] = "imb built with intel compiler and openmpi3 MPI ",
          ["Version"] = "2018.1 ",
          ["canonical"] = "2018.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/imb/2018.1",
          ["help"] = [[
 
This module loads the imb library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 2018.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000002018.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/imb/2018.1/bin"] = 1,
          },
          ["wV"] = "000002018.000000001.*zfinal",
          whatis = {
            "Name: imb built with intel compiler and openmpi3 MPI ", "Version: 2018.1 "
            , "Category: runtime library ", "Description: Intel MPI Benchmarks (IMB) ", "URL https://software.intel.com/en-us/articles/intel-mpi-benchmarks ",
          },
        },
      },
    },
    mfem = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mfem/.version.4.0"]  = {
          ["Version"] = ".version.4.0",
          ["canonical"] = ".version.4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/mfem/.version.4.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000004.*zfinal",
          ["wV"] = "*version.000000004.*zfinal",
        },
        ["mfem/4.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Lightweight, general, scalable C++ library for finite element methods ",
          ["Name"] = "mfem built with intel compiler and openmpi3 MPI ",
          ["Version"] = "4.0 ",
          ["canonical"] = "4.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/mfem/4.0",
          ["help"] = [[
 
This module loads the MFEM library built with the intel compiler
toolchain and the openmpi3 MPI stack.
 

Version 4.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/mfem/4.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/mfem/4.0/bin"] = 1,
          },
          ["wV"] = "000000004.*zfinal",
          whatis = {
            "Name: mfem built with intel compiler and openmpi3 MPI ", "Version: 4.0 "
            , "Category: runtime library "
            , "Description: Lightweight, general, scalable C++ library for finite element methods ", "http://mfem.org ",
          },
        },
      },
    },
    mumps = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["mumps/.version.5.2.1"]  = {
          ["Version"] = ".version.5.2.1",
          ["canonical"] = ".version.5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/mumps/.version.5.2.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000005.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000002.000000001.*zfinal",
        },
        ["mumps/5.2.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A MUltifrontal Massively Parallel Sparse direct Solver ",
          ["Name"] = "mumps built with intel compiler and openmpi3 MPI ",
          ["Version"] = "5.2.1 ",
          ["canonical"] = "5.2.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/mumps/5.2.1",
          ["help"] = [[
 
This module loads the mumps library built with the intel compiler
toolchain and the openmpi3 MPI stack.
 

Version 5.2.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/mumps/5.2.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000005.000000002.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/mumps/5.2.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000002.000000001.*zfinal",
          whatis = {
            "Name: mumps built with intel compiler and openmpi3 MPI ", "Version: 5.2.1 "
            , "Category: runtime library "
            , "Description: A MUltifrontal Massively Parallel Sparse direct Solver ", "http://mumps.enseeiht.fr/ ",
          },
        },
      },
    },
    netcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf/.version.4.7.1"]  = {
          ["Version"] = ".version.4.7.1",
          ["canonical"] = ".version.4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/netcdf/.version.4.7.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000004.000000007.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000007.000000001.*zfinal",
        },
        ["netcdf/4.7.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF built with intel toolchain ",
          ["Version"] = "4.7.1 ",
          ["canonical"] = "4.7.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/netcdf/4.7.1",
          ["help"] = [[
 
This module loads the NetCDF C API built with the intel compiler
toolchain and the openmpi3 MPI stack.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5. Consequently, the phdf5 package is loaded automatically with this module.
A typical compilation step for C applications requiring NetCDF is as follows:
 
$CC -I$NETCDF_INC app.c -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.7.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/netcdf/4.7.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000004.000000007.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/netcdf/4.7.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000007.000000001.*zfinal",
          whatis = {
            "Name: NETCDF built with intel toolchain ", "Version: 4.7.1 "
            , "Category: runtime library "
            , "Description: C Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-cxx"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-cxx/.version.4.3.1"]  = {
          ["Version"] = ".version.4.3.1",
          ["canonical"] = ".version.4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/netcdf-cxx/.version.4.3.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000004.000000003.000000001.*zfinal",
          ["wV"] = "*version.000000004.000000003.000000001.*zfinal",
        },
        ["netcdf-cxx/4.3.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "C++ Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_CXX built with intel toolchain ",
          ["Version"] = "4.3.1 ",
          ["canonical"] = "4.3.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/netcdf-cxx/4.3.1",
          ["help"] = [[
 
This module loads the NetCDF C++ API built with the intel compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for C++ applications requiring NetCDF is as follows:
 
$CXX -I$NETCDF_CXX_INC app.cpp -L$NETCDF_CXX_LIB -lnetcdf_c++4 -L$NETCDF_LIB -lnetcdf -L$HDF5_LIB -lhdf5

Version 4.3.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/netcdf-cxx/4.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000004.000000003.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/netcdf-cxx/4.3.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000003.000000001.*zfinal",
          whatis = {
            "Name: NETCDF_CXX built with intel toolchain ", "Version: 4.3.1 "
            , "Category: runtime library "
            , "Description: C++ Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    ["netcdf-fortran"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["netcdf-fortran/.version.4.5.2"]  = {
          ["Version"] = ".version.4.5.2",
          ["canonical"] = ".version.4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/netcdf-fortran/.version.4.5.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000004.000000005.000000002.*zfinal",
          ["wV"] = "*version.000000004.000000005.000000002.*zfinal",
        },
        ["netcdf-fortran/4.5.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Fortran Libraries for the Unidata network Common Data Form ",
          ["Name"] = "NETCDF_FORTRAN built with intel toolchain ",
          ["Version"] = "4.5.2 ",
          ["canonical"] = "4.5.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/netcdf-fortran/4.5.2",
          ["help"] = [[
 
This module loads the NetCDF Fortran API built with the intel compiler toolchain.
 
Note that this build of NetCDF leverages the HDF I/O library and requires linkage
against hdf5 and the native C NetCDF library. Consequently, phdf5 and the standard C
version of NetCDF are loaded automatically via this module. A typical compilation
example for Fortran applications requiring NetCDF is as follows:
 

]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/netcdf-fortran/4.5.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000004.000000005.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/netcdf-fortran/4.5.2/bin"] = 1,
          },
          ["wV"] = "000000004.000000005.000000002.*zfinal",
          whatis = {
            "Name: NETCDF_FORTRAN built with intel toolchain ", "Version: 4.5.2 "
            , "Category: runtime library "
            , "Description: Fortran Libraries for the Unidata network Common Data Form ", "http://www.unidata.ucar.edu/software/netcdf/ ",
          },
        },
      },
    },
    omb = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["omb/.version.5.6.2"]  = {
          ["Version"] = ".version.5.6.2",
          ["canonical"] = ".version.5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/omb/.version.5.6.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000005.000000006.000000002.*zfinal",
          ["wV"] = "*version.000000005.000000006.000000002.*zfinal",
        },
        ["omb/5.6.2"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "OSU Micro-benchmarks ",
          ["Name"] = "OSU Micro-benchmarks built with intel compiler and openmpi3 MPI ",
          ["Version"] = "5.6.2 ",
          ["canonical"] = "5.6.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/omb/5.6.2",
          ["help"] = [[
 
This module loads the OSU Micro-benchmarks built with the intel toolchain
and the openmpi3 MPI stack.

Version 5.6.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000005.000000006.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/omb/5.6.2/bin/osu-micro-benchmarks/mpi/collective"] = 1,
            ["/opt/ohpc/pub/libs/intel/openmpi3/omb/5.6.2/bin/osu-micro-benchmarks/mpi/one-sided"] = 1,
            ["/opt/ohpc/pub/libs/intel/openmpi3/omb/5.6.2/bin/osu-micro-benchmarks/mpi/pt2pt"] = 1,
            ["/opt/ohpc/pub/libs/intel/openmpi3/omb/5.6.2/bin/osu-micro-benchmarks/mpi/startup"] = 1,
          },
          ["wV"] = "000000005.000000006.000000002.*zfinal",
          whatis = {
            "Name: OSU Micro-benchmarks built with intel compiler and openmpi3 MPI "
            , "Version: 5.6.2 ", "Category: performance tool "
            , "Description: OSU Micro-benchmarks ", "http://mvapich.cse.ohio-state.edu/benchmarks/ ",
          },
        },
      },
    },
    petsc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["petsc/.version.3.12.0"]  = {
          ["Version"] = ".version.3.12.0",
          ["canonical"] = ".version.3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/petsc/.version.3.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000003.000000012.*zfinal",
          ["wV"] = "*version.000000003.000000012.*zfinal",
        },
        ["petsc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Portable Extensible Toolkit for Scientific Computation ",
          ["Name"] = "petsc built with intel compiler and openmpi3 MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/petsc/3.12.0",
          ["help"] = [[
 
This module loads the PETSc library built with the intel compiler
toolchain and the openmpi3 MPI stack.
 

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/petsc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000003.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/petsc/3.12.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: petsc built with intel compiler and openmpi3 MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: Portable Extensible Toolkit for Scientific Computation ", "http://www.mcs.anl.gov/petsc/ ",
          },
        },
      },
    },
    phdf5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["phdf5/.version.1.10.5"]  = {
          ["Version"] = ".version.1.10.5",
          ["canonical"] = ".version.1.10.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/phdf5/.version.1.10.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000001.000000010.000000005.*zfinal",
          ["wV"] = "*version.000000001.000000010.000000005.*zfinal",
        },
        ["phdf5/1.10.5"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library and file format for storing scientific data ",
          ["Name"] = "hdf5 built with intel compiler and openmpi3 MPI ",
          ["Version"] = "1.10.5 ",
          ["canonical"] = "1.10.5",
          ["family"] = "hdf5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/phdf5/1.10.5",
          ["help"] = [[
 
This module loads the parallel hdf5 library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 1.10.5


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/hdf5/1.10.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000001.000000010.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/hdf5/1.10.5/bin"] = 1,
          },
          ["wV"] = "000000001.000000010.000000005.*zfinal",
          whatis = {
            "Name: hdf5 built with intel compiler and openmpi3 MPI ", "Version: 1.10.5 "
            , "Category: runtime library "
            , "Description: A general purpose library and file format for storing scientific data ", "http://www.hdfgroup.org/HDF5 ",
          },
        },
      },
    },
    pnetcdf = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["pnetcdf/.version.1.12.0"]  = {
          ["Version"] = ".version.1.12.0",
          ["canonical"] = ".version.1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/pnetcdf/.version.1.12.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000001.000000012.*zfinal",
          ["wV"] = "*version.000000001.000000012.*zfinal",
        },
        ["pnetcdf/1.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A Parallel NetCDF library (PnetCDF) ",
          ["Name"] = "pnetcdf built with intel compiler and openmpi3 MPI ",
          ["Version"] = "1.12.0 ",
          ["canonical"] = "1.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/pnetcdf/1.12.0",
          ["help"] = [[
 
This module loads the pnetcdf library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 1.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/pnetcdf/1.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000001.000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/pnetcdf/1.12.0/bin"] = 1,
          },
          ["wV"] = "000000001.000000012.*zfinal",
          whatis = {
            "Name: pnetcdf built with intel compiler and openmpi3 MPI ", "Version: 1.12.0 "
            , "Category: runtime library ", "Description: A Parallel NetCDF library (PnetCDF) ", "URL http://cucis.ece.northwestern.edu/projects/PnetCDF ",
          },
        },
      },
    },
    ptscotch = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["ptscotch/6.0.6"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Graph, mesh and hypergraph partitioning library using MPI ",
          ["Name"] = "ptscotch built with intel compiler and openmpi3 MPI ",
          ["Version"] = "6.0.6 ",
          ["canonical"] = "6.0.6",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/ptscotch/6.0.6",
          ["help"] = [[
 
This module loads the Scotch library built with the intel compiler
toolchain and the openmpi3 MPI stack.
 

Version 6.0.6


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/ptscotch/6.0.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000006.000000000.000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/ptscotch/6.0.6/bin"] = 1,
          },
          ["wV"] = "000000006.000000000.000000006.*zfinal",
          whatis = {
            "Name: ptscotch built with intel compiler and openmpi3 MPI ", "Version: 6.0.6 "
            , "Category: runtime library "
            , "Description: Graph, mesh and hypergraph partitioning library using MPI ", "http://www.labri.fr/perso/pelegrin/scotch/ ",
          },
        },
      },
    },
    ["py2-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py2-mpi4py/.version.3.0.2"]  = {
          ["Version"] = ".version.3.0.2",
          ["canonical"] = ".version.3.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/py2-mpi4py/.version.3.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000003.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000002.*zfinal",
        },
        ["py2-mpi4py/3.0.2"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python-mpi4py built with intel compiler and openmpi3 ",
          ["Version"] = "3.0.2 ",
          ["canonical"] = "3.0.2",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/py2-mpi4py/3.0.2",
          ["help"] = [[
 
This module loads the python-mpi4py library built with the intel compiler
toolchain and the openmpi3 MPI library.

Version 3.0.2


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000003.000000000.000000002.*zfinal",
          ["wV"] = "000000003.000000000.000000002.*zfinal",
          whatis = {
            "Name: python-mpi4py built with intel compiler and openmpi3 ", "Version: 3.0.2 "
            , "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    ["py3-mpi4py"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["py3-mpi4py/.version.3.0.1"]  = {
          ["Version"] = ".version.3.0.1",
          ["canonical"] = ".version.3.0.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/py3-mpi4py/.version.3.0.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000003.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000000.000000001.*zfinal",
        },
        ["py3-mpi4py/3.0.1"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Python bindings for the Message Passing Interface (MPI) standard. ",
          ["Name"] = "python34-mpi4py built with intel compiler and openmpi3 ",
          ["Version"] = "3.0.1 ",
          ["canonical"] = "3.0.1",
          ["family"] = "mpi4py",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/py3-mpi4py/3.0.1",
          ["help"] = [[
 
This module loads the python34-mpi4py library built with the intel compiler
toolchain and the openmpi3 MPI library.

Version 3.0.1


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000003.000000000.000000001.*zfinal",
          ["wV"] = "000000003.000000000.000000001.*zfinal",
          whatis = {
            "Name: python34-mpi4py built with intel compiler and openmpi3 "
            , "Version: 3.0.1 ", "Category: python module "
            , "Description: Python bindings for the Message Passing Interface (MPI) standard. ", "URL https://bitbucket.org/mpi4py/mpi4py ",
          },
        },
      },
    },
    scalapack = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalapack/.version.2.0.2"]  = {
          ["Version"] = ".version.2.0.2",
          ["canonical"] = ".version.2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/scalapack/.version.2.0.2",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000002.000000000.000000002.*zfinal",
          ["wV"] = "*version.000000002.000000000.000000002.*zfinal",
        },
        ["scalapack/2.0.2"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A subset of LAPACK routines redesigned for heterogenous computing ",
          ["Name"] = "scalapack built with intel compiler and openmpi3 MPI ",
          ["Version"] = "2.0.2 ",
          ["canonical"] = "2.0.2",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/scalapack/2.0.2",
          ["help"] = [[
 
This module loads the ScaLAPACK library built with the intel compiler
toolchain and the openmpi3 MPI stack.
 

Version 2.0.2


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/scalapack/2.0.2/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000002.000000000.000000002.*zfinal",
          ["wV"] = "000000002.000000000.000000002.*zfinal",
          whatis = {
            "Name: scalapack built with intel compiler and openmpi3 MPI ", "Version: 2.0.2 "
            , "Category: runtime library "
            , "Description: A subset of LAPACK routines redesigned for heterogenous computing ", "http://www.netlib.org/lapack-dev/ ",
          },
        },
      },
    },
    scalasca = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scalasca/.version.2.5"]  = {
          ["Version"] = ".version.2.5",
          ["canonical"] = ".version.2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/scalasca/.version.2.5",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000002.000000005.*zfinal",
          ["wV"] = "*version.000000002.000000005.*zfinal",
        },
        ["scalasca/2.5"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Toolset for performance analysis of large-scale parallel applications ",
          ["Name"] = "scalasca built with intel compiler and openmpi3 MPI ",
          ["Version"] = "2.5 ",
          ["canonical"] = "2.5",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/scalasca/2.5",
          ["help"] = [[
 
This module loads the scalasca library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 2.5


]],
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000002.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/scalasca/2.5/bin"] = 1,
          },
          ["wV"] = "000000002.000000005.*zfinal",
          whatis = {
            "Name: scalasca built with intel compiler and openmpi3 MPI ", "Version: 2.5 "
            , "Category: performance tool "
            , "Description: Toolset for performance analysis of large-scale parallel applications ", "URL http://www.scalasca.org ",
          },
        },
      },
    },
    scorep = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["scorep/.version.6.0"]  = {
          ["Version"] = ".version.6.0",
          ["canonical"] = ".version.6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/scorep/.version.6.0",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000006.*zfinal",
          ["wV"] = "*version.000000006.*zfinal",
        },
        ["scorep/6.0"]  = {
          ["Category"] = "performance tool ",
          ["Description"] = "Scalable Performance Measurement Infrastructure for Parallel Codes ",
          ["Name"] = "scorep built with intel compiler and openmpi3 MPI ",
          ["Version"] = "6.0 ",
          ["canonical"] = "6.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/scorep/6.0",
          ["help"] = [[
 
This module loads the scorep library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 6.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/scorep/6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000006.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/scorep/6.0/bin"] = 1,
          },
          ["wV"] = "000000006.*zfinal",
          whatis = {
            "Name: scorep built with intel compiler and openmpi3 MPI ", "Version: 6.0 "
            , "Category: performance tool "
            , "Description: Scalable Performance Measurement Infrastructure for Parallel Codes ", "URL http://www.vi-hps.org/projects/score-p/ ",
          },
        },
      },
    },
    sionlib = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["sionlib/.version.1.7.4"]  = {
          ["Version"] = ".version.1.7.4",
          ["canonical"] = ".version.1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/sionlib/.version.1.7.4",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000001.000000007.000000004.*zfinal",
          ["wV"] = "*version.000000001.000000007.000000004.*zfinal",
        },
        ["sionlib/1.7.4"]  = {
          ["Category"] = "IO Library ",
          ["Description"] = "Scalable I/O Library for Parallel Access to Task-Local Files ",
          ["Name"] = "sionlib built with intel compiler and openmpi3 MPI ",
          ["Version"] = "1.7.4 ",
          ["canonical"] = "1.7.4",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/sionlib/1.7.4",
          ["help"] = [[
 
This module loads the sionlib library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 1.7.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/sionlib/1.7.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000001.000000007.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/sionlib/1.7.4/bin"] = 1,
          },
          ["wV"] = "000000001.000000007.000000004.*zfinal",
          whatis = {
            "Name: sionlib built with intel compiler and openmpi3 MPI ", "Version: 1.7.4 "
            , "Category: IO Library "
            , "Description: Scalable I/O Library for Parallel Access to Task-Local Files ", "URL http://www.fz-juelich.de/ias/jsc/EN/Expertise/Support/Software/SIONlib/_node.html ",
          },
        },
      },
    },
    slepc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["slepc/3.12.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A library for solving large scale sparse eigenvalue problems ",
          ["Name"] = "slepc built with intel compiler and openmpi3 MPI ",
          ["Version"] = "3.12.0 ",
          ["canonical"] = "3.12.0",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/slepc/3.12.0",
          ["help"] = [[
 
This module loads the slepc library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 3.12.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/slepc/3.12.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000003.000000012.*zfinal",
          ["wV"] = "000000003.000000012.*zfinal",
          whatis = {
            "Name: slepc built with intel compiler and openmpi3 MPI ", "Version: 3.12.0 "
            , "Category: runtime library "
            , "Description: A library for solving large scale sparse eigenvalue problems ", "URL http://slepc.upv.es ",
          },
        },
      },
    },
    superlu_dist = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["superlu_dist/.version.6.1.1"]  = {
          ["Version"] = ".version.6.1.1",
          ["canonical"] = ".version.6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/superlu_dist/.version.6.1.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000006.000000001.000000001.*zfinal",
          ["wV"] = "*version.000000006.000000001.000000001.*zfinal",
        },
        ["superlu_dist/6.1.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A general purpose library for the direct solution of linear equations ",
          ["Name"] = "superlu_dist built with intel compiler and openmpi3 MPI ",
          ["Version"] = "6.1.1 ",
          ["canonical"] = "6.1.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/superlu_dist/6.1.1",
          ["help"] = [[
 
This module loads the SuperLU_dist library built with the intel compiler
toolchain and the openmpi3 MPI stack.
 
Note that this build of SuperLU_dist leverages the metis and MKL libraries.
Consequently, these packages are loaded automatically with this module.

Version 6.1.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/superlu_dist/6.1.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000006.000000001.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/superlu_dist/6.1.1/bin"] = 1,
          },
          ["wV"] = "000000006.000000001.000000001.*zfinal",
          whatis = {
            "Name: superlu_dist built with intel compiler and openmpi3 MPI "
            , "Version: 6.1.1 ", "Category: runtime library "
            , "Description: A general purpose library for the direct solution of linear equations ", "http://crd-legacy.lbl.gov/~xiaoye/SuperLU/ ",
          },
        },
      },
    },
    tau = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["tau/.version.2.28"]  = {
          ["Version"] = ".version.2.28",
          ["canonical"] = ".version.2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/tau/.version.2.28",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000002.000000028.*zfinal",
          ["wV"] = "*version.000000002.000000028.*zfinal",
        },
        ["tau/2.28"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Tuning and Analysis Utilities Profiling Package ",
          ["Name"] = "tau built with intel compiler ",
          ["Version"] = "2.28 ",
          ["canonical"] = "2.28",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/tau/2.28",
          ["help"] = [[
 
This module loads the tau library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 2.28


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/tau/2.28/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000002.000000028.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/tau/2.28/bin"] = 1,
          },
          ["wV"] = "000000002.000000028.*zfinal",
          whatis = {
            "Name: tau built with intel compiler ", "Version: 2.28 "
            , "Category: runtime library "
            , "Description: Tuning and Analysis Utilities Profiling Package ", "URL http://www.cs.uoregon.edu/research/tau/home.php ",
          },
        },
      },
    },
    trilinos = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["trilinos/.version.12.14.1"]  = {
          ["Version"] = ".version.12.14.1",
          ["canonical"] = ".version.12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/trilinos/.version.12.14.1",
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "*version.000000012.000000014.000000001.*zfinal",
          ["wV"] = "*version.000000012.000000014.000000001.*zfinal",
        },
        ["trilinos/12.14.1"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "A collection of libraries of numerical algorithms ",
          ["Name"] = "trilinos built with intel compiler and openmpi3 MPI ",
          ["Version"] = "12.14.1 ",
          ["canonical"] = "12.14.1",
          ["fn"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3/trilinos/12.14.1",
          ["help"] = [[
 
This module loads the trilinos library built with the intel compiler
toolchain and the openmpi3 MPI stack.

Version 12.14.1


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/trilinos/12.14.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/moduledeps/intel-openmpi3",
          ["pV"] = "000000012.000000014.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/intel/openmpi3/trilinos/12.14.1/bin"] = 1,
          },
          ["wV"] = "000000012.000000014.000000001.*zfinal",
          whatis = {
            "Name: trilinos built with intel compiler and openmpi3 MPI ", "Version: 12.14.1 "
            , "Category: runtime library "
            , "Description: A collection of libraries of numerical algorithms ", "URL https://trilinos.org/ ",
          },
        },
      },
    },
  },
  ["/opt/ohpc/pub/modulefiles"]  = {
    EasyBuild = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["EasyBuild/.version.3.9.4"]  = {
          ["Version"] = ".version.3.9.4",
          ["canonical"] = ".version.3.9.4",
          ["fn"] = "/opt/ohpc/pub/modulefiles/EasyBuild/.version.3.9.4",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000003.000000009.000000004.*zfinal",
          ["wV"] = "*version.000000003.000000009.000000004.*zfinal",
        },
        ["EasyBuild/3.9.4"]  = {
          ["Category"] = "system tool ",
          ["Description"] = "Build and installation framework ",
          ["Name"] = "easybuild ",
          ["URL"] = "http://easybuilders.github.io/easybuild/ ",
          ["Version"] = "3.9.4 ",
          ["canonical"] = "3.9.4",
          ["fn"] = "/opt/ohpc/pub/modulefiles/EasyBuild/3.9.4",
          ["help"] = [[
 
This module loads easybuild

Version 3.9.4


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/easybuild/3.9.4/software/EasyBuild/3.9.4/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000009.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/admin/lmod/lmod/libexec"] = 1,
            ["/opt/ohpc/pub/libs/easybuild/3.9.4/software/EasyBuild/3.9.4/bin"] = 1,
          },
          ["wV"] = "000000003.000000009.000000004.*zfinal",
          whatis = {
            "Name: easybuild ", "Version: 3.9.4 ", "Category: system tool "
            , "Description: Build and installation framework ", "URL: http://easybuilders.github.io/easybuild/ ",
          },
        },
      },
    },
    ["apps/mom_6"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["apps/mom_6/intel_18.2"]  = {
          ["Version"] = "intel_18.2",
          ["canonical"] = "intel_18.2",
          ["fn"] = "/opt/ohpc/pub/modulefiles/apps/mom_6/intel_18.2",
          ["help"] = [[
	Adds mom_6 to your environment

]],
          lpathA = {
            ["/home/apps/cdac/mom_6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*intel.*_.000000018.000000002.*zfinal",
          pathA = {
            ["/home/apps/cdac/mom_6/bin"] = 1,
          },
          ["wV"] = "*intel.*_.000000018.000000002.*zfinal",
          whatis = {
            "Adds mom_6 to your environment ",
          },
        },
      },
    },
    ["apps/mpiblast/1.6.0"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["apps/mpiblast/1.6.0/intel_18.2"]  = {
          ["Version"] = "intel_18.2",
          ["canonical"] = "intel_18.2",
          ["fn"] = "/opt/ohpc/pub/modulefiles/apps/mpiblast/1.6.0/intel_18.2",
          ["help"] = [[
	Adds mpiblast_1.6.0 to your environment

]],
          lpathA = {
            ["/home/apps/cdac/mpiblast_1.6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*intel.*_.000000018.000000002.*zfinal",
          pathA = {
            ["/home/apps/cdac/mpiblast_1.6.0/bin"] = 1,
          },
          ["wV"] = "*intel.*_.000000018.000000002.*zfinal",
          whatis = {
            "Adds mpiblast_1.6.0 to your environment ",
          },
        },
      },
    },
    ["apps/roms/3.6"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["apps/roms/3.6/intel_18"]  = {
          ["Version"] = "intel_18",
          ["canonical"] = "intel_18",
          ["fn"] = "/opt/ohpc/pub/modulefiles/apps/roms/3.6/intel_18",
          ["help"] = [[
	Adds roms_3.6 to your environment

]],
          lpathA = {
            ["/home/apps/cdacApps/roms_3.6/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*intel.*_.000000018.*zfinal",
          pathA = {
            ["/home/apps/cdacApps/roms_3.6/bin"] = 1,
          },
          ["wV"] = "*intel.*_.000000018.*zfinal",
          whatis = {
            "Adds roms_3.6 to your environment ",
          },
        },
      },
    },
    autotools = {
      defaultT = {},
      dirT = {},
      ["file"] = "/opt/ohpc/pub/modulefiles/autotools",
      fileT = {},
      metaModuleT = {
        ["Category"] = "utility, developer support ",
        ["Description"] = "Developer utilities ",
        ["Name"] = "GNU Autotools ",
        ["Version"] = "1.0 ",
        ["canonical"] = "autotools",
        ["fn"] = "/opt/ohpc/pub/modulefiles/autotools",
        ["help"] = [[
This module loads the autotools collection to provide recent
versions of autoconf, automake, and libtool.
 

]],
        ["mpath"] = "/opt/ohpc/pub/modulefiles",
        ["pV"] = "~",
        pathA = {
          ["/opt/ohpc/pub/utils/autotools/bin"] = 1,
        },
        ["wV"] = "~",
        whatis = {
          "Name: GNU Autotools ", "Version: 1.0 ", "Category: utility, developer support "
          , "Keywords: System, Utility ", "Description: Developer utilities ",
        },
      },
      ["mpath"] = "/opt/ohpc/pub/modulefiles",
    },
    charliecloud = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["charliecloud/.version.0.11"]  = {
          ["Version"] = ".version.0.11",
          ["canonical"] = ".version.0.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/charliecloud/.version.0.11",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000000.000000011.*zfinal",
          ["wV"] = "*version.000000000.000000011.*zfinal",
        },
        ["charliecloud/0.11"]  = {
          ["Category"] = "runtime ",
          ["Description"] = "Lightweight user-defined software stacks for high-performance computing ",
          ["Name"] = "charliecloud ",
          ["Version"] = "0.11 ",
          ["canonical"] = "0.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/charliecloud/0.11",
          ["help"] = [[
 
This module loads the charliecloud utility

Version 0.11


]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000000.000000011.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/charliecloud/0.11/bin"] = 1,
          },
          ["wV"] = "000000000.000000011.*zfinal",
          whatis = {
            "Name: charliecloud ", "Version: 0.11 ", "Category: runtime "
            , "Description: Lightweight user-defined software stacks for high-performance computing ", "URL https://hpc.github.io/charliecloud/ ",
          },
        },
        ["charliecloud/0.22"]  = {
          ["Category"] = "runtime ",
          ["Description"] = "Lightweight user-defined software stacks for high-performance computing ",
          ["Name"] = "charliecloud ",
          ["Version"] = "0.22 ",
          ["canonical"] = "0.22",
          ["fn"] = "/opt/ohpc/pub/modulefiles/charliecloud/0.22",
          ["help"] = [[
 
This module loads the charliecloud utility

Version 0.22


]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000000.000000022.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/charliecloud/0.22/bin"] = 1,
          },
          ["wV"] = "000000000.000000022.*zfinal",
          whatis = {
            "Name: charliecloud ", "Version: 0.22 ", "Category: runtime "
            , "Description: Lightweight user-defined software stacks for high-performance computing ", "URL https://hpc.github.io/charliecloud/ ",
          },
        },
      },
    },
    clustershell = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["clustershell/.version.1.8.2"]  = {
          ["Version"] = ".version.1.8.2",
          ["canonical"] = ".version.1.8.2",
          ["fn"] = "/opt/ohpc/pub/modulefiles/clustershell/.version.1.8.2",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000001.000000008.000000002.*zfinal",
          ["wV"] = "*version.000000001.000000008.000000002.*zfinal",
        },
        ["clustershell/1.8.2"]  = {
          ["Category"] = "python module ",
          ["Description"] = "VIM files for ClusterShell ",
          ["Name"] = "clustershell ",
          ["Version"] = "1.8.2 ",
          ["canonical"] = "1.8.2",
          ["fn"] = "/opt/ohpc/pub/modulefiles/clustershell/1.8.2",
          ["help"] = [[
 
This module loads the clustershell utility

Version 1.8.2


]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000001.000000008.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/clustershell/1.8.2/bin"] = 1,
          },
          ["wV"] = "000000001.000000008.000000002.*zfinal",
          whatis = {
            "Name: clustershell ", "Version: 1.8.2 ", "Category: python module "
            , "Description: VIM files for ClusterShell ", "URL http://clustershell.sourceforge.net/ ",
          },
        },
      },
    },
    cmake = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["cmake/.version.3.15.4"]  = {
          ["Version"] = ".version.3.15.4",
          ["canonical"] = ".version.3.15.4",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cmake/.version.3.15.4",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000003.000000015.000000004.*zfinal",
          ["wV"] = "*version.000000003.000000015.000000004.*zfinal",
        },
        ["cmake/3.15.4"]  = {
          ["Category"] = "utility, developer support ",
          ["Description"] = "CMake is an open-source, cross-platform family of tools designed to build, test and package software. ",
          ["Name"] = "cmake ",
          ["Version"] = "3.15.4 ",
          ["canonical"] = "3.15.4",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cmake/3.15.4",
          ["help"] = [[
 
This module loads the cmake utility

Version 3.15.4


]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000015.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/utils/cmake/3.15.4/bin"] = 1,
          },
          ["wV"] = "000000003.000000015.000000004.*zfinal",
          whatis = {
            "Name: cmake ", "Version: 3.15.4 ", "Category: utility, developer support "
            , "Keywords: System, Utility "
            , "Description: CMake is an open-source, cross-platform family of tools designed to build, test and package software. ", "URL https://cmake.org/ ",
          },
        },
      },
    },
    ["compiler/hpc_sdk/nvhpc"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["compiler/hpc_sdk/nvhpc/21.7"]  = {
          ["Version"] = "21.7",
          ["canonical"] = "21.7",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/hpc_sdk/nvhpc/21.7",
          lpathA = {
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/comm_libs/mpi/lib"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/comm_libs/nccl/lib"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/comm_libs/nvshmem/lib"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/compilers/extras/qd/lib"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/compilers/lib"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/cuda/extras/CUPTI/lib64"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/cuda/lib64"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/math_libs/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000021.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/comm_libs/mpi/bin"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/compilers/bin"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/compilers/extras/qd/bin"] = 1,
            ["/opt/ohpc/pub/compiler/hpc_sdk/Linux_x86_64/21.7/cuda/bin"] = 1,
          },
          ["wV"] = "000000021.000000007.*zfinal",
        },
      },
    },
    ["compiler/hpc_sdk_22.11/nvhpc"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["compiler/hpc_sdk_22.11/nvhpc/22.11"]  = {
          ["Version"] = "22.11",
          ["canonical"] = "22.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/hpc_sdk_22.11/nvhpc/22.11",
          lpathA = {
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/mpi/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/nccl/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/nvshmem/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/extras/qd/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/extras/CUPTI/lib64"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/lib64"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/math_libs/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000022.000000011.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/mpi/bin"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/bin"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/extras/qd/bin"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/bin"] = 1,
          },
          ["wV"] = "000000022.000000011.*zfinal",
        },
        ["compiler/hpc_sdk_22.11/nvhpc/22.11test"]  = {
          ["Version"] = "22.11test",
          ["canonical"] = "22.11test",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/hpc_sdk_22.11/nvhpc/22.11test",
          lpathA = {
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/mpi/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/nccl/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/nvshmem/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/extras/qd/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/extras/CUPTI/lib64"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/lib64"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/math_libs/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000022.000000011.*test.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/mpi/bin"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/bin"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/extras/qd/bin"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/bin"] = 1,
          },
          ["wV"] = "000000022.000000011.*test.*zfinal",
        },
      },
    },
    ["compiler/hpc_sdk_22.11/nvhpc-byo-compiler"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["compiler/hpc_sdk_22.11/nvhpc-byo-compiler/22.11"]  = {
          ["Version"] = "22.11",
          ["canonical"] = "22.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/hpc_sdk_22.11/nvhpc-byo-compiler/22.11",
          lpathA = {
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/nccl/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/nvshmem/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/extras/CUPTI/lib64"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/lib64"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/math_libs/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000022.000000011.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/bin"] = 1,
          },
          ["wV"] = "000000022.000000011.*zfinal",
        },
      },
    },
    ["compiler/hpc_sdk_22.11/nvhpc-nompi"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["compiler/hpc_sdk_22.11/nvhpc-nompi/22.11"]  = {
          ["Version"] = "22.11",
          ["canonical"] = "22.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/hpc_sdk_22.11/nvhpc-nompi/22.11",
          lpathA = {
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/nccl/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/comm_libs/nvshmem/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/extras/qd/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/lib"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/extras/CUPTI/lib64"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/lib64"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/math_libs/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000022.000000011.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/bin"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/compilers/extras/qd/bin"] = 1,
            ["/opt/ohpc/pub/hpc_sdk_22.11/Linux_x86_64/22.11/cuda/bin"] = 1,
          },
          ["wV"] = "000000022.000000011.*zfinal",
        },
      },
    },
    ["compiler/intel"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["compiler/intel/2017.7.259"]  = {
          ["Version"] = "2017.7.259",
          ["canonical"] = "2017.7.259",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/intel/2017.7.259",
          ["help"] = [[
 Intel(R) MPI Library

]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/compiler/lib"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/compiler/lib/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/mkl/lib/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/mpi/intel64/lib"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/mpi/intel64/lib/release"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/mpi/intel64/libfabric/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002017.000000007.000000259.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/bin/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/mpi/intel64/bin"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2017_7/compilers_and_libraries_2017.7.259/linux/mpi/intel64/libfabric/bin"] = 1,
          },
          ["wV"] = "000002017.000000007.000000259.*zfinal",
          whatis = {
            "Sets up the Intel(R) MPI Library environment ",
          },
        },
        ["compiler/intel/2018.4.057"]  = {
          ["Version"] = "2018.4.057",
          ["canonical"] = "2018.4.057",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/intel/2018.4.057",
          ["help"] = [[
 Intel(R) MPI Library

]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/compiler/lib"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/compiler/lib/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/mkl/lib/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/mpi/intel64/lib"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/mpi/intel64/lib/release"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/mpi/intel64/libfabric/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002018.000000004.000000057.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/bin/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/mpi/intel64/bin"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2018_4/compilers_and_libraries_2018.5.274/linux/mpi/intel64/libfabric/bin"] = 1,
          },
          ["wV"] = "000002018.000000004.000000057.*zfinal",
          whatis = {
            "Sets up the Intel(R) MPI Library environment ",
          },
        },
        ["compiler/intel/2019.5.281"]  = {
          ["Version"] = "2019.5.281",
          ["canonical"] = "2019.5.281",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/intel/2019.5.281",
          ["help"] = [[
 Intel(R) MPI Library

]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/compiler/lib"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/compiler/lib/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/mkl/lib/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/mpi/intel64/lib"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/mpi/intel64/lib/release"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/mpi/intel64/libfabric/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002019.000000005.000000281.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/bin/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/mpi/intel64/bin"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2019_5/compilers_and_libraries_2019.5.281/linux/mpi/intel64/libfabric/bin"] = 1,
          },
          ["wV"] = "000002019.000000005.000000281.*zfinal",
          whatis = {
            "Sets up the Intel(R) MPI Library environment ",
          },
        },
        ["compiler/intel/2020.4.304"]  = {
          ["Version"] = "2020.4.304",
          ["canonical"] = "2020.4.304",
          ["fn"] = "/opt/ohpc/pub/modulefiles/compiler/intel/2020.4.304",
          ["help"] = [[
 Intel(R) MPI Library

]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/compiler/lib"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/compiler/lib/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/mkl/lib/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/mpi/intel64/lib"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/mpi/intel64/lib/release"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/mpi/intel64/libfabric/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002020.000000004.000000304.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/bin/intel64"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/mpi/intel64/bin"] = 1,
            ["/opt/ohpc/pub/compiler/intel/2020_4/compilers_and_libraries_2020.4.304/linux/mpi/intel64/libfabric/bin"] = 1,
          },
          ["wV"] = "000002020.000000004.000000304.*zfinal",
          whatis = {
            "Sets up the Intel(R) MPI Library environment ",
          },
        },
      },
    },
    cuda = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["cuda/10.0"]  = {
          ["Version"] = "10.0",
          ["canonical"] = "10.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/10.0",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-10.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000010.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-10.0/bin"] = 1,
          },
          ["wV"] = "000000010.*zfinal",
        },
        ["cuda/10.1"]  = {
          ["Version"] = "10.1",
          ["canonical"] = "10.1",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/10.1",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-10.1/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000010.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-10.1/bin"] = 1,
          },
          ["wV"] = "000000010.000000001.*zfinal",
        },
        ["cuda/10.2"]  = {
          ["Version"] = "10.2",
          ["canonical"] = "10.2",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/10.2",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-10.2/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000010.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-10.2/bin"] = 1,
          },
          ["wV"] = "000000010.000000002.*zfinal",
        },
        ["cuda/11.0"]  = {
          ["Version"] = "11.0",
          ["canonical"] = "11.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/11.0",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-11.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000011.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-11.0/bin"] = 1,
          },
          ["wV"] = "000000011.*zfinal",
        },
        ["cuda/11.2"]  = {
          ["Version"] = "11.2",
          ["canonical"] = "11.2",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/11.2",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-11.2/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000011.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-11.2/bin"] = 1,
          },
          ["wV"] = "000000011.000000002.*zfinal",
        },
        ["cuda/11.7"]  = {
          ["Version"] = "11.7",
          ["canonical"] = "11.7",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/11.7",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-11.7/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000011.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-11.7/bin"] = 1,
          },
          ["wV"] = "000000011.000000007.*zfinal",
        },
        ["cuda/11.8"]  = {
          ["Version"] = "11.8",
          ["canonical"] = "11.8",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/11.8",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-11.8/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000011.000000008.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-11.8/bin"] = 1,
          },
          ["wV"] = "000000011.000000008.*zfinal",
        },
        ["cuda/12.0"]  = {
          ["Version"] = "12.0",
          ["canonical"] = "12.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/12.0",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-12.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000012.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-12.0/bin"] = 1,
          },
          ["wV"] = "000000012.*zfinal",
        },
        ["cuda/7.5"]  = {
          ["Version"] = "7.5",
          ["canonical"] = "7.5",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/7.5",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-7.5/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000007.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-7.5/bin"] = 1,
          },
          ["wV"] = "000000007.000000005.*zfinal",
        },
        ["cuda/8.0"]  = {
          ["Version"] = "8.0",
          ["canonical"] = "8.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/8.0",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-8.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000008.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-8.0/bin"] = 1,
          },
          ["wV"] = "000000008.*zfinal",
        },
        ["cuda/9.0"]  = {
          ["Version"] = "9.0",
          ["canonical"] = "9.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/9.0",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-9.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000009.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-9.0/bin"] = 1,
          },
          ["wV"] = "000000009.*zfinal",
        },
        ["cuda/9.2"]  = {
          ["Version"] = "9.2",
          ["canonical"] = "9.2",
          ["fn"] = "/opt/ohpc/pub/modulefiles/cuda/9.2",
          lpathA = {
            ["/opt/ohpc/pub/cuda/cuda-9.2/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000009.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/cuda/cuda-9.2/bin"] = 1,
          },
          ["wV"] = "000000009.000000002.*zfinal",
        },
      },
    },
    fftw = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["fftw/3.3"]  = {
          ["Version"] = "3.3",
          ["canonical"] = "3.3",
          ["fn"] = "/opt/ohpc/pub/modulefiles/fftw/3.3",
          ["help"] = [[
	Adds FFTW to your environment

]],
          lpathA = {
            ["/home/atos02/fftw/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000003.*zfinal",
          pathA = {
            ["/home/atos02/fftw/bin"] = 1,
          },
          ["wV"] = "000000003.000000003.*zfinal",
          whatis = {
            "Adds FFTW to your environment ",
          },
        },
      },
    },
    firefox = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["firefox/101.0"]  = {
          ["Version"] = "101.0",
          ["canonical"] = "101.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/firefox/101.0",
          lpathA = {
            ["/home/apps/firefox"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000101.*zfinal",
          pathA = {
            ["/home/apps/firefox"] = 1,
          },
          ["wV"] = "000000101.*zfinal",
        },
      },
    },
    gcc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gcc/8.2.0"]  = {
          ["Category"] = "compiler, runtime support ",
          ["Description"] = "GNU Compiler Family (C/C++/Fortran for x86_64) ",
          ["Name"] = "GNU Compiler Collection ",
          ["URL"] = "http://gcc.gnu.org/ ",
          ["Version"] = "8.2.0 ",
          ["canonical"] = "8.2.0",
          ["family"] = "compiler",
          ["fn"] = "/opt/ohpc/pub/modulefiles/gcc/8.2.0",
          ["help"] = [[
 
This module loads the GNU compiler collection
 
See the man pages for gcc, g++, and gfortran for detailed information
on available compiler options and command-line syntax.
 

Version 8.2.0


]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/gcc/8.2.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000008.000000002.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/gcc/8.2.0/bin"] = 1,
          },
          ["wV"] = "000000008.000000002.*zfinal",
          whatis = {
            "Name: GNU Compiler Collection ", "Version: 8.2.0 "
            , "Category: compiler, runtime support "
            , "Description: GNU Compiler Family (C/C++/Fortran for x86_64) ", "URL: http://gcc.gnu.org/ ",
          },
        },
      },
    },
    gnu = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gnu/.version.5.4.0"]  = {
          ["Version"] = ".version.5.4.0",
          ["canonical"] = ".version.5.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/gnu/.version.5.4.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000005.000000004.*zfinal",
          ["wV"] = "*version.000000005.000000004.*zfinal",
        },
        ["gnu/5.4.0"]  = {
          ["Category"] = "compiler, runtime support ",
          ["Description"] = "GNU Compiler Family (C/C++/Fortran for x86_64) ",
          ["Name"] = "GNU Compiler Collection ",
          ["URL"] = "http://gcc.gnu.org/ ",
          ["Version"] = "5.4.0 ",
          ["canonical"] = "5.4.0",
          ["family"] = "compiler",
          ["fn"] = "/opt/ohpc/pub/modulefiles/gnu/5.4.0",
          ["help"] = [[
 
This module loads the GNU compiler collection
 
See the man pages for gcc, g++, and gfortran for detailed information
on available compiler options and command-line syntax.
 

Version 5.4.0


]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/gcc/5.4.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000005.000000004.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/gcc/5.4.0/bin"] = 1,
          },
          ["wV"] = "000000005.000000004.*zfinal",
          whatis = {
            "Name: GNU Compiler Collection ", "Version: 5.4.0 "
            , "Category: compiler, runtime support "
            , "Description: GNU Compiler Family (C/C++/Fortran for x86_64) ", "URL: http://gcc.gnu.org/ ",
          },
        },
      },
    },
    gnu8 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["gnu8/.version.8.3.0"]  = {
          ["Version"] = ".version.8.3.0",
          ["canonical"] = ".version.8.3.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/gnu8/.version.8.3.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000008.000000003.*zfinal",
          ["wV"] = "*version.000000008.000000003.*zfinal",
        },
        ["gnu8/8.3.0"]  = {
          ["Category"] = "compiler, runtime support ",
          ["Description"] = "GNU Compiler Family (C/C++/Fortran for x86_64) ",
          ["Name"] = "GNU Compiler Collection ",
          ["URL"] = "http://gcc.gnu.org/ ",
          ["Version"] = "8.3.0 ",
          ["canonical"] = "8.3.0",
          ["family"] = "compiler",
          ["fn"] = "/opt/ohpc/pub/modulefiles/gnu8/8.3.0",
          ["help"] = [[
 
This module loads the GNU compiler collection
 
See the man pages for gcc, g++, and gfortran for detailed information
on available compiler options and command-line syntax.
 

Version 8.3.0


]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/gcc/8.3.0/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000008.000000003.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/gcc/8.3.0/bin"] = 1,
          },
          ["wV"] = "000000008.000000003.*zfinal",
          whatis = {
            "Name: GNU Compiler Collection ", "Version: 8.3.0 "
            , "Category: compiler, runtime support "
            , "Description: GNU Compiler Family (C/C++/Fortran for x86_64) ", "URL: http://gcc.gnu.org/ ",
          },
        },
      },
    },
    hwloc = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["hwloc/.version.2.1.0"]  = {
          ["Version"] = ".version.2.1.0",
          ["canonical"] = ".version.2.1.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/hwloc/.version.2.1.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000002.000000001.*zfinal",
          ["wV"] = "*version.000000002.000000001.*zfinal",
        },
        ["hwloc/2.1.0"]  = {
          ["Category"] = "python module ",
          ["Description"] = "Portable Hardware Locality ",
          ["Name"] = "hwloc ",
          ["Version"] = "2.1.0 ",
          ["canonical"] = "2.1.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/hwloc/2.1.0",
          ["help"] = [[
 
This module loads the hwloc utility

Version 2.1.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/hwloc/2.1.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000002.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/hwloc/2.1.0/bin"] = 1,
          },
          ["wV"] = "000000002.000000001.*zfinal",
          whatis = {
            "Name: hwloc ", "Version: 2.1.0 ", "Category: python module "
            , "Description: Portable Hardware Locality ", "URL http://www.open-mpi.org/projects/hwloc/ ",
          },
        },
      },
    },
    intel = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["intel/18.0.5.274"]  = {
          ["Category"] = "compiler, runtime support ",
          ["Description"] = "Intel Compiler Family (C/C++/Fortran for x86_64) ",
          ["Name"] = "Intel Compiler ",
          ["URL"] = "http://software.intel.com/en-us/articles/intel-compilers/ ",
          ["Version"] = "18.0.5.274 ",
          ["canonical"] = "18.0.5.274",
          ["family"] = "compiler",
          ["fn"] = "/opt/ohpc/pub/modulefiles/intel/18.0.5.274",
          ["help"] = [[
 
See the man pages for icc, icpc, and ifort for detailed information
on available compiler options and command-line syntax.

Version 18.0.5.274


]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000018.000000000.000000005.000000274.*zfinal",
          ["wV"] = "000000018.000000000.000000005.000000274.*zfinal",
          whatis = {
            "Name: Intel Compiler ", "Version: 18.0.5.274 "
            , "Category: compiler, runtime support "
            , "Description: Intel Compiler Family (C/C++/Fortran for x86_64) ", "URL: http://software.intel.com/en-us/articles/intel-compilers/ ",
          },
        },
      },
    },
    ["lib/netcdf_c/4.3.3.1"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["lib/netcdf_c/4.3.3.1/intel_18"]  = {
          ["Version"] = "intel_18",
          ["canonical"] = "intel_18",
          ["fn"] = "/opt/ohpc/pub/modulefiles/lib/netcdf_c/4.3.3.1/intel_18",
          ["help"] = [[
	Adds netcdf_c_with_parallel_support_4.3.3.1 to your environment

]],
          lpathA = {
            ["/home/apps/cdacApps/deps/netcdf_c_with_parallel_support_4.3.3.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*intel.*_.000000018.*zfinal",
          pathA = {
            ["/home/apps/cdacApps/deps/netcdf_c_with_parallel_support_4.3.3.1/bin"] = 1,
          },
          ["wV"] = "*intel.*_.000000018.*zfinal",
          whatis = {
            "Adds netcdf_c_with_parallel_support_4.3.3.1 to your environment ",
          },
        },
      },
    },
    ["lib/netcdf_fortran/4.4.0"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["lib/netcdf_fortran/4.4.0/intel_18"]  = {
          ["Version"] = "intel_18",
          ["canonical"] = "intel_18",
          ["fn"] = "/opt/ohpc/pub/modulefiles/lib/netcdf_fortran/4.4.0/intel_18",
          ["help"] = [[
	Adds netcdf_fortran_with_parallel_support_4.4.0 to your environment

]],
          lpathA = {
            ["/home/apps/cdacApps/deps/netcdf_fortran_with_parallel_support_4.4.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*intel.*_.000000018.*zfinal",
          pathA = {
            ["/home/apps/cdacApps/deps/netcdf_fortran_with_parallel_support_4.4.0/bin"] = 1,
          },
          ["wV"] = "*intel.*_.000000018.*zfinal",
          whatis = {
            "Adds netcdf_fortran_with_parallel_support_4.4.0 to your environment ",
          },
        },
      },
    },
    ["lib/parallel_hdf5/1.8.21"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["lib/parallel_hdf5/1.8.21/intel_18"]  = {
          ["Version"] = "intel_18",
          ["canonical"] = "intel_18",
          ["fn"] = "/opt/ohpc/pub/modulefiles/lib/parallel_hdf5/1.8.21/intel_18",
          ["help"] = [[
	Adds parallel_hdf5_1.8.21 to your environment

]],
          lpathA = {
            ["/home/apps/cdacApps/deps/parallel_hdf5_1.8.21/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*intel.*_.000000018.*zfinal",
          pathA = {
            ["/home/apps/cdacApps/deps/parallel_hdf5_1.8.21/bin"] = 1,
          },
          ["wV"] = "*intel.*_.000000018.*zfinal",
          whatis = {
            "Adds parallel_hdf5_1.8.21 to your environment ",
          },
        },
      },
    },
    ["lib/parallel_netcdf/1.8.1"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["lib/parallel_netcdf/1.8.1/intel_18"]  = {
          ["Version"] = "intel_18",
          ["canonical"] = "intel_18",
          ["fn"] = "/opt/ohpc/pub/modulefiles/lib/parallel_netcdf/1.8.1/intel_18",
          ["help"] = [[
	Adds parallel_netcdf_1.8.1 to your environment

]],
          lpathA = {
            ["/home/apps/cdacApps/deps/parallel_netcdf_1.8.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*intel.*_.000000018.*zfinal",
          pathA = {
            ["/home/apps/cdacApps/deps/parallel_netcdf_1.8.1/bin"] = 1,
          },
          ["wV"] = "*intel.*_.000000018.*zfinal",
          whatis = {
            "Adds parallel_netcdf_1.8.1 to your environment ",
          },
        },
      },
    },
    llvm5 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["llvm5/.version.5.0.1"]  = {
          ["Version"] = ".version.5.0.1",
          ["canonical"] = ".version.5.0.1",
          ["fn"] = "/opt/ohpc/pub/modulefiles/llvm5/.version.5.0.1",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000005.000000000.000000001.*zfinal",
          ["wV"] = "*version.000000005.000000000.000000001.*zfinal",
        },
        ["llvm5/5.0.1"]  = {
          ["Category"] = "compiler, runtime support ",
          ["Description"] = "LLVM Compiler Infrastructure ",
          ["Name"] = "LLVM Compiler Infrastructure ",
          ["URL"] = "http://www.llvm.org ",
          ["Version"] = "5.0.1 ",
          ["canonical"] = "5.0.1",
          ["family"] = "compiler",
          ["fn"] = "/opt/ohpc/pub/modulefiles/llvm5/5.0.1",
          ["help"] = [[
 
This module loads the LLVM compiler infrastructure
 

Version 5.0.1


]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/llvm/5.0.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000005.000000000.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/llvm/5.0.1/bin"] = 1,
          },
          ["wV"] = "000000005.000000000.000000001.*zfinal",
          whatis = {
            "Name: LLVM Compiler Infrastructure ", "Version: 5.0.1 "
            , "Category: compiler, runtime support "
            , "Description: LLVM Compiler Infrastructure ", "URL: http://www.llvm.org ",
          },
        },
      },
    },
    ohpc = {
      defaultT = {},
      dirT = {},
      ["file"] = "/opt/ohpc/pub/modulefiles/ohpc",
      fileT = {},
      metaModuleT = {
        ["canonical"] = "ohpc",
        ["fn"] = "/opt/ohpc/pub/modulefiles/ohpc",
        ["help"] = [[
Setup default login environment

]],
        ["mpath"] = "/opt/ohpc/pub/modulefiles",
        ["pV"] = "~",
        pathA = {
          ["/opt/ohpc/pub/bin"] = 1,
        },
        ["wV"] = "~",
      },
      ["mpath"] = "/opt/ohpc/pub/modulefiles",
    },
    ["oneapi/advisor"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/advisor/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/advisor/2021.4.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/advisor/2021.4.0/bin64"] = 1,
          },
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) Advisor 2021.4 ",
          },
        },
        ["oneapi/advisor/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/advisor/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/advisor/2021.4.0/bin64"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) Advisor 2021.4 ",
          },
        },
      },
    },
    ["oneapi/ccl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/ccl/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/ccl/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ccl/2021.4.0/lib/cpu_gpu_dpcpp"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) oneAPI Collective Communications Library ",
          },
        },
        ["oneapi/ccl/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/ccl/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ccl/2021.4.0/lib/cpu_gpu_dpcpp"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI Collective Communications Library ",
          },
        },
      },
    },
    ["oneapi/clck"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/clck/2021.5.0"]  = {
          ["Version"] = "2021.5.0",
          ["canonical"] = "2021.5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/clck/2021.5.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000005.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/clck/2021.5.0/bin/intel64"] = 1,
          },
          ["wV"] = "000002021.000000005.*zfinal",
          whatis = {
            "Intel(R) Cluster Checker ",
          },
        },
        ["oneapi/clck/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/clck/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/clck/2021.5.0/bin/intel64"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) Cluster Checker ",
          },
        },
      },
    },
    ["oneapi/compiler"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/compiler/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/compiler/2022.0.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin/intel64"] = 1,
          },
          ["wV"] = "000002022.*zfinal",
          whatis = {
            "Configure for use with Intel 64-bit compiler(s). ",
          },
        },
        ["oneapi/compiler/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/compiler/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin/intel64"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Configure for use with Intel 64-bit compiler(s). ",
          },
        },
      },
    },
    ["oneapi/compiler-rt"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/compiler-rt/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/compiler-rt/2022.0.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/lib/x64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          ["wV"] = "000002022.*zfinal",
        },
        ["oneapi/compiler-rt/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/compiler-rt/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/compiler/lib/intel64_lin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/lib/x64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
        },
      },
    },
    ["oneapi/compiler-rt32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/compiler-rt32/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/compiler-rt32/2022.0.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/compiler/lib/ia32_lin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/compiler/lib/intel64_lin"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          ["wV"] = "000002022.*zfinal",
        },
        ["oneapi/compiler-rt32/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/compiler-rt32/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/compiler/lib/ia32_lin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/compiler/lib/intel64_lin"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
        },
      },
    },
    ["oneapi/compiler32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/compiler32/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/compiler32/2022.0.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin/intel64"] = 1,
          },
          ["wV"] = "000002022.*zfinal",
          whatis = {
            "Configure for use with Intel 32-bit compiler(s). ",
          },
        },
        ["oneapi/compiler32/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/compiler32/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin/intel64"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Configure for use with Intel 32-bit compiler(s). ",
          },
        },
      },
    },
    ["oneapi/dal"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/dal/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dal/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dal/2021.4.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/dal/2021.4.0/lib/intel64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) oneAPI Data Analytics Library for intel64. ",
          },
        },
        ["oneapi/dal/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dal/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dal/2021.4.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/dal/2021.4.0/lib/intel64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI Data Analytics Library for intel64. ",
          },
        },
      },
    },
    ["oneapi/debugger"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/debugger/2021.5.0"]  = {
          ["Version"] = "2021.5.0",
          ["canonical"] = "2021.5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/debugger/2021.5.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/debugger/2021.5.0/dep/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/debugger/2021.5.0/gdb/intel64/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/debugger/2021.5.0/libipt/intel64/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000005.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/debugger/2021.5.0/gdb/intel64/bin"] = 1,
          },
          ["wV"] = "000002021.000000005.*zfinal",
          whatis = {
            "The gdb-oneapi debugger (an extension of standard gdb). ",
          },
        },
        ["oneapi/debugger/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/debugger/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/debugger/2021.5.0/dep/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/debugger/2021.5.0/gdb/intel64/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/debugger/2021.5.0/libipt/intel64/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/debugger/2021.5.0/gdb/intel64/bin"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "The gdb-oneapi debugger (an extension of standard gdb). ",
          },
        },
      },
    },
    ["oneapi/dev-utilities"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/dev-utilities/2021.5.0"]  = {
          ["Version"] = "2021.5.0",
          ["canonical"] = "2021.5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dev-utilities/2021.5.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000005.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/dev-utilities/2021.5.0/bin"] = 1,
          },
          ["wV"] = "000002021.000000005.*zfinal",
          whatis = {
            "Add oneap-cli sample browser to PATH and oneAPI samples include dirs into CPATH. ",
          },
        },
        ["oneapi/dev-utilities/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dev-utilities/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/dev-utilities/2021.5.0/bin"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Add oneap-cli sample browser to PATH and oneAPI samples include dirs into CPATH. ",
          },
        },
      },
    },
    ["oneapi/dnnl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/dnnl/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dnnl/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dnnl/2021.4.0/cpu_dpcpp_gpu_dpcpp/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "IntelÂ® oneAPI Deep Neural Network Library for the cpu_dpcpp_gpu_dpcpp configuration. ",
          },
        },
        ["oneapi/dnnl/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dnnl/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dnnl/2021.4.0/cpu_dpcpp_gpu_dpcpp/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "IntelÂ® oneAPI Deep Neural Network Library for the cpu_dpcpp_gpu_dpcpp configuration. ",
          },
        },
      },
    },
    ["oneapi/dnnl-cpu-gomp"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/dnnl-cpu-gomp/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dnnl-cpu-gomp/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dnnl/2021.4.0/cpu_gomp/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "IntelÂ® oneAPI Deep Neural Network Library for the cpu_gomp configuration. ",
          },
        },
        ["oneapi/dnnl-cpu-gomp/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dnnl-cpu-gomp/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dnnl/2021.4.0/cpu_gomp/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "IntelÂ® oneAPI Deep Neural Network Library for the cpu_gomp configuration. ",
          },
        },
      },
    },
    ["oneapi/dnnl-cpu-iomp"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/dnnl-cpu-iomp/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dnnl-cpu-iomp/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dnnl/2021.4.0/cpu_iomp/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "IntelÂ® oneAPI Deep Neural Network Library for the cpu_iomp configuration. ",
          },
        },
        ["oneapi/dnnl-cpu-iomp/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dnnl-cpu-iomp/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dnnl/2021.4.0/cpu_iomp/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "IntelÂ® oneAPI Deep Neural Network Library for the cpu_iomp configuration. ",
          },
        },
      },
    },
    ["oneapi/dnnl-cpu-tbb"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/dnnl-cpu-tbb/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dnnl-cpu-tbb/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dnnl/2021.4.0/cpu_tbb/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "IntelÂ® oneAPI Deep Neural Network Library for the cpu_tbb configuration. ",
          },
        },
        ["oneapi/dnnl-cpu-tbb/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dnnl-cpu-tbb/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/dnnl/2021.4.0/cpu_tbb/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "IntelÂ® oneAPI Deep Neural Network Library for the cpu_tbb configuration. ",
          },
        },
      },
    },
    ["oneapi/dpct"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/dpct/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dpct/2021.4.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/dpcpp-ct/2021.4.0/bin"] = 1,
          },
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Configure for Intel(R) DPC++ Compatibility Tool. ",
          },
        },
        ["oneapi/dpct/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dpct/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/dpcpp-ct/2021.4.0/bin"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Configure for Intel(R) DPC++ Compatibility Tool. ",
          },
        },
      },
    },
    ["oneapi/dpl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/dpl/2021.5.0"]  = {
          ["Version"] = "2021.5.0",
          ["canonical"] = "2021.5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dpl/2021.5.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000005.*zfinal",
          ["wV"] = "000002021.000000005.*zfinal",
          whatis = {
            "Intel(R) DPC++ Library. ",
          },
        },
        ["oneapi/dpl/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/dpl/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) DPC++ Library. ",
          },
        },
      },
    },
    ["oneapi/icc"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/icc/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/icc/2022.0.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin/intel64"] = 1,
          },
          ["wV"] = "000002022.*zfinal",
          whatis = {
            "Intel 64-bit Classic Compiler (icc) ",
          },
        },
        ["oneapi/icc/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/icc/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin/intel64"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel 64-bit Classic Compiler (icc) ",
          },
        },
      },
    },
    ["oneapi/icc32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/icc32/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/icc32/2022.0.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin/intel64"] = 1,
          },
          ["wV"] = "000002022.*zfinal",
          whatis = {
            "Intel 32-bit Classic Compiler (icc) ",
          },
        },
        ["oneapi/icc32/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/icc32/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/compiler/2022.0.0/linux/bin/intel64"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel 32-bit Classic Compiler (icc) ",
          },
        },
      },
    },
    ["oneapi/init_opencl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/init_opencl/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/init_opencl/2022.0.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          ["wV"] = "000002022.*zfinal",
          whatis = {
            "Submodule for Intel(R) oneAPI DPCPP compiler FPGA environment ",
          },
        },
        ["oneapi/init_opencl/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/init_opencl/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Submodule for Intel(R) oneAPI DPCPP compiler FPGA environment ",
          },
        },
      },
    },
    ["oneapi/inspector"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/inspector/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/inspector/2022.0.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/inspector/2022.0.0/bin64"] = 1,
          },
          ["wV"] = "000002022.*zfinal",
          whatis = {
            "Intel(R) Inspector 2022.0 ",
          },
        },
        ["oneapi/inspector/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/inspector/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/inspector/2022.0.0/bin64"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) Inspector 2022.0 ",
          },
        },
      },
    },
    ["oneapi/intel_ipp_ia32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/intel_ipp_ia32/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/intel_ipp_ia32/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ipp/2021.4.0/lib/ia32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) Integrated Performance Primitives IA-32 architecture. For a full Intel(R) IPP functionality, you should load Intel(R) oneAPI Compiler and Intel(R) oneAPI Threading Building Blocks modules. ",
          },
        },
        ["oneapi/intel_ipp_ia32/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/intel_ipp_ia32/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ipp/2021.4.0/lib/ia32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) Integrated Performance Primitives IA-32 architecture. For a full Intel(R) IPP functionality, you should load Intel(R) oneAPI Compiler and Intel(R) oneAPI Threading Building Blocks modules. ",
          },
        },
      },
    },
    ["oneapi/intel_ipp_intel64"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/intel_ipp_intel64/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/intel_ipp_intel64/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ipp/2021.4.0/lib/intel64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) Integrated Performance Primitives Intel(R) 64 architecture. For a full Intel(R) IPP functionality, you should load Intel(R) oneAPI Compiler and Intel(R) oneAPI Threading Building Blocks modules. ",
          },
        },
        ["oneapi/intel_ipp_intel64/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/intel_ipp_intel64/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ipp/2021.4.0/lib/intel64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) Integrated Performance Primitives Intel(R) 64 architecture. For a full Intel(R) IPP functionality, you should load Intel(R) oneAPI Compiler and Intel(R) oneAPI Threading Building Blocks modules. ",
          },
        },
      },
    },
    ["oneapi/intel_ippcp_ia32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/intel_ippcp_ia32/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/intel_ippcp_ia32/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ippcp/2021.4.0/lib/ia32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) Integrated Performance Primitives Cryptography IA-32 architecture. For a full Intel(R) IPP functionality, you should load Intel(R) oneAPI Compiler and Intel(R) oneAPI Threading Building Blocks modules. ",
          },
        },
        ["oneapi/intel_ippcp_ia32/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/intel_ippcp_ia32/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ippcp/2021.4.0/lib/ia32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) Integrated Performance Primitives Cryptography IA-32 architecture. For a full Intel(R) IPP functionality, you should load Intel(R) oneAPI Compiler and Intel(R) oneAPI Threading Building Blocks modules. ",
          },
        },
      },
    },
    ["oneapi/intel_ippcp_intel64"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/intel_ippcp_intel64/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/intel_ippcp_intel64/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ippcp/2021.4.0/lib/intel64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) Integrated Performance Primitives Cryptography Intel(R) 64 architecture. For a full Intel(R) IPP functionality, you should load Intel(R) oneAPI Compiler and Intel(R) oneAPI Threading Building Blocks modules. ",
          },
        },
        ["oneapi/intel_ippcp_intel64/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/intel_ippcp_intel64/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/ippcp/2021.4.0/lib/intel64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) Integrated Performance Primitives Cryptography Intel(R) 64 architecture. For a full Intel(R) IPP functionality, you should load Intel(R) oneAPI Compiler and Intel(R) oneAPI Threading Building Blocks modules. ",
          },
        },
      },
    },
    ["oneapi/itac"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/itac/2021.5.0"]  = {
          ["Version"] = "2021.5.0",
          ["canonical"] = "2021.5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/itac/2021.5.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/itac/2021.5.0/slib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000005.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/itac/2021.5.0/bin"] = 1,
          },
          ["wV"] = "000002021.000000005.*zfinal",
          whatis = {
            "Intel(R) Trace Analyzer and Collector ",
          },
        },
        ["oneapi/itac/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/itac/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/itac/2021.5.0/slib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/itac/2021.5.0/bin"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) Trace Analyzer and Collector ",
          },
        },
      },
    },
    ["oneapi/mkl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/mkl/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/mkl/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/mkl/2021.4.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mkl/2021.4.0/lib/intel64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) oneAPI Math Kernel Library (oneMKL) IA-64 architecture ",
          },
        },
        ["oneapi/mkl/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/mkl/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/mkl/2021.4.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mkl/2021.4.0/lib/intel64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI Math Kernel Library (oneMKL) IA-64 architecture ",
          },
        },
      },
    },
    ["oneapi/mkl32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/mkl32/2021.4.0"]  = {
          ["Version"] = "2021.4.0",
          ["canonical"] = "2021.4.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/mkl32/2021.4.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/mkl/2021.4.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mkl/2021.4.0/lib/ia32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000004.*zfinal",
          ["wV"] = "000002021.000000004.*zfinal",
          whatis = {
            "Intel(R) oneAPI Math Kernel Library (oneMKL) IA-32 architecture ",
          },
        },
        ["oneapi/mkl32/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/mkl32/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/mkl/2021.4.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mkl/2021.4.0/lib/ia32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI Math Kernel Library (oneMKL) IA-32 architecture ",
          },
        },
      },
    },
    ["oneapi/mpi"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/mpi/2021.5.0"]  = {
          ["Version"] = "2021.5.0",
          ["canonical"] = "2021.5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/mpi/2021.5.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/lib/release"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/libfabric/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000005.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/bin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/libfabric/bin"] = 1,
          },
          ["wV"] = "000002021.000000005.*zfinal",
          whatis = {
            "Intel(R) MPI Library ",
          },
        },
        ["oneapi/mpi/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/mpi/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/lib/release"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/libfabric/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/bin"] = 1,
            ["/home/opt_ohpc_pub/oneapi/mpi/2021.5.0/libfabric/bin"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) MPI Library ",
          },
        },
      },
    },
    ["oneapi/oclfpga"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/oclfpga/2022.0.0"]  = {
          ["Version"] = "2022.0.0",
          ["canonical"] = "2022.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/oclfpga/2022.0.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          ["wV"] = "000002022.*zfinal",
          whatis = {
            "Intel(R) oneAPI DPCPP compiler FPGA environment ",
          },
        },
        ["oneapi/oclfpga/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/oclfpga/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI DPCPP compiler FPGA environment ",
          },
        },
      },
    },
    ["oneapi/tbb"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/tbb/2021.5.0"]  = {
          ["Version"] = "2021.5.0",
          ["canonical"] = "2021.5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/tbb/2021.5.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/tbb/2021.5.0/lib/intel64/gcc4.8"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000005.*zfinal",
          ["wV"] = "000002021.000000005.*zfinal",
          whatis = {
            "Intel(R) oneAPI Threading Building Blocks for intel64. ",
          },
        },
        ["oneapi/tbb/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/tbb/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/tbb/2021.5.0/lib/intel64/gcc4.8"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI Threading Building Blocks for intel64. ",
          },
        },
      },
    },
    ["oneapi/tbb32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/tbb32/2021.5.0"]  = {
          ["Version"] = "2021.5.0",
          ["canonical"] = "2021.5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/tbb32/2021.5.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/tbb/2021.5.0/lib/ia32/gcc4.8"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000005.*zfinal",
          ["wV"] = "000002021.000000005.*zfinal",
          whatis = {
            "Intel(R) oneAPI Threading Building Blocks for ia32. ",
          },
        },
        ["oneapi/tbb32/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/tbb32/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/tbb/2021.5.0/lib/ia32/gcc4.8"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI Threading Building Blocks for ia32. ",
          },
        },
      },
    },
    ["oneapi/vpl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/vpl/2021.6.0"]  = {
          ["Version"] = "2021.6.0",
          ["canonical"] = "2021.6.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/vpl/2021.6.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/vpl/2021.6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000006.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/vpl/2021.6.0/bin"] = 1,
          },
          ["wV"] = "000002021.000000006.*zfinal",
          whatis = {
            "Intel(R) oneAPI Video Processing Library. ",
          },
        },
        ["oneapi/vpl/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/vpl/latest",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi/vpl/2021.6.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/vpl/2021.6.0/bin"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI Video Processing Library. ",
          },
        },
      },
    },
    ["oneapi/vtune"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi/vtune/2021.7.1"]  = {
          ["Version"] = "2021.7.1",
          ["canonical"] = "2021.7.1",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/vtune/2021.7.1",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000007.000000001.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/vtune/2021.7.1/bin64"] = 1,
          },
          ["wV"] = "000002021.000000007.000000001.*zfinal",
          whatis = {
            "Intel(R) oneAPI VTune(TM) Profiler 2021.7.1 ",
          },
        },
        ["oneapi/vtune/latest"]  = {
          ["Version"] = "latest",
          ["canonical"] = "latest",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi/vtune/latest",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*latest.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi/vtune/2021.7.1/bin64"] = 1,
          },
          ["wV"] = "*latest.*zfinal",
          whatis = {
            "Intel(R) oneAPI VTune(TM) Profiler 2021.7.1 ",
          },
        },
      },
    },
    ["oneapi_2024/advisor"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/advisor/2024.0"]  = {
          ["Version"] = "/} ",
          ["canonical"] = "2024.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/advisor/2024.0",
          ["help"] = "",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/bin64"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Intel(R) Advisor 2024.0.0 ", "Version: /} ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/ccl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/ccl/2021.11.0"]  = {
          ["Description"] = "Supports message passing interfaces (MPI) and libfabrics over a variety of interconnects. ",
          ["Name"] = "IntelÂ® oneAPI Collective Communications Library ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/oneccl.html ",
          ["Version"] = "ccl/2021.11.0 ",
          ["canonical"] = "2021.11.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/ccl/2021.11.0",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/ccl/2021.11/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000011.*zfinal",
          ["wV"] = "000002021.000000011.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI Collective Communications Library "
            , "Version: ccl/2021.11.0 "
            , "Description: Supports message passing interfaces (MPI) and libfabrics over a variety of interconnects. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/oneccl.html ", "Dependencies: mpi ",
          },
        },
      },
    },
    ["oneapi_2024/compiler"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/compiler/2024.0.0"]  = {
          ["Description"] = "IntelÂ® oneAPI C/C++ and SYCL code compiler for CPUs, GPUs and FPGAs ",
          ["Name"] = "IntelÂ® oneAPI DPC++/C++ Compiler ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-compiler.html ",
          ["Version"] = "compiler/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/compiler/2024.0.0",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/bin"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI DPC++/C++ Compiler ", "Version: compiler/2024.0.0 "
            , "Description: IntelÂ® oneAPI C/C++ and SYCL code compiler for CPUs, GPUs and FPGAs "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-compiler.html ", "Dependencies: tbb compiler-rt oclfpga ",
          },
        },
      },
    },
    ["oneapi_2024/compiler-rt"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/compiler-rt/2024.0.0"]  = {
          ["Description"] = "oneAPI Compiler redistributable libraries ",
          ["Name"] = "IntelÂ® oneAPI Compiler redistributable libraries ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/articles/tool/compilers-redistributable-libraries-by-version.html ",
          ["Version"] = "compiler-rt/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/compiler-rt/2024.0.0",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/opt/compiler/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI Compiler redistributable libraries "
            , "Version: compiler-rt/2024.0.0 "
            , "Description: oneAPI Compiler redistributable libraries "
            , "URL: https://www.intel.com/content/www/us/en/developer/articles/tool/compilers-redistributable-libraries-by-version.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/compiler-rt32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/compiler-rt32/2024.0.0"]  = {
          ["Description"] = "oneAPI Compiler redistributable libraries ",
          ["Name"] = "IntelÂ® oneAPI Compiler redistributable libraries ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/articles/tool/compilers-redistributable-libraries-by-version.html ",
          ["Version"] = "compiler-rt32/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/compiler-rt32/2024.0.0",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/lib32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI Compiler redistributable libraries "
            , "Version: compiler-rt32/2024.0.0 "
            , "Description: oneAPI Compiler redistributable libraries "
            , "URL: https://www.intel.com/content/www/us/en/developer/articles/tool/compilers-redistributable-libraries-by-version.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/compiler32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/compiler32/2024.0.0"]  = {
          ["Description"] = "IntelÂ® oneAPI C/C++ and SYCL code compiler for CPUs, GPUs and FPGAs ",
          ["Name"] = "IntelÂ® oneAPI DPC++/C++ Compiler ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-compiler.html ",
          ["Version"] = "compiler32/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/compiler32/2024.0.0",
          ["help"] = "",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/bin"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI DPC++/C++ Compiler ", "Version: compiler32/2024.0.0 "
            , "Description: IntelÂ® oneAPI C/C++ and SYCL code compiler for CPUs, GPUs and FPGAs "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-compiler.html ", "Dependencies: tbb32 compiler-rt32 ",
          },
        },
      },
    },
    ["oneapi_2024/dal"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/dal/2024.0.0"]  = {
          ["Description"] = "Library for building compute-intense applications optimized for Intel CPUs and GPUs. ",
          ["Name"] = "IntelÂ® oneAPI Data Analytics Library ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/onedal.html ",
          ["Version"] = "dal/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/dal/2024.0.0",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/dal/2024.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI Data Analytics Library ", "Version: dal/2024.0.0 "
            , "Description: Library for building compute-intense applications optimized for Intel CPUs and GPUs. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/onedal.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/debugger"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/debugger/2024.0.0"]  = {
          ["Description"] = "IntelÂ® oneAPI Application Debugger (gdb-oneapi) ",
          ["Name"] = "IntelÂ® Distribution for GDB ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/distribution-for-gdb.html ",
          ["Version"] = "debugger/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/debugger/2024.0.0",
          ["help"] = [[
module whatis oneapi_2024/debugger

]],
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/debugger/2024.0/opt/debugger/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/debugger/2024.0/bin"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® Distribution for GDB ", "Version: debugger/2024.0.0 "
            , "Description: IntelÂ® oneAPI Application Debugger (gdb-oneapi) "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/distribution-for-gdb.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/dev-utilities"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/dev-utilities/2024.0.0"]  = {
          ["Description"] = "Sample headers and CLI sample browser (oneapi-cli). ",
          ["Name"] = "IntelÂ® Dev Utilities ",
          ["URL"] = "https://github.com/intel/oneapi-cli ",
          ["Version"] = "dev-utilities/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/dev-utilities/2024.0.0",
          ["help"] = [[
module whatis oneapi_2024/dev-utilities

]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/dev-utilities/2024.0/bin"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® Dev Utilities ", "Version: dev-utilities/2024.0.0 "
            , "Description: Sample headers and CLI sample browser (oneapi-cli). "
            , "URL: https://github.com/intel/oneapi-cli ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/dnnl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/dnnl/3.3.0"]  = {
          ["Description"] = "Performance library of basic building blocks for deep learning applications ",
          ["Name"] = "IntelÂ® oneAPI Deep Neural Network Library (oneDNN) ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/onednn.html ",
          ["Version"] = "dnnl/3.3.0 ",
          ["canonical"] = "3.3.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/dnnl/3.3.0",
          ["help"] = [[
module whatis oneapi_2024/dnnl

]],
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/dnnl/2024.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000003.*zfinal",
          ["wV"] = "000000003.000000003.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI Deep Neural Network Library (oneDNN) "
            , "Version: dnnl/3.3.0 "
            , "Description: Performance library of basic building blocks for deep learning applications "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/onednn.html ", "Dependencies: tbb compiler-rt ",
          },
        },
      },
    },
    ["oneapi_2024/dpct"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/dpct/2024.0.0"]  = {
          ["Description"] = "Migrate existing CUDA* code to SYCL code. ",
          ["Name"] = "IntelÂ® DPC++ Compatibility Tool ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-compatibility-tool.html ",
          ["Version"] = "dpct/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/dpct/2024.0.0",
          ["help"] = [[
module whatis oneapi_2024/dpct

]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/dpcpp-ct/2024.0/bin"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® DPC++ Compatibility Tool ", "Version: dpct/2024.0.0 "
            , "Description: Migrate existing CUDA* code to SYCL code. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-compatibility-tool.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/dpl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/dpl/2022.3"]  = {
          ["Description"] = "Intel(R) oneAPI DPC++ Library provides an alternative for C++ developers who create heterogeneous applications and solutions. Its APIs are based on familiar standards - C++ STL, Parallel STL (PSTL), Boost.Compute, and SYCL* - to maximize productivity and performance across CPUs, GPUs, and FPGAs. ",
          ["Name"] = "Intel(R) oneAPI DPC++ Library (oneDPL) ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-library.html ",
          ["Version"] = "dpl/2022.3 ",
          ["canonical"] = "2022.3",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/dpl/2022.3",
          ["help"] = [[
module whatis oneapi_2024/dpl

]],
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/dpl/2022.3/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.000000003.*zfinal",
          ["wV"] = "000002022.000000003.*zfinal",
          whatis = {
            "Name: Intel(R) oneAPI DPC++ Library (oneDPL) ", "Version: dpl/2022.3 "
            , "Description: Intel(R) oneAPI DPC++ Library provides an alternative for C++ developers who create heterogeneous applications and solutions. Its APIs are based on familiar standards - C++ STL, Parallel STL (PSTL), Boost.Compute, and SYCL* - to maximize productivity and performance across CPUs, GPUs, and FPGAs. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/dpc-library.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/ifort"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/ifort/2024.0.0"]  = {
          ["Description"] = "IntelÂ® Fortran Compiler Classic for building optimized IntelÂ® 64, and IA-32 CPUs ",
          ["Name"] = "IntelÂ® oneAPI DPC++/C++ Compiler ",
          ["URL"] = "https://www.intel.com/content/www/us/en/docs/fortran-compiler/get-started-guide/current/overview.html ",
          ["Version"] = "ifort/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/ifort/2024.0.0",
          ["help"] = "",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/bin"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI DPC++/C++ Compiler ", "Version: ifort/2024.0.0 "
            , "Description: IntelÂ® Fortran Compiler Classic for building optimized IntelÂ® 64, and IA-32 CPUs "
            , "URL: https://www.intel.com/content/www/us/en/docs/fortran-compiler/get-started-guide/current/overview.html ", "Dependencies: compiler-rt ",
          },
        },
      },
    },
    ["oneapi_2024/ifort32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/ifort32/2024.0.0"]  = {
          ["Description"] = "IntelÂ® Fortran Compiler Classic for building optimized IntelÂ® 64, and IA-32 CPUs ",
          ["Name"] = "IntelÂ® Fortran Compiler Classic ",
          ["URL"] = "https://www.intel.com/content/www/us/en/docs/fortran-compiler/get-started-guide/current/overview.html ",
          ["Version"] = "ifort32/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/ifort32/2024.0.0",
          ["help"] = "",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/compiler/2024.0/bin"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® Fortran Compiler Classic ", "Version: ifort32/2024.0.0 "
            , "Description: IntelÂ® Fortran Compiler Classic for building optimized IntelÂ® 64, and IA-32 CPUs "
            , "URL: https://www.intel.com/content/www/us/en/docs/fortran-compiler/get-started-guide/current/overview.html ", "Dependencies: compiler-rt32 ",
          },
        },
      },
    },
    ["oneapi_2024/inspector"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/inspector/2024.0"]  = {
          ["Version"] = "/} ",
          ["canonical"] = "2024.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/inspector/2024.0",
          ["help"] = "",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/bin64"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Intel(R) Inspector 2024.0 ", "Version: /} ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/intel_ipp_ia32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/intel_ipp_ia32/2021.10"]  = {
          ["Description"] = "A library of multimedia and data processing optimized for Single Instruction, Multiple Data (SIMD) instructions. ",
          ["Name"] = "IntelÂ® Integrated Performance Primitives IA-32 architecture ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/ipp.html ",
          ["Version"] = "intel_ipp_ia32/2021.10 ",
          ["canonical"] = "2021.10",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/intel_ipp_ia32/2021.10",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/ipp/2021.10/lib32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000010.*zfinal",
          ["wV"] = "000002021.000000010.*zfinal",
          whatis = {
            "Name: IntelÂ® Integrated Performance Primitives IA-32 architecture "
            , "Version: intel_ipp_ia32/2021.10 "
            , "Description: A library of multimedia and data processing optimized for Single Instruction, Multiple Data (SIMD) instructions. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/ipp.html ", "Dependencies: compiler-rt32 tbb32 ",
          },
        },
      },
    },
    ["oneapi_2024/intel_ipp_intel64"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/intel_ipp_intel64/2021.10"]  = {
          ["Description"] = "A library of multimedia and data processing optimized for Single Instruction, Multiple Data (SIMD) instructions. ",
          ["Name"] = "IntelÂ® Integrated Performance Primitives Intel(R) 64 architecture ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/ipp.html ",
          ["Version"] = "intel_ipp_intel64/2021.10 ",
          ["canonical"] = "2021.10",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/intel_ipp_intel64/2021.10",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/ipp/2021.10/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000010.*zfinal",
          ["wV"] = "000002021.000000010.*zfinal",
          whatis = {
            "Name: IntelÂ® Integrated Performance Primitives Intel(R) 64 architecture "
            , "Version: intel_ipp_intel64/2021.10 "
            , "Description: A library of multimedia and data processing optimized for Single Instruction, Multiple Data (SIMD) instructions. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/ipp.html ", "Dependencies: compiler-rt tbb ",
          },
        },
      },
    },
    ["oneapi_2024/intel_ippcp_ia32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/intel_ippcp_ia32/2021.9"]  = {
          ["Description"] = "A secure, fast and lightweight library of building blocks for cryptography, highly-optimized for various IntelÂ® CPUs. ",
          ["Name"] = "IntelÂ® Integrated Performance Primitives Cryptography IA-32 architecture ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/ipp.html ",
          ["Version"] = "intel_ippcp_ia32/2021.9 ",
          ["canonical"] = "2021.9",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/intel_ippcp_ia32/2021.9",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/ippcp/2021.9/lib32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000009.*zfinal",
          ["wV"] = "000002021.000000009.*zfinal",
          whatis = {

                        "Name: IntelÂ® Integrated Performance Primitives Cryptography IA-32 architecture "
            , "Version: intel_ippcp_ia32/2021.9 "
            , "Description: A secure, fast and lightweight library of building blocks for cryptography, highly-optimized for various IntelÂ® CPUs. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/ipp.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/intel_ippcp_intel64"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/intel_ippcp_intel64/2021.9"]  = {
          ["Description"] = "A secure, fast and lightweight library of building blocks for cryptography, highly-optimized for various IntelÂ® CPUs. ",
          ["Name"] = "IntelÂ® Integrated Performance Primitives Cryptography IntelÂ® 64 architecture ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/ipp.html ",
          ["Version"] = "intel_ippcp_intel64/2021.9 ",
          ["canonical"] = "2021.9",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/intel_ippcp_intel64/2021.9",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/ippcp/2021.9/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000009.*zfinal",
          ["wV"] = "000002021.000000009.*zfinal",
          whatis = {

                        "Name: IntelÂ® Integrated Performance Primitives Cryptography IntelÂ® 64 architecture "
            , "Version: intel_ippcp_intel64/2021.9 "
            , "Description: A secure, fast and lightweight library of building blocks for cryptography, highly-optimized for various IntelÂ® CPUs. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/ipp.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/itac"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/itac/2022.0"]  = {
          ["Version"] = "2022.0",
          ["canonical"] = "2022.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/itac/2022.0",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/itac/2022.0/slib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002022.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/itac/2022.0/bin"] = 1,
          },
          ["wV"] = "000002022.*zfinal",
          whatis = {
            "Intel(R) Trace Analyzer and Collector ",
          },
        },
      },
    },
    ["oneapi_2024/mkl"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/mkl/2024.0"]  = {
          ["Description"] = "Intel(R) oneAPI Math Kernel Library (oneMKL) ",
          ["Name"] = "Intel(R) oneAPI Math Kernel Library ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/onemkl.html ",
          ["Version"] = "mkl/2024.0 ",
          ["canonical"] = "2024.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/mkl/2024.0",
          ["help"] = [[
module whatis oneapi_2024/mkl

]],
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/mkl/2024.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: Intel(R) oneAPI Math Kernel Library ", "Version: mkl/2024.0 "
            , "Description: Intel(R) oneAPI Math Kernel Library (oneMKL) "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/onemkl.html ", "Dependencies: tbb compiler-rt ",
          },
        },
      },
    },
    ["oneapi_2024/mkl32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/mkl32/2024.0"]  = {
          ["Description"] = "Intel(R) oneAPI Math Kernel Library (oneMKL) ",
          ["Name"] = "Intel(R) oneAPI Math Kernel Library ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/onemkl.html ",
          ["Version"] = "mkl32/2024.0 ",
          ["canonical"] = "2024.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/mkl32/2024.0",
          ["help"] = [[
module whatis oneapi_2024/mkl32

]],
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/mkl/2024.0/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi_2024/mkl/2024.0/lib32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: Intel(R) oneAPI Math Kernel Library ", "Version: mkl32/2024.0 "
            , "Description: Intel(R) oneAPI Math Kernel Library (oneMKL) "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/onemkl.html ", "Dependencies: tbb32 compiler-rt32 ",
          },
        },
      },
    },
    ["oneapi_2024/mpi"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/mpi/2021.11"]  = {
          ["Description"] = "Intel(R) MPI Library ",
          ["Name"] = "Intel(R) MPI Library ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/mpi-library.html ",
          ["Version"] = "modulefiles/2021.11 ",
          ["canonical"] = "2021.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/mpi/2021.11",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/mpi/2021.11/lib"] = 1,
            ["/home/opt_ohpc_pub/oneapi_2024/mpi/2021.11/opt/mpi/libfabric/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000011.*zfinal",
          pathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/mpi/2021.11/bin"] = 1,
            ["/home/opt_ohpc_pub/oneapi_2024/mpi/2021.11/opt/mpi/libfabric/bin"] = 1,
          },
          ["wV"] = "000002021.000000011.*zfinal",
          whatis = {
            "Name: Intel(R) MPI Library ", "Version: modulefiles/2021.11 "
            , "Description: Intel(R) MPI Library "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/mpi-library.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/oclfpga"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/oclfpga/2024.0.0"]  = {
          ["Description"] = "Enables FPGA development using the IntelÂ® oneAPI SYCL Compiler. ",
          ["Name"] = "IntelÂ® oneAPI SYCL Compiler for FPGA ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/distribution-for-gdb.html ",
          ["Version"] = "oclfpga/2024.0.0 ",
          ["canonical"] = "2024.0.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/oclfpga/2024.0.0",
          ["help"] = "",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Name: IntelÂ® oneAPI SYCL Compiler for FPGA ", "Version: oclfpga/2024.0.0 "
            , "Description: Enables FPGA development using the IntelÂ® oneAPI SYCL Compiler. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/distribution-for-gdb.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/tbb"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/tbb/2021.11"]  = {
          ["Description"] = "Flexible threading library for adding parallelism to complex applications across accelerated architectures. ",
          ["Name"] = "Intel(R) oneAPI Threading Building Blocks ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/onetbb.html ",
          ["Version"] = "tbb/2021.11 ",
          ["canonical"] = "2021.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/tbb/2021.11",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/tbb/2021.11/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000011.*zfinal",
          ["wV"] = "000002021.000000011.*zfinal",
          whatis = {
            "Name: Intel(R) oneAPI Threading Building Blocks ", "Version: tbb/2021.11 "
            , "Description: Flexible threading library for adding parallelism to complex applications across accelerated architectures. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/onetbb.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/tbb32"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/tbb32/2021.11"]  = {
          ["Description"] = "Flexible threading library for adding parallelism to complex applications across accelerated architectures. ",
          ["Name"] = "Intel(R) oneAPI Threading Building Blocks ",
          ["URL"] = "https://www.intel.com/content/www/us/en/developer/tools/oneapi/onetbb.html ",
          ["Version"] = "tbb32/2021.11 ",
          ["canonical"] = "2021.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/tbb32/2021.11",
          ["help"] = "",
          lpathA = {
            ["/home/opt_ohpc_pub/oneapi_2024/tbb/2021.11/lib32"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002021.000000011.*zfinal",
          ["wV"] = "000002021.000000011.*zfinal",
          whatis = {
            "Name: Intel(R) oneAPI Threading Building Blocks ", "Version: tbb32/2021.11 "
            , "Description: Flexible threading library for adding parallelism to complex applications across accelerated architectures. "
            , "URL: https://www.intel.com/content/www/us/en/developer/tools/oneapi/onetbb.html ", "Dependencies: none ",
          },
        },
      },
    },
    ["oneapi_2024/vtune"]  = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["oneapi_2024/vtune/2024.0"]  = {
          ["Version"] = "/} ",
          ["canonical"] = "2024.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/oneapi_2024/vtune/2024.0",
          ["help"] = "",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000002024.*zfinal",
          pathA = {
            ["/bin64"] = 1,
          },
          ["wV"] = "000002024.*zfinal",
          whatis = {
            "Intel(R) VTune(TM) Profiler 2024.0.0 ", "Version: /} ", "Dependencies: none ",
          },
        },
      },
    },
    openmpi = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["openmpi/3.1.5"]  = {
          ["Version"] = "3.1.5",
          ["canonical"] = "3.1.5",
          ["fn"] = "/opt/ohpc/pub/modulefiles/openmpi/3.1.5",
          ["help"] = [[
	Adds OpenMPI to your environment

]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/openmpi/3.1.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000001.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/openmpi/3.1.5/bin"] = 1,
          },
          ["wV"] = "000000003.000000001.000000005.*zfinal",
          whatis = {
            "Adds OpenMPI to your environment ",
          },
        },
        ["openmpi/4.0.5"]  = {
          ["Version"] = "4.0.5",
          ["canonical"] = "4.0.5",
          ["fn"] = "/opt/ohpc/pub/modulefiles/openmpi/4.0.5",
          ["help"] = [[
	Adds OpenMPI to your environment

]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/openmpi/4.0.5/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000004.000000000.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/openmpi/4.0.5/bin"] = 1,
          },
          ["wV"] = "000000004.000000000.000000005.*zfinal",
          whatis = {
            "Adds OpenMPI to your environment ",
          },
        },
        ["openmpi/4.1.0"]  = {
          ["Version"] = "4.1.0",
          ["canonical"] = "4.1.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/openmpi/4.1.0",
          ["help"] = [[
	Adds OpenMPI to your environment

]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/openmpi/4.1.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/openmpi/4.1.0/bin"] = 1,
          },
          ["wV"] = "000000004.000000001.*zfinal",
          whatis = {
            "Adds OpenMPI to your environment ",
          },
        },
        ["openmpi/4.1.1"]  = {
          ["Version"] = "4.1.1",
          ["canonical"] = "4.1.1",
          ["fn"] = "/opt/ohpc/pub/modulefiles/openmpi/4.1.1",
          ["help"] = [[
	Adds OpenMPI to your environment

]],
          lpathA = {
            ["/opt/ohpc/pub/compiler/openmpi/4.1.1/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000004.000000001.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/compiler/openmpi/4.1.1/bin"] = 1,
          },
          ["wV"] = "000000004.000000001.000000001.*zfinal",
          whatis = {
            "Adds OpenMPI to your environment ",
          },
        },
      },
    },
    papi = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["papi/.version.5.7.0"]  = {
          ["Version"] = ".version.5.7.0",
          ["canonical"] = ".version.5.7.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/papi/.version.5.7.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000005.000000007.*zfinal",
          ["wV"] = "*version.000000005.000000007.*zfinal",
        },
        ["papi/5.7.0"]  = {
          ["Category"] = "runtime library ",
          ["Description"] = "Performance Application Programming Interface ",
          ["Name"] = "papi built with gnu8 compiler ",
          ["Version"] = "5.7.0 ",
          ["canonical"] = "5.7.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/papi/5.7.0",
          ["help"] = [[
 
This module loads the papi library built with the gnu8 compiler
toolchain.

Version 5.7.0


]],
          lpathA = {
            ["/opt/ohpc/pub/libs/papi/5.7.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000005.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/papi/5.7.0/bin"] = 1,
          },
          ["wV"] = "000000005.000000007.*zfinal",
          whatis = {
            "Name: papi built with gnu8 compiler ", "Version: 5.7.0 "
            , "Category: runtime library "
            , "Description: Performance Application Programming Interface ", "URL http://icl.cs.utk.edu/papi/ ",
          },
        },
      },
    },
    prun = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["prun/.version.1.3"]  = {
          ["Version"] = ".version.1.3",
          ["canonical"] = ".version.1.3",
          ["fn"] = "/opt/ohpc/pub/modulefiles/prun/.version.1.3",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000001.000000003.*zfinal",
          ["wV"] = "*version.000000001.000000003.*zfinal",
        },
        ["prun/1.3"]  = {
          ["Category"] = "resource manager tools ",
          ["Description"] = "job launch utility for multiple MPI families ",
          ["Name"] = "prun job launch utility ",
          ["Version"] = "1.3 ",
          ["canonical"] = "1.3",
          ["fn"] = "/opt/ohpc/pub/modulefiles/prun/1.3",
          ["help"] = [[
 
This module loads the prun job launch utility
 
Version 1.3
 

]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000001.000000003.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/utils/prun/1.3"] = 1,
          },
          ["wV"] = "000000001.000000003.*zfinal",
          whatis = {
            "Name: prun job launch utility ", "Version: 1.3 "
            , "Category: resource manager tools ", "Description: job launch utility for multiple MPI families ",
          },
        },
      },
    },
    python = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["python/3.7.0"]  = {
          ["Version"] = "3.7.0",
          ["canonical"] = "3.7.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/python/3.7.0",
          lpathA = {
            ["/opt/ohpc/pub/python/python-3.7.0/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000007.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/python/python-3.7.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.*zfinal",
        },
        ["python/3.7.11"]  = {
          ["Version"] = "3.7.11",
          ["canonical"] = "3.7.11",
          ["fn"] = "/opt/ohpc/pub/modulefiles/python/3.7.11",
          lpathA = {
            ["/opt/ohpc/pub/python3.7.11/lib"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000007.000000011.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/python3.7.11/bin"] = 1,
          },
          ["wV"] = "000000003.000000007.000000011.*zfinal",
        },
      },
    },
    singularity = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["singularity/.version.3.4.1"]  = {
          ["Version"] = ".version.3.4.1",
          ["canonical"] = ".version.3.4.1",
          ["fn"] = "/opt/ohpc/pub/modulefiles/singularity/.version.3.4.1",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000003.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000004.000000001.*zfinal",
        },
        ["singularity/3.4.1"]  = {
          ["Category"] = "runtime ",
          ["Description"] = "Application and environment virtualization ",
          ["Name"] = "singularity ",
          ["Version"] = "3.4.1 ",
          ["canonical"] = "3.4.1",
          ["fn"] = "/opt/ohpc/pub/modulefiles/singularity/3.4.1",
          ["help"] = [[
 
This module loads the singularity utility

Version 3.4.1


]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/singularity/3.4.1/bin"] = 1,
          },
          ["wV"] = "000000003.000000004.000000001.*zfinal",
          whatis = {
            "Name: singularity ", "Version: 3.4.1 ", "Category: runtime "
            , "Description: Application and environment virtualization ", "URL https://www.sylabs.io/singularity/ ",
          },
        },
      },
    },
    singularity101 = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["singularity101/.version.3.4.1"]  = {
          ["Version"] = ".version.3.4.1",
          ["canonical"] = ".version.3.4.1",
          ["fn"] = "/opt/ohpc/pub/modulefiles/singularity101/.version.3.4.1",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000003.000000004.000000001.*zfinal",
          ["wV"] = "*version.000000003.000000004.000000001.*zfinal",
        },
        ["singularity101/3.4.1"]  = {
          ["Category"] = "runtime ",
          ["Description"] = "Application and environment virtualization ",
          ["Name"] = "singularity ",
          ["Version"] = "3.4.1 ",
          ["canonical"] = "3.4.1",
          ["fn"] = "/opt/ohpc/pub/modulefiles/singularity101/3.4.1",
          ["help"] = [[
 
This module loads the singularity utility

Version 3.4.1


]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000004.000000001.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/libs/singularity/3.4.1/bin"] = 1,
          },
          ["wV"] = "000000003.000000004.000000001.*zfinal",
          whatis = {
            "Name: singularity ", "Version: 3.4.1 ", "Category: runtime "
            , "Description: Application and environment virtualization ", "URL https://www.sylabs.io/singularity/ ",
          },
        },
      },
    },
    valgrind = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["valgrind/.version.3.15.0"]  = {
          ["Version"] = ".version.3.15.0",
          ["canonical"] = ".version.3.15.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/valgrind/.version.3.15.0",
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "*version.000000003.000000015.*zfinal",
          ["wV"] = "*version.000000003.000000015.*zfinal",
        },
        ["valgrind/3.15.0"]  = {
          ["Category"] = "utility, developer support ",
          ["Description"] = "Memory debugging utilities ",
          ["Name"] = "Valgrind Memory Debugger ",
          ["Version"] = "3.15.0 ",
          ["canonical"] = "3.15.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/valgrind/3.15.0",
          ["help"] = [[
This module loads the valgrind package for performing dynamic analysis.
 

]],
          lpathA = {
            ["/opt/ohpc/pub/utils/valgrind/3.15.0/lib"] = 1,
            ["/opt/ohpc/pub/utils/valgrind/3.15.0/lib/pkgconfig"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000003.000000015.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/utils/valgrind/3.15.0/bin"] = 1,
          },
          ["wV"] = "000000003.000000015.*zfinal",
          whatis = {
            "Name: Valgrind Memory Debugger ", "Version: 3.15.0 "
            , "Category: utility, developer support ", "Keywords: Debugging ", "Description: Memory debugging utilities ",
          },
        },
      },
    },
    vampire = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["vampire/5.0"]  = {
          ["Version"] = "5.0",
          ["canonical"] = "5.0",
          ["fn"] = "/opt/ohpc/pub/modulefiles/vampire/5.0",
          lpathA = {
            ["/opt/ohpc/pub/modulefiles/vampire/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/modulefiles/vampire/bin"] = 1,
          },
          ["wV"] = "000000005.*zfinal",
        },
      },
    },
    vmd = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["vmd/1.9.3"]  = {
          ["Category"] = "runtime ",
          ["Name"] = "vmd ",
          ["Version"] = "3.9.3 ",
          ["canonical"] = "1.9.3",
          ["fn"] = "/opt/ohpc/pub/modulefiles/vmd/1.9.3",
          ["help"] = [[
 
This module loads the VMD

Version 3.9.3


]],
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000001.000000009.000000003.*zfinal",
          pathA = {
            ["/home/apps/vmd/bin"] = 1,
          },
          ["wV"] = "000000001.000000009.000000003.*zfinal",
          whatis = {
            "Name: vmd ", "Version: 3.9.3 ", "Category: runtime ",
          },
        },
      },
    },
    xcrysden = {
      defaultT = {},
      dirT = {},
      fileT = {
        ["xcrysden/1.5"]  = {
          ["Version"] = "1.5",
          ["canonical"] = "1.5",
          ["fn"] = "/opt/ohpc/pub/modulefiles/xcrysden/1.5",
          lpathA = {
            ["/opt/ohpc/pub/modulefiles/xcrysden/lib64"] = 1,
          },
          ["mpath"] = "/opt/ohpc/pub/modulefiles",
          ["pV"] = "000000001.000000005.*zfinal",
          pathA = {
            ["/opt/ohpc/pub/modulefiles/xcrysden/bin"] = 1,
          },
          ["wV"] = "000000001.000000005.*zfinal",
        },
      },
    },
  },
  ["version"] = 5,
}
mpathMapT = {
  ["/home/apps/spack/share/spack/modules/linux-centos7-cascadelake"]  = {
    ["spack/0.16.3"] = "/home/apps/modulefiles",
  },
  ["/home/apps/spack/share/spack/modules/linux-centos7-skylake_avx512"]  = {
    ["spack/0.16.3"] = "/home/apps/modulefiles",
  },
  ["/home/c-huk27/.local/easybuild/modules/all"]  = {
    ["EasyBuild/3.9.4"] = "/opt/ohpc/pub/modulefiles",
  },
  ["/opt/ohpc/pub/moduledeps/gnu"]  = {
    ["gnu/5.4.0"] = "/opt/ohpc/pub/modulefiles",
  },
  ["/opt/ohpc/pub/moduledeps/gnu8"]  = {
    ["gnu8/8.3.0"] = "/opt/ohpc/pub/modulefiles",
  },
  ["/opt/ohpc/pub/moduledeps/gnu8-mpich"]  = {
    ["mpich/3.3.1"] = "/opt/ohpc/pub/moduledeps/gnu8",
  },
  ["/opt/ohpc/pub/moduledeps/gnu8-mvapich2"]  = {
    ["mvapich2/2.3.2"] = "/opt/ohpc/pub/moduledeps/gnu8",
  },
  ["/opt/ohpc/pub/moduledeps/intel"]  = {
    ["intel/18.0.5.274"] = "/opt/ohpc/pub/modulefiles",
  },
  ["/opt/ohpc/pub/moduledeps/intel-impi"]  = {
    ["impi/2018.4.274"] = "/opt/ohpc/pub/moduledeps/intel",
  },
  ["/opt/ohpc/pub/moduledeps/intel-mpich"]  = {
    ["mpich/3.3.1"] = "/opt/ohpc/pub/moduledeps/intel",
  },
  ["/opt/ohpc/pub/moduledeps/intel-mvapich2"]  = {
    ["mvapich2/2.3.2"] = "/opt/ohpc/pub/moduledeps/intel",
  },
  ["/opt/ohpc/pub/moduledeps/intel-openmpi3"]  = {
    ["openmpi3/3.1.4"] = "/opt/ohpc/pub/moduledeps/intel",
  },
  ["/opt/ohpc/pub/moduledeps/llvm"]  = {
    ["llvm5/5.0.1"] = "/opt/ohpc/pub/modulefiles",
  },
}
